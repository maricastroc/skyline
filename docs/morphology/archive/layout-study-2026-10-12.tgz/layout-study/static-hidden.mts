import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir] = process.argv.slice(2);
const { safeFetch, decodeHtml } = await import(join(root, "src/lib/acquisition/safe-fetch.ts"));
const { fetchStylesheets } = await import(join(root, "src/lib/acquisition/static-fetch.ts"));
const { parsePage } = await import(join(root, "src/lib/snapshot/parse-html.ts"));
const PAGES: Record<string, string> = {
  hn: "https://news.ycombinator.com/", lobsters: "https://lobste.rs/", pydocs: "https://docs.python.org/3/library/itertools.html",
  mdn: "https://developer.mozilla.org/en-US/docs/Web/HTML", wikipedia: "https://en.wikipedia.org/wiki/City", linear: "https://linear.app/",
  vercel: "https://vercel.com/", apple: "https://www.apple.com/", govuk: "https://www.gov.uk/", guardian: "https://www.theguardian.com/international",
  github: "https://github.com/vercel/next.js", craigslist: "https://www.craigslist.org/about/sites", ikea: "https://www.ikea.com/us/en/cat/chairs-fu002/",
};

function applicable(css: string): string {
  const clean = css.replace(/\/\*[\s\S]*?\*\//g, "");
  let out = "";
  let i = 0;
  while (i < clean.length) {
    const at = clean.indexOf("@", i);
    if (at < 0) { out += clean.slice(i); break; }
    out += clean.slice(i, at);
    const open = clean.indexOf("{", at);
    const semi = clean.indexOf(";", at);
    if (open < 0 || (semi >= 0 && semi < open)) { i = semi < 0 ? clean.length : semi + 1; continue; }
    let depth = 1, j = open + 1;
    while (j < clean.length && depth > 0) { if (clean[j] === "{") depth++; else if (clean[j] === "}") depth--; j++; }
    const head = clean.slice(at, open).toLowerCase();
    const body = clean.slice(open + 1, j - 1);
    if (/^@(media|supports|layer|container)/.test(head)) {
      const max = /max-width\s*:\s*([\d.]+)(px|em|rem)/.exec(head);
      const min = /min-width\s*:\s*([\d.]+)(px|em|rem)/.exec(head);
      const px = (m: RegExpExecArray) => parseFloat(m[1]) * (m[2] === "px" ? 1 : 16);
      const off = /print|prefers-reduced|hover:\s*none|pointer:\s*coarse|orientation:\s*portrait/.test(head) || (max && px(max) < 1440) || (min && px(min) > 1440);
      if (!off) out += applicable(body);
    }
    i = j;
  }
  return out;
}

const SIMPLE = /^([a-z][a-z0-9-]*)?(?:#([\w-]+))?((?:\.[\w-]+)*)$/i;
function hiddenRules(css: string) {
  const state = new Map<string, boolean>();
  for (const m of applicable(css).matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    const d = /(?:^|;)\s*display\s*:\s*([a-z-]+)/i.exec(m[2]);
    const v = /(?:^|;)\s*visibility\s*:\s*(hidden|visible)/i.exec(m[2]);
    if (!d && !v) continue;
    const hide = d ? d[1].toLowerCase() === "none" : v![1].toLowerCase() === "hidden";
    for (const raw of m[1].split(",")) {
      const sel = raw.trim();
      if (!sel || /[\s>+~:\[]/.test(sel)) continue;
      const s = SIMPLE.exec(sel);
      if (!s || (!s[2] && !s[3])) continue;
      state.set(`${s[1]?.toLowerCase() ?? ""}|${s[2] ?? ""}|${s[3].split(".").filter(Boolean).sort().join(".")}`, hide);
    }
  }
  return [...state].filter(([, h]) => h).map(([k]) => { const [tag, id, cls] = k.split("|"); return { tag, id, cls: cls ? cls.split(".") : [] }; });
}

const weightOf = (n: any): number => 1 + n.text / 180 + n.children.reduce((s: number, c: any) => s + weightOf(c), 0);
const hasBox = (n: any): boolean => !!n.box || n.children.some(hasBox);

console.log("page".padEnd(11), "truly unseen", "caught from CSS", "wrongly hidden", "rules");
for (const [id, url] of Object.entries(PAGES)) {
  const file = join(dir, `${id}.nojs.json`);
  if (!existsSync(file)) continue;
  const snap = JSON.parse(readFileSync(file, "utf8"));
  try {
    const res = await safeFetch(new URL(url), { accept: "text/html", maxBytes: 4 * 1024 * 1024, deadlineMs: 15000 });
    const page = parsePage(decodeHtml(res.body, res.contentType), res.url.toString());
    const css = [...page.inlineCss, ...(await fetchStylesheets(page.stylesheets))].join("\n");
    const rules = hiddenRules(css);
    const UTIL = /^(hidden|d-none|sr-only|visually-hidden|visuallyhidden|screen-reader-text|is-hidden|u-hidden|hide)$/;
    const predicted = (n: any) => (n.classes ?? []).some((c: string) => UTIL.test(c)) || rules.some((r) => (!r.tag || r.tag === n.tag) && (!r.id || r.id === n.id) && r.cls.every((c: string) => (n.classes ?? []).includes(c)));
    let total = 0, unseen = 0, caught = 0, wrong = 0;
    const walk = (n: any, hiddenAbove: boolean, unseenAbove: boolean) => {
      const own = 1 + n.text / 180;
      const h = hiddenAbove || predicted(n);
      const u = unseenAbove || !hasBox(n);
      total += own;
      if (u) unseen += own;
      if (u && h) caught += own;
      if (!u && h && n.box) wrong += own;
      for (const c of n.children) walk(c, h, u);
    };
    for (const c of snap.root.children) walk(c, false, false);
    console.log(id.padEnd(11), `${Math.round((unseen / total) * 100)}%`.padStart(12), `${unseen ? Math.round((caught / unseen) * 100) : 0}%`.padStart(15), `${Math.round((wrong / total) * 100)}%`.padStart(14), String(rules.length).padStart(5));
  } catch (e) {
    console.log(id.padEnd(11), "FAILED", (e as Error).message);
  }
}
