import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate, lotPath, N } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));

type Rect = [number, number, number, number];
const uni = (a: Rect | null, b: Rect): Rect => (a ? [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])] : b);

function prune(n: any): any {
  const kids = n.children.map(prune).filter(Boolean);
  if (!n.box && !kids.length) return null;
  return { ...n, children: kids };
}

function describe(snap: any) {
  const p = realPage(snap);
  const nodes = p.doc.nodes;
  const a = allocate(p.plan);
  const W = p.doc.layout?.width ?? 1440;
  const H = p.doc.layout?.height ?? 900;
  const ts = p.plan.territories.map((t: any, i: number) => {
    const scope: number[] = t.scope ? scopeOf(nodes, t.scope.roots, t.scope.excluded) : [];
    let rect: Rect | null = null;
    for (const r of t.scope?.roots ?? []) if (nodes[r].box) rect = uni(rect, [nodes[r].box[0], nodes[r].box[1], nodes[r].box[0] + nodes[r].box[2], nodes[r].box[1] + nodes[r].box[3]]);
    let hull: Rect | null = null;
    let ink = 0;
    const marks: Array<[number, number, number, number, number]> = [];
    for (const k of scope) {
      const n = nodes[k];
      if (!n.box) continue;
      hull = uni(hull, [n.box[0], n.box[1], n.box[0] + n.box[2], n.box[1] + n.box[3]]);
      ink += n.ink ?? 0;
      if ((n.ink ?? 0) > 0 || n.ownChars > 0) marks.push([n.box[0], n.box[1], n.box[0] + n.box[2], n.box[1] + n.box[3], n.selfWeight]);
    }
    const wq = (col: number, f: number) => {
      const v = marks.map((m) => [m[col], m[4]] as [number, number]).sort((a, b) => a[0] - b[0]);
      const total = v.reduce((x, y) => x + y[1], 0);
      let acc = 0;
      for (const [x, w] of v) if ((acc += w) >= f * total) return x;
      return v.length ? v[v.length - 1][0] : 0;
    };
    const core: Rect | null = marks.length >= 3 ? [wq(0, 0.1), wq(1, 0.1), wq(2, 0.9), wq(3, 0.9)] : null;
    const own = core && core[2] > core[0] && core[3] > core[1] ? core : t.source === "remainder" || t.source === "page" ? hull : (rect ?? hull);
    const area = own ? (own[2] - own[0]) * (own[3] - own[1]) : 0;
    const lots = a.lots[i] ?? 0;
    const coverage = area ? Math.min(1, ink / area) : 0;
    return { i, key: t.key, label: (t.label ?? t.kind).slice(0, 22), comp: [...t.mix].sort((x: any, y: any) => y.share - x.share)[0]?.comp ?? "-", tier: t.tier, order: t.order, lots, rect: own, coverage, empty: lots >= 6 && area > 0 && coverage < 0.03 && t.metrics.chars / lots < 3 && t.metrics.images === 0 };
  });
  const owner = Array.from(a.owner as Int32Array).map((s) => (s < 0 ? -1 : a.segments[s].territory));
  const comp: Record<string, number> = {};
  for (const t of ts) comp[t.comp] = (comp[t.comp] ?? 0) + t.lots / 256;
  return { W, H, ts, owner, comp, alloc: a };
}

function columnsOf(d: ReturnType<typeof describe>) {
  const big = d.ts.filter((t: any) => t.lots >= 6 && t.rect);
  if (big.length < 2) return null;
  const x0 = Math.min(...big.map((t: any) => t.rect[0]));
  const x1 = Math.max(...big.map((t: any) => t.rect[2]));
  const span = Math.max(x1 - x0, 1);
  const narrow = big.filter((t: any) => (t.rect[2] - t.rect[0]) / span < 0.7);
  const cols: Array<{ x0: number; x1: number; members: any[] }> = [];
  for (const t of [...narrow].sort((a: any, b: any) => a.rect[0] - b.rect[0])) {
    const c = cols.find((k) => Math.min(k.x1, t.rect[2]) - Math.max(k.x0, t.rect[0]) > 0.5 * Math.min(k.x1 - k.x0, t.rect[2] - t.rect[0]));
    if (c) {
      c.x0 = Math.min(c.x0, t.rect[0]);
      c.x1 = Math.max(c.x1, t.rect[2]);
      c.members.push(t);
    } else cols.push({ x0: t.rect[0], x1: t.rect[2], members: [t] });
  }
  const beside = (a: any, b: any) => {
    const oy = Math.min(a.rect[3], b.rect[3]) - Math.max(a.rect[1], b.rect[1]);
    return oy >= 0.5 * Math.min(a.rect[3] - a.rect[1], b.rect[3] - b.rect[1]);
  };
  const real = cols.filter((c) => cols.some((o) => o !== c && c.members.some((m) => o.members.some((n) => beside(m, n)))));
  if (real.length < 2) return null;
  return real.sort((a, b) => a.x0 - b.x0);
}

function plan2d(d: ReturnType<typeof describe>) {
  const cols = columnsOf(d);
  const voids = new Set(d.ts.filter((t: any) => t.empty).map((t: any) => t.i));
  if (!cols) return { owner: d.owner.map((t: number) => (voids.has(t) ? -2 : t)), columns: 0 };
  const colOf = new Map<number, number>();
  cols.forEach((c, k) => c.members.forEach((m) => colOf.set(m.i, k)));
  const main = cols.map((c, k) => ({ k, lots: c.members.reduce((s, m) => s + m.lots, 0) })).sort((a, b) => b.lots - a.lots)[0].k;
  for (const t of d.ts) if (t.lots > 0 && !colOf.has(t.i)) colOf.set(t.i, main);
  const need = cols.map((_, k) => d.ts.filter((t: any) => colOf.get(t.i) === k).reduce((s: number, t: any) => s + t.lots, 0));
  const sweep: number[] = [];
  for (let qx = 0; qx < N / 2; qx++) for (let qz = 0; qz < N / 2; qz++) for (const [dx, dz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) sweep.push((qx * 2 + dx) * N + qz * 2 + dz);
  const bandOf = new Int32Array(N * N).fill(-1);
  let at = 0;
  cols.forEach((_, k) => {
    for (let n = 0; n < need[k] && at < sweep.length; n++) bandOf[sweep[at++]] = k;
  });
  const path: Array<[number, number]> = lotPath();
  const owner = new Array(N * N).fill(-1);
  cols.forEach((_, k) => {
    const mine = d.ts.filter((t: any) => colOf.get(t.i) === k && t.lots > 0).sort((a: any, b: any) => a.tier - b.tier || a.order - b.order);
    const order = k === main ? path.map(([x, z]) => x * N + z).filter((c) => bandOf[c] === k) : sweep.filter((c) => bandOf[c] === k);
    let j = 0;
    for (const t of mine) for (let n = 0; n < t.lots && j < order.length; n++) owner[order[j++]] = voids.has(t.i) ? -2 : t.i;
  });
  return { owner, columns: cols.length };
}

const out: any[] = [];
console.log("page".padEnd(11), "fabric shares today → with only what is laid out".padEnd(86), "lots that change fabric", "columns", "empty lots");
for (const id of ids) {
  const file = join(dir, `${id}.js.json`);
  if (!existsSync(file)) continue;
  const snap = JSON.parse(readFileSync(file, "utf8"));
  const before = describe(snap);
  const after = describe({ ...snap, root: prune(snap.root) ?? snap.root });
  const p2 = plan2d(after);
  const fmt = (c: Record<string, number>) => Object.entries(c).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, v]) => `${k.slice(0, 6)} ${Math.round(v * 100)}`).join(", ");
  const keys = new Set([...Object.keys(before.comp), ...Object.keys(after.comp)]);
  let shift = 0;
  for (const k of keys) shift += Math.abs((before.comp[k] ?? 0) - (after.comp[k] ?? 0));
  console.log(id.padEnd(11), `${fmt(before.comp)}  →  ${fmt(after.comp)}`.padEnd(86), `${Math.round((shift / 2) * 100)}%`.padStart(22), String(p2.columns).padStart(7), String(p2.owner.filter((o: number) => o === -2).length).padStart(10));
  out.push({ id, W: after.W, H: after.H, before: { ts: before.ts, owner: before.owner }, after: { ts: after.ts, owner: after.owner }, plan: p2.owner, columns: p2.columns });
}
writeFileSync(join(dir, "plans.json"), JSON.stringify(out));
