import { readFileSync } from "node:fs";
const [dir, A, B] = process.argv.slice(2);
const load = (m) => new Map(JSON.parse(readFileSync(`${dir}/analysis.${m}.json`, "utf8")).map((r) => [r.id, r]));
const a = load(A), b = load(B);
const comp = (r) => { const d = {}; for (const t of r.territories) d[t.comp] = (d[t.comp] ?? 0) + t.lots / 256; return d; };
const tvd = (x, y) => { let s = 0; for (const k of new Set([...Object.keys(x), ...Object.keys(y)])) s += Math.abs((x[k] ?? 0) - (y[k] ?? 0)); return s / 2; };
console.log(`page`.padEnd(11), `elements ${A}/${B}`.padEnd(18), "visible".padEnd(10), "fabric shift", "same territories (lots)", "x-range kept", "side-by-side");
for (const [id, x] of a) {
  const y = b.get(id);
  if (!y) continue;
  const ky = new Map(y.territories.map((t) => [t.key, t]));
  let shared = 0, kept = 0, n = 0;
  for (const t of x.territories) {
    const u = ky.get(t.key);
    if (!u || !t.lots) continue;
    shared += Math.min(t.lots, u.lots);
    if (t.rect && u.rect && t.lots >= 6) {
      n++;
      const dx = Math.abs(t.rect[0] / x.W - u.rect[0] / y.W) + Math.abs(t.rect[2] / x.W - u.rect[2] / y.W);
      if (dx < 0.04) kept++;
    }
  }
  console.log(id.padEnd(11), `${x.elements}/${y.elements}`.padEnd(18), `${Math.round(x.visible * 100)}/${Math.round(y.visible * 100)}%`.padEnd(10), `${Math.round(tvd(comp(x), comp(y)) * 100)}%`.padStart(11), `${Math.round((shared / 256) * 100)}%`.padStart(22), `${kept}/${n}`.padStart(13), `${x.sideCount}/${y.sideCount}`.padStart(12));
}
