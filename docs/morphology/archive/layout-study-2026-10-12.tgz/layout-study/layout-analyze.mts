import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, mode, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate, N } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));

type Rect = [number, number, number, number];
const uni = (a: Rect | null, b: Rect): Rect => (a ? [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])] : b);
const median = (pairs: Array<[number, number]>) => {
  const s = pairs.filter((p) => p[1] > 0).sort((a, b) => a[0] - b[0]);
  const total = s.reduce((v, p) => v + p[1], 0);
  let acc = 0;
  for (const [v, w] of s) if ((acc += w) >= total / 2) return v;
  return 0;
};

export function analyze(id: string) {
  const file = join(dir, `${id}.${mode}.json`);
  if (!existsSync(file)) return null;
  const snap = JSON.parse(readFileSync(file, "utf8"));
  const p = realPage(snap);
  const nodes = p.doc.nodes;
  const a = allocate(p.plan);
  const W = p.doc.layout?.width ?? 1440;
  const H = p.doc.layout?.height ?? 900;
  const totalSelf = nodes.reduce((s: number, n: any) => s + n.selfWeight, 0);
  const seenSelf = nodes.reduce((s: number, n: any) => s + (n.box ? n.selfWeight : 0), 0);
  const shownSelf = nodes.reduce((s: number, n: any) => s + (n.box && !n.faded ? n.selfWeight : 0), 0);
  const ts = p.plan.territories.map((t: any, i: number) => {
    const scope: number[] = t.scope ? scopeOf(nodes, t.scope.roots, t.scope.excluded) : [];
    let rect: Rect | null = null;
    for (const r of t.scope?.roots ?? []) if (nodes[r].box) rect = uni(rect, [nodes[r].box[0], nodes[r].box[1], nodes[r].box[0] + nodes[r].box[2], nodes[r].box[1] + nodes[r].box[3]]);
    let hull: Rect | null = null;
    let ink = 0;
    let self = 0;
    let seen = 0;
    const fonts: Array<[number, number]> = [];
    let head = 0;
    for (const k of scope) {
      const n = nodes[k];
      self += n.selfWeight;
      if (!n.box) continue;
      seen += n.selfWeight;
      hull = uni(hull, [n.box[0], n.box[1], n.box[0] + n.box[2], n.box[1] + n.box[3]]);
      ink += n.ink ?? 0;
      if (n.fontSize && n.ownChars > 0) fonts.push([n.fontSize, n.ownChars]);
      if (n.heading && n.fontSize) head = Math.max(head, n.fontSize);
    }
    const own = t.source === "remainder" || t.source === "page" ? hull : (rect ?? hull);
    const area = own ? (own[2] - own[0]) * (own[3] - own[1]) : 0;
    const top = [...t.mix].sort((x: any, y: any) => y.share - x.share)[0]?.comp ?? "-";
    const region = t.region >= 0 ? p.sem.regions[t.region] : null;
    const items = (region?.items ?? []).map((k: number) => nodes[k].box).filter(Boolean) as number[][];
    const cols = items.length >= 4 ? new Set(items.map((b) => Math.round(b[0] / 16))).size : 0;
    return {
      i,
      key: t.key,
      label: (t.label ?? t.kind).slice(0, 26),
      kind: t.kind,
      source: t.source,
      comp: top,
      tier: t.tier,
      lots: a.lots[i] ?? 0,
      share: t.weight,
      rect: own,
      area,
      coverage: area ? Math.min(1, ink / area) : 0,
      font: Math.round(median(fonts)),
      head: Math.round(head),
      seen: self ? seen / self : 0,
      items: items.length,
      itemW: items.length ? Math.round(median(items.map((b) => [b[2], 1] as [number, number]))) : 0,
      itemH: items.length ? Math.round(median(items.map((b) => [b[3], 1] as [number, number]))) : 0,
      cols,
    };
  });
  const owner = Array.from(a.owner as Int32Array).map((s) => (s < 0 ? -1 : a.segments[s].territory));
  const landed = ts.filter((t: any) => t.lots > 0 && t.rect);
  const bbox = landed.reduce((r: Rect | null, t: any) => uni(r, t.rect), null as Rect | null) ?? [0, 0, W, H];
  const totalInk = nodes.reduce((s: number, n: any) => s + (n.box ? (n.ink ?? 0) : 0), 0);
  const side = new Set<number>();
  for (const x of landed)
    for (const y of landed) {
      if (x.i >= y.i || x.lots < 6 || y.lots < 6) continue;
      const oy = Math.min(x.rect[3], y.rect[3]) - Math.max(x.rect[1], y.rect[1]);
      const disjoint = x.rect[2] <= y.rect[0] + 8 || y.rect[2] <= x.rect[0] + 8;
      if (disjoint && oy >= 0.5 * Math.min(x.rect[3] - x.rect[1], y.rect[3] - y.rect[1])) {
        side.add(x.i);
        side.add(y.i);
      }
    }
  const lots = landed.reduce((s: number, t: any) => s + t.lots, 0) || 1;
  return {
    id,
    mode,
    W,
    H,
    elements: snap.stats.elementCount,
    chars: nodes[0].chars,
    visible: seenSelf / Math.max(totalSelf, 1),
    shown: shownSelf / Math.max(totalSelf, 1),
    headMax: Math.max(0, ...nodes.filter((n: any) => n.heading && n.fontSize && n.box && !n.faded).map((n: any) => n.fontSize)),
    bbox,
    coverage: totalInk / Math.max((bbox[2] - bbox[0]) * (bbox[3] - bbox[1]), 1),
    placed: landed.reduce((s: number, t: any) => s + t.lots, 0) / 256,
    sideShare: [...side].reduce((s, i) => s + ts[i].lots, 0) / lots,
    sideCount: side.size,
    territories: ts,
    owner,
    N,
  };
}

if (process.argv[1]?.endsWith("layout-analyze.mts")) {
  const out: any[] = [];
  console.log("page".padEnd(11), "page px".padEnd(12), "visible", "placed", "ink%", "side-by-side", " | largest territories: comp lots · x-range · coverage · body px / heading px");
  for (const id of ids) {
    const r = analyze(id);
    if (!r) continue;
    out.push(r);
    const big = r.territories.filter((t: any) => t.lots >= 10 && t.rect).sort((x: any, y: any) => y.lots - x.lots).slice(0, 4);
    console.log(
      id.padEnd(11),
      `${r.W}×${r.H}`.padEnd(12),
      `${Math.round(r.visible * 100)}%`.padStart(6),
      `${Math.round(r.placed * 100)}%`.padStart(6),
      `${Math.round(r.coverage * 100)}%`.padStart(4),
      `${r.sideCount} terr ${Math.round(r.sideShare * 100)}%`.padStart(12),
      " |",
      big.map((t: any) => `${t.comp.slice(0, 5)} ${t.lots}L x${Math.round((t.rect[0] / r.W) * 100)}–${Math.round((t.rect[2] / r.W) * 100)} c${Math.round(t.coverage * 100)} ${t.font}/${t.head}${t.cols ? ` ${t.cols}col ${t.itemW}×${t.itemH}` : ""}`).join(" · "),
    );
  }
  writeFileSync(join(dir, `analysis.${mode}.json`), JSON.stringify(out));
}
