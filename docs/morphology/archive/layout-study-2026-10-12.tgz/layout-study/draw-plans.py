import json, sys
from PIL import Image, ImageDraw, ImageFont

src, out, cols = sys.argv[1], sys.argv[2], int(sys.argv[3])
names = dict(a.split("=", 1) for a in sys.argv[4].split(","))
data = {r["id"]: r for r in json.load(open(src))}
COL = {
    "parcelled": (224, 142, 69), "continuous": (86, 132, 201), "media": (150, 104, 196), "archive": (150, 110, 78),
    "grid": (64, 168, 160), "navigation": (222, 196, 84), "support": (140, 146, 156), "interactive": (104, 178, 104),
    "structured": (214, 120, 160), "landmark": (214, 72, 72), "marker": (90, 90, 100), "-": (70, 70, 80),
}
BG, FG, MUTED, OPEN = (18, 18, 22), (240, 240, 240), (150, 150, 160), (196, 214, 170)
f = ImageFont.load_default(size=15)
fb = ImageFont.load_default(size=19)
PW, PH, LOT = 200, 300, 12
GRID = 16 * LOT
CW, CH = PW + 2 * GRID + 70, PH + 78

def page_panel(d, r, x, y):
    d.rectangle([x, y, x + PW, y + PH], fill=(34, 34, 40))
    sx = PW / r["W"]
    sy = min(sx, PH / r["H"])
    d.rectangle([x, y, x + PW, y + r["H"] * sy], fill=(246, 246, 242))
    for t in sorted([t for t in r["after"]["ts"] if t["lots"] > 0 and t["rect"]], key=lambda t: -((t["rect"][2] - t["rect"][0]) * (t["rect"][3] - t["rect"][1]))):
        a = t["rect"]
        box = [x + a[0] * sx, y + a[1] * sy, x + a[2] * sx, y + max(a[3] * sy, a[1] * sy + 2)]
        d.rectangle(box, fill=OPEN if t["empty"] else COL.get(t["comp"], COL["-"]), outline=(20, 20, 24))

def lot_panel(d, owner, ts, x, y):
    comp = {t["i"]: t["comp"] for t in ts}
    for X in range(16):
        for Z in range(16):
            o = owner[X * 16 + Z]
            c = OPEN if o == -2 else (40, 40, 46) if o < 0 else COL.get(comp.get(o, "-"), COL["-"])
            d.rectangle([x + X * LOT, y + Z * LOT, x + X * LOT + LOT - 1, y + Z * LOT + LOT - 1], fill=c)
    for X in range(16):
        for Z in range(16):
            o = owner[X * 16 + Z]
            if X < 15 and owner[(X + 1) * 16 + Z] != o:
                d.line([x + (X + 1) * LOT - 1, y + Z * LOT, x + (X + 1) * LOT - 1, y + (Z + 1) * LOT - 1], fill=(14, 14, 18), width=2)
            if Z < 15 and owner[X * 16 + Z + 1] != o:
                d.line([x + X * LOT, y + (Z + 1) * LOT - 1, x + (X + 1) * LOT - 1, y + (Z + 1) * LOT - 1], fill=(14, 14, 18), width=2)
    for k in range(1, 4):
        d.line([x + k * 4 * LOT - 1, y, x + k * 4 * LOT - 1, y + GRID], fill=(250, 250, 250), width=1)
        d.line([x, y + k * 4 * LOT - 1, x + GRID, y + k * 4 * LOT - 1], fill=(250, 250, 250), width=1)

ids = [i for i in names if i in data]
rows = (len(ids) + cols - 1) // cols
img = Image.new("RGB", (cols * CW + 20, rows * CH + 64), BG)
d = ImageDraw.Draw(img)
lx = 14
for k, v in [("parcelled", "sobrados"), ("continuous", "quadras"), ("media", "midia"), ("archive", "indice"), ("grid", "grade"), ("navigation", "navegacao"), ("support", "rodape"), ("interactive", "praca"), ("landmark", "marco")]:
    d.rectangle([lx, 14, lx + 16, 30], fill=COL[k])
    d.text((lx + 22, 13), v, fill=MUTED, font=f)
    lx += 30 + int(d.textlength(v, font=f)) + 16
d.rectangle([lx, 14, lx + 16, 30], fill=OPEN)
d.text((lx + 22, 13), "vazio medido", fill=MUTED, font=f)
for n, i in enumerate(ids):
    r = data[i]
    x = 14 + (n % cols) * CW
    y = 56 + (n // cols) * CH
    d.text((x, y), names[i], fill=FG, font=fb)
    d.text((x, y + 26), "a pagina", fill=MUTED, font=f)
    d.text((x + PW + 24, y + 26), "planta hoje", fill=MUTED, font=f)
    d.text((x + PW + GRID + 48, y + 26), "planta proposta", fill=MUTED, font=f)
    page_panel(d, r, x, y + 48)
    lot_panel(d, r["before"]["owner"], r["before"]["ts"], x + PW + 24, y + 48)
    lot_panel(d, r["plan"], r["after"]["ts"], x + PW + GRID + 48, y + 48)
img.save(out, quality=90)
print(out, img.size)
