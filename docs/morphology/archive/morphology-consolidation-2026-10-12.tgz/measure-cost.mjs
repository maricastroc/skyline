// The measuring pass alone, timed inside the page: how long it takes and how much it adds to the serialised HTML.
import { createRequire } from "node:module";
import { readFileSync, writeFileSync } from "node:fs";
const require = createRequire(process.cwd() + "/");
const puppeteer = require("puppeteer-core");
const [, , out, ...urls] = process.argv;
const src = readFileSync("src/lib/acquisition/render-page.ts", "utf8");
const grab = (name) => { const m = src.match(new RegExp("const " + name + " = `([\\s\\S]*?)`;")); if (!m) throw new Error("no " + name); return m[1]; };
const CLEAR = grab("CLEAR_BOXES");
const MEASURE = grab("MEASURE_BOXES").replace("${CLEAR_BOXES}", CLEAR);
const rows = [];
for (const url of urls) {
  const browser = await puppeteer.launch({ executablePath: process.env.CHROME_PATH ?? "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", headless: true });
  const row = { url };
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900 });
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
    await page.waitForNetworkIdle({ idleTime: 800, timeout: 8000 }).catch(() => undefined);
    row.elements = await page.evaluate("document.body.querySelectorAll('*').length");
    let t = Date.now(); const plain = await page.content(); row.contentPlainMs = Date.now() - t;
    row.passMs = [];
    for (let k = 0; k < 3; k++) row.passMs.push(await page.evaluate(`(() => { const t = performance.now(); const r = ${MEASURE}(1500); return [Math.round(performance.now() - t), !!r]; })()`));
    t = Date.now(); const measured = await page.content(); row.contentMeasuredMs = Date.now() - t;
    row.boxed = await page.evaluate("document.querySelectorAll('[data-sk-box]').length");
    row.htmlPlain = plain.length; row.htmlMeasured = measured.length;
  } catch (e) { row.error = String(e.message).slice(0, 80); }
  await browser.close().catch(() => undefined);
  rows.push(row);
  console.log(JSON.stringify(row));
  writeFileSync(out, JSON.stringify(rows));
}
process.exit(0);
