// Which capture the product's automatic strategy takes for each URL, and what the measuring pass costs.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...urls] = process.argv.slice(2);
const { fetchStaticPage } = await import(join(root, "src/lib/acquisition/static-fetch.ts"));
const { captureWithLocalBrowser } = await import(join(root, "src/lib/acquisition/rendered-capture.ts"));
const { normalize } = await import(join(root, "src/lib/model/normalize.ts"));
const rows: any[] = [];
const within = <T,>(ms: number, work: Promise<T>): Promise<T> => Promise.race([work, new Promise<T>((_, no) => setTimeout(() => no(Object.assign(new Error("probe timeout"), { code: "probe_timeout" })), ms))]);
for (const u of urls) {
  const url = new URL(u); const row: any = { url: u };
  try {
    const t = Date.now(); const s = await within(20000, fetchStaticPage(url));
    row.static = { ms: Date.now() - t, elements: s.stats.elementCount, shell: s.warnings.some((w: any) => w.code === "spa_shell") };
  } catch (e: any) { row.static = { error: e.code ?? String(e.message).slice(0, 40) }; }
  row.auto = row.static.error === "empty_page" || row.static.shell ? "rendered" : row.static.error ? "fails" : "static";
  row.runs = [];
  for (const measure of [false, true, true, false]) {
    try {
      const t = Date.now(); const snap = await within(40000, captureWithLocalBrowser(url, { measure }));
      const ms = Date.now() - t; const t1 = Date.now(); const doc = normalize(snap); const nms = Date.now() - t1;
      row.runs.push({ measure, ms, renderMs: snap.source.durationMs, htmlBytes: snap.source.bytes, elements: snap.stats.elementCount, layout: !!snap.layout, boxed: doc.nodes.filter((n: any) => n.box).length, nodes: doc.nodes.length, normalizeMs: nms, docBytes: JSON.stringify(doc).length });
    } catch (e: any) { row.runs.push({ measure, error: e.code ?? String(e.message).slice(0, 60) }); }
  }
  rows.push(row);
  const f = (r: any) => r.error ? `ERR ${r.error}` : `${r.ms}ms html ${Math.round(r.htmlBytes / 1024)}KB doc ${Math.round(r.docBytes / 1024)}KB boxed ${r.boxed}/${r.nodes}`;
  console.log(`${u}\n  static: ${JSON.stringify(row.static)} → auto takes ${row.auto}\n  ${row.runs.map((r: any) => `${r.measure ? "measured" : "plain   "} ${f(r)}`).join("\n  ")}`);
  writeFileSync(out, JSON.stringify(rows));
}
process.exit(0);
