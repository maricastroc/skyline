// Throwaway probe, not product code: lay out the static HTML that was already fetched in a headless browser with
// scripts off and only stylesheets loaded, run the measuring pass, and see what the reading gets and what it costs.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...pairs] = process.argv.slice(2);
const { tools } = await import(join(import.meta.dirname, "sig.mts"));
const T = await tools(root);
const { launchLocalBrowser } = await import(join(root, "src/lib/acquisition/local-browser.ts"));
const { USER_AGENT } = await import(join(root, "src/lib/acquisition/safe-fetch.ts"));
const { snapshotFromHtml } = await import(join(root, "src/lib/snapshot/parse-html.ts"));
const src = readFileSync(join(root, "src/lib/acquisition/render-page.ts"), "utf8");
const grab = (name: string) => src.match(new RegExp("const " + name + " = `([\\s\\S]*?)`;"))![1];
const MEASURE = grab("MEASURE_BOXES").replace("${CLEAR_BOXES}", grab("CLEAR_BOXES"));
const GIF = Buffer.from("R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", "base64");
const rows: any[] = [];
for (const pair of pairs) {
  const [id, url, ref] = pair.split("|");
  const row: any = { id, url };
  try {
    let t = Date.now();
    const res = await fetch(url, { headers: { "user-agent": USER_AGENT, accept: "text/html,*/*" }, redirect: "follow", signal: AbortSignal.timeout(20000) });
    const html = await res.text(); const finalUrl = res.url;
    row.staticMs = Date.now() - t; row.htmlKB = Math.round(html.length / 1024);
    const plain = snapshotFromHtml(html, finalUrl, "static");
    row.staticElements = plain.stats.elementCount;
    t = Date.now(); const browser = await launchLocalBrowser(); row.launchMs = Date.now() - t;
    try {
      t = Date.now();
      const page = await browser.newPage();
      await page.setUserAgent(USER_AGENT);
      await page.setViewport({ width: 1440, height: 900 });
      await page.setJavaScriptEnabled(false);
      await page.setRequestInterception(true);
      let css = 0, other = 0;
      page.on("request", (req: any) => {
        const type = req.resourceType();
        if (req.isNavigationRequest() && req.frame() === page.mainFrame()) return void req.respond({ status: 200, contentType: "text/html; charset=utf-8", body: html }).catch(() => undefined);
        if (type === "stylesheet") { css++; return void req.continue().catch(() => undefined); }
        if (type === "image") return void req.respond({ status: 200, contentType: "image/gif", body: GIF }).catch(() => undefined);
        other++; req.abort().catch(() => undefined);
      });
      await page.goto(finalUrl, { waitUntil: "load", timeout: 6000 }).catch(() => undefined);
      row.layoutMs = Date.now() - t; row.stylesheets = css; row.refused = other;
      t = Date.now(); const layout = await page.evaluate(`${MEASURE}(1500)`); row.measureMs = Date.now() - t;
      t = Date.now(); const measured = await page.content(); row.contentMs = Date.now() - t;
      const snap = snapshotFromHtml(measured, finalUrl, "static", { layout });
      row.measuredElements = snap.stats.elementCount;
      row.light = T.governed(snap);
      row.buildings = [T.buildings(T.strip(snap)), T.buildings(snap)];
      row.plainBuildings = T.buildings(plain);
    } finally { t = Date.now(); await browser.close().catch(() => undefined); row.closeMs = Date.now() - t; }
    row.extraMs = row.launchMs + row.layoutMs + row.measureMs + row.contentMs;
    if (ref && existsSync(join(root, ref))) row.full = T.governed(JSON.parse(readFileSync(join(root, ref), "utf8")));
  } catch (e: any) { row.error = String(e.message).slice(0, 90); }
  rows.push(row);
  console.log(`${id.padEnd(11)} static ${row.staticMs}ms ${row.htmlKB}KB · light pass +${row.extraMs}ms (launch ${row.launchMs}, layout ${row.layoutMs}, measure ${row.measureMs}, read ${row.contentMs}) · css ${row.stylesheets} · elements ${row.staticElements}→${row.measuredElements} · buildings ${row.plainBuildings} / ${row.buildings?.join("→")}${row.error ? ` · ERROR ${row.error}` : ""}\n    light: ${row.light ? T.says(row.light) : "-"}\n    full : ${row.full ? T.says(row.full) : "(no reference)"}`);
  writeFileSync(out, JSON.stringify(rows));
}
process.exit(0);
