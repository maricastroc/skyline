// Photographs the product page (/pixel?url=…) once the city is built. usage: node product-shot.mjs <base> <outDir> <tag> <name=url>…
import { createRequire } from "node:module";
import { mkdirSync } from "node:fs";
const require = createRequire(process.cwd() + "/");
const puppeteer = require("puppeteer-core");
const [, , base, outDir, tag, ...pairs] = process.argv;
mkdirSync(outDir, { recursive: true });
const browser = await puppeteer.launch({ executablePath: process.env.CHROME_PATH ?? "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", headless: true, args: ["--use-angle=metal", "--enable-gpu", "--ignore-gpu-blocklist"] });
for (const pair of pairs) {
  const [name, url] = [pair.slice(0, pair.indexOf("=")), pair.slice(pair.indexOf("=") + 1)];
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
  let capture = null;
  page.on("response", async (r) => { if (r.url().endsWith("/api/capture")) { try { const j = await r.json(); capture = j.ok ? { strategy: j.doc.source.strategy, layout: !!j.doc.layout, nodes: j.doc.nodes.length, boxed: j.doc.nodes.filter((n) => n.box).length, acquireMs: j.timings.acquireMs, cached: j.cached } : { error: j.error.code }; } catch {} } });
  try {
    await page.goto(`${base}/pixel?url=${encodeURIComponent(url)}`, { waitUntil: "domcontentloaded" });
    await page.waitForFunction(`document.querySelector('[data-phase="building"]') && !document.querySelector('[data-phase="building"] .sk-loading')`, { timeout: 60000 }).catch(() => undefined);
    for (let k = 0; k < 40 && !capture; k++) await new Promise((r) => setTimeout(r, 1000));
    await new Promise((r) => setTimeout(r, 2500));
    await page.keyboard.press("Escape");
    await page.waitForFunction(`!!document.querySelector('[data-phase="city"]')`, { timeout: 30000 }).catch(() => undefined);
    await new Promise((r) => setTimeout(r, 6000));
    await page.screenshot({ path: `${outDir}/${name}-${tag}.jpg`, type: "jpeg", quality: 84 });
    console.log("shot", name, tag, JSON.stringify(capture), "phase", await page.evaluate(`document.querySelector('[data-phase]')?.getAttribute('data-phase')`));
  } catch (e) { console.log("failed", name, String(e.message).slice(0, 100), JSON.stringify(capture)); }
  await page.close();
}
await browser.close();
process.exit(0);
