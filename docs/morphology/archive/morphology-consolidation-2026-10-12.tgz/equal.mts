// The consolidated code against the previewed subset: same city, piece by piece, on every measured page.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, armc, out, ...specs] = process.argv.slice(2);
const { build } = await import(join(import.meta.dirname, "../eval/arms.mts"));
const C = Object.fromEntries(JSON.parse(readFileSync(armc, "utf8")).map((r: any) => [r.id, r]));
let same = 0; const diff: string[] = []; const rows: any[] = [];
for (const spec of specs) {
  const [set, rest] = spec.split(":"); const [id, file] = rest.split("=");
  const snap = JSON.parse(readFileSync(join(root, file), "utf8"));
  const on = build(snap, "");
  const plain = JSON.parse(JSON.stringify(snap)); delete plain.layout; const strip = (n: any) => { delete n.box; delete n.fontSize; n.children?.forEach(strip); }; strip(plain.root);
  const off = build(plain, "");
  rows.push({ set, id, on: { hash: on.hash, buildings: on.buildings, max: on.max, clashes: on.clashes, fam: on.fam }, off: { hash: off.hash, buildings: off.buildings, max: off.max, clashes: off.clashes, fam: off.fam } });
  if (on.hash === C[id].hash) same++; else diff.push(id);
}
writeFileSync(out, JSON.stringify(rows));
console.log(`consolidated = previewed subset on ${same} of ${specs.length} pages${diff.length ? ` · differs: ${diff.join(", ")}` : ""}`);
const ch = rows.filter((r) => r.on.hash !== r.off.hash);
console.log(`measured vs the same snapshot without boxes: ${rows.length - ch.length} identical, ${ch.length} gain frontages`);
console.log(`  tallest lower than without boxes: ${ch.filter((r) => r.on.max < r.off.max - 0.01).length} · any family smaller: ${ch.filter((r) => Object.entries(r.off.fam).some(([k, v]: any) => (r.on.fam[k] ?? 0) < v)).length} · more overlaps: ${ch.filter((r) => r.on.clashes > r.off.clashes).length}`);
