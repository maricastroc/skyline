import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict, newTrace, blockCentre } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));

export const fileOf = (id: string) => {
  for (const f of [`docs/morphology/recapture/layout/${id}.js.json`, `docs/morphology/recapture/layout-holdout/${id}.js.json`]) if (existsSync(join(root, f))) return join(root, f);
  return null;
};

export function build(snap: any, exp: string) {
  const p = realPage(snap, "none", parseExperiments(exp));
  const trace = newTrace();
  const city = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
  const h = createHash("sha1");
  for (const q of city.parts) h.update(JSON.stringify([q.mesh, q.x, q.y, q.z, q.w, q.h, q.d, q.color, q.surf]));
  const tops: number[] = [];
  const fam: Record<string, number> = {};
  const boxes: Array<{ x0: number; x1: number; z0: number; z1: number; fam: string; t: number }> = [];
  for (const b of trace.buildings) {
    let top = 0;
    let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (let k = b.parts[0]; k < b.parts[1]; k++) {
      const q = city.parts[k];
      top = Math.max(top, q.y + q.h);
      if (q.mesh !== "box" || q.h < 0.45 || q.w < 0.6 || q.d < 0.6 || q.y > 0.9) continue;
      const turned = Math.abs(Math.sin(q.rotY ?? 0)) > 0.5;
      const w = turned ? q.d : q.w, d = turned ? q.w : q.d;
      x0 = Math.min(x0, q.x - w / 2); x1 = Math.max(x1, q.x + w / 2); z0 = Math.min(z0, q.z - d / 2); z1 = Math.max(z1, q.z + d / 2);
    }
    tops.push(top);
    fam[b.P.family] = (fam[b.P.family] ?? 0) + 1;
    if (x0 < x1) boxes.push({ x0, x1, z0, z1, fam: b.P.family, t: b.territory });
  }
  let clashes = 0;
  const clashKinds: Record<string, number> = {};
  for (let i = 0; i < boxes.length; i++)
    for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i], b = boxes[j];
      const ox = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
      const oz = Math.min(a.z1, b.z1) - Math.max(a.z0, b.z0);
      if (ox > 0.15 && oz > 0.15) { clashes++; const k = [a.fam, b.fam].sort().join("+"); clashKinds[k] = (clashKinds[k] ?? 0) + 1; }
    }
  tops.sort((a, b) => a - b);
  const q = (f: number) => tops[Math.min(tops.length - 1, Math.floor(f * tops.length))] ?? 0;
  return { p, trace, city, hash: h.digest("hex"), q50: q(0.5), q90: q(0.9), max: q(1), buildings: tops.length, fam, clashes, clashKinds, parts: city.parts.length };
}

if (process.argv[1]?.endsWith("arms.mts")) {
  const focus: Record<string, [number, number]> = {};
  const lines: string[] = [];
  const say = (s: string) => { console.log(s); lines.push(s); };
  const top = (d: Record<string, number>) => Object.entries(d).sort((x, y) => y[1] - x[1]).slice(0, 6).map(([k, v]) => `${k} ${v}`).join(", ");
  for (const id of ids) {
    const f = fileOf(id);
    if (!f) { say(`${id}: no snapshot`); continue; }
    const snap = JSON.parse(readFileSync(f, "utf8"));
    const a = build(snap, "");
    const b = build(snap, "series");
    const c = build(snap, "ensemble");
    const al = c.trace.alloc!;
    let lots = 0;
    const blocks = new Map<string, number>();
    for (const pc of c.trace.pieces) {
      const t = c.p.plan.territories[pc.territory];
      if (!t.series || pc.comp !== "media" || pc.piece.interior || al.lots[pc.territory] < 8) continue;
      lots += pc.piece.lots;
      if (pc.piece.type === "full") blocks.set(`${pc.block[0]},${pc.block[1]}`, al.lots[pc.territory]);
    }
    const best = [...blocks].sort((x, y) => y[1] - x[1])[0];
    if (best) { const [i, j] = best[0].split(",").map(Number); focus[id] = blockCentre(i, j); }
    say(`\n## ${id} — governed lots ${lots}/256 · series same as base: ${a.hash === b.hash} · ensemble same as base: ${a.hash === c.hash}`);
    for (const [name, r] of [["base", a], ["series", b], ["ensemble", c]] as const)
      say(`  ${name.padEnd(9)} buildings ${String(r.buildings).padStart(3)} · tops q50/q90/max ${r.q50.toFixed(1)}/${r.q90.toFixed(1)}/${r.max.toFixed(1)} · clashes ${r.clashes}${r.clashes ? ` (${top(r.clashKinds)})` : ""} · ${top(r.fam)}`);
    c.p.plan.territories.forEach((t: any, ti: number) => {
      if (!t.series || al.lots[ti] < 4) return;
      const s = t.series;
      const comps = t.mix.map((m: any) => m.comp).join("+");
      say(`  · T${ti} ${String(al.lots[ti]).padStart(3)} lots ${comps.padEnd(18)} “${(t.label ?? t.kind).slice(0, 22)}” ${s.arrangement} ${s.units}u ${Math.round(s.width)}×${Math.round(s.height)} aspect ${(s.height / s.width).toFixed(2)} · ${s.perRow}/row × ${s.rows} · ${s.groups} group(s) · head ×${s.head.toFixed(2)}${al.lots[ti] < 8 || !t.mix.some((m: any) => m.comp === "media") ? "  [not governed]" : ""}`);
    });
  }
  writeFileSync(join(out, "focus.json"), JSON.stringify(focus, null, 1));
  writeFileSync(join(out, "arms.txt"), lines.join("\n") + "\n");
}
