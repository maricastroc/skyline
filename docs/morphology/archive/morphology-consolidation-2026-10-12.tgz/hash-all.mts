import { createHash } from "node:crypto";
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [code, data, out, exp = ""] = process.argv.slice(2);
const { realPage } = await import(join(code, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict } = await import(join(code, "src/lib/pixelcity/kit/district.ts"));
const { parseExperiments } = await import(join(code, "src/lib/semantics/experiments.ts"));
const DIRS = ["docs/real-pages/snapshots", "docs/morphology/all-snapshots", "docs/rendered-capture/snapshots", "docs/morphology/holdout/snapshots", "docs/morphology/holdout2/snapshots", "docs/morphology/recapture/layout", "docs/morphology/recapture/layout-holdout"];
const res: Record<string, string> = {};
let failed = 0;
for (const d of DIRS) {
  let files: string[] = [];
  try { files = readdirSync(join(data, d)).filter((f) => f.endsWith(".json")); } catch { continue; }
  for (const f of files) {
    try {
      const snap = JSON.parse(readFileSync(join(data, d, f), "utf8"));
      if (!snap.root) continue;
      const p = realPage(snap, "none", parseExperiments(exp));
      const city = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7 });
      const h = createHash("sha1");
      for (const q of city.parts) h.update(JSON.stringify([q.mesh, q.x, q.y, q.z, q.w, q.h, q.d, q.color, q.surf, q.rotY]));
      h.update(JSON.stringify(city.signs?.length ?? 0));
      res[`${d}/${f}`] = h.digest("hex");
    } catch (e) { failed++; res[`${d}/${f}`] = `error: ${(e as Error).message.slice(0, 60)}`; }
  }
}
writeFileSync(out, JSON.stringify(res, null, 0));
console.log(`${Object.keys(res).length} snapshots hashed, ${failed} failed → ${out}`);
