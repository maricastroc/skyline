// Which capture the automatic strategy takes: the static fetch only, as acquire() decides it.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...urls] = process.argv.slice(2);
const { fetchStaticPage } = await import(join(root, "src/lib/acquisition/static-fetch.ts"));
const rows: any[] = [];
for (const u of urls) {
  const row: any = { url: u };
  try {
    const t = Date.now();
    const s: any = await Promise.race([fetchStaticPage(new URL(u)), new Promise((_, no) => setTimeout(() => no(Object.assign(new Error("timeout"), { code: "probe_timeout" })), 20000))]);
    Object.assign(row, { ms: Date.now() - t, elements: s.stats.elementCount, shell: s.warnings.some((w: any) => w.code === "spa_shell"), takes: s.warnings.some((w: any) => w.code === "spa_shell") ? "rendered" : "static" });
  } catch (e: any) { Object.assign(row, { error: e.code ?? String(e.message).slice(0, 40), takes: e.code === "empty_page" ? "rendered" : "fails" }); }
  rows.push(row); console.log(JSON.stringify(row));
}
writeFileSync(out, JSON.stringify(rows));
process.exit(0);
