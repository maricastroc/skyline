// What a static capture knows about sizes without a layout engine: pictures that declare width and height in the markup.
import { join } from "node:path";
const [root, ...urls] = process.argv.slice(2);
const { fetchStaticPage } = await import(join(root, "src/lib/acquisition/static-fetch.ts"));
let all = 0, sized = 0, pages = 0, withAny = 0;
for (const u of urls) {
  try {
    const s: any = await Promise.race([fetchStaticPage(new URL(u)), new Promise((_, no) => setTimeout(() => no(new Error("timeout")), 20000))]);
    let n = 0, k = 0;
    const walk = (x: any) => { if (x.tag === "img" || x.image) { n++; if (x.attrs?.width && x.attrs?.height) k++; } x.children.forEach(walk); };
    walk(s.root);
    all += n; sized += k; pages++; if (k) withAny++;
    console.log(`${u.replace("https://", "").slice(0, 36).padEnd(36)} pictures ${String(n).padStart(4)} · with width and height in the markup ${String(k).padStart(4)}`);
  } catch (e: any) { console.log(`${u.replace("https://", "").slice(0, 36).padEnd(36)} ${e.code ?? e.message}`); }
}
console.log(`\n${pages} pages · ${sized} of ${all} pictures declare their size (${Math.round(100 * sized / Math.max(all, 1))}%) · ${withAny} pages have at least one`);
process.exit(0);
