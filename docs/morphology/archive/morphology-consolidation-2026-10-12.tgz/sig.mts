// What the composition would receive from a snapshot: the series of every media territory large enough to be governed.
import { join } from "node:path";
export async function tools(root: string) {
  const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
  const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
  const { generateKitDistrict, newTrace } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
  const strip = (snap: any) => { const c = JSON.parse(JSON.stringify(snap)); delete c.layout; const f = (n: any) => { delete n.box; delete n.fontSize; n.children?.forEach(f); }; f(c.root); return c; };
  const buildings = (snap: any) => { const p = realPage(snap, "none"); const trace = newTrace(); generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace }); return trace.buildings.length; };
  const governed = (snap: any) => {
    const p = realPage(snap, "none"); const lots = allocate(p.plan).lots;
    return p.plan.territories.map((t: any, i: number) => ({ t, lots: lots[i] })).filter((x: any) => x.t.series && x.t.series.kind !== "key" && x.lots >= 8 && x.t.mix.some((m: any) => m.comp === "media")).sort((a: any, b: any) => b.lots - a.lots)
      .map((x: any) => ({ lots: x.lots, kind: x.t.series.kind, perRow: x.t.series.perRow, arrangement: x.t.series.arrangement, w: Math.round(x.t.series.width), h: Math.round(x.t.series.height), units: x.t.series.units }));
  };
  const says = (g: any[]) => g.length ? g.slice(0, 3).map((s) => `${s.lots}l ${s.kind} ${s.w}x${s.h} ${s.perRow}/row ${s.arrangement}`).join(" | ") : "nothing governed";
  return { realPage, strip, buildings, governed, says };
}
