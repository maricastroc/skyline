// What the consolidated path costs after the capture: normalising and planning a measured snapshot against the same snapshot without boxes.
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...specs] = process.argv.slice(2);
const { normalize } = await import(join(root, "src/lib/model/normalize.ts"));
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
const med = (v: number[]) => [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)];
const time = (f: () => void, n = 5) => { const t: number[] = []; for (let k = 0; k < n; k++) { const a = performance.now(); f(); t.push(performance.now() - a); } return med(t); };
const rows: any[] = [];
for (const spec of specs) {
  const [, rest] = spec.split(":"); const [id, file] = rest.split("=");
  const on = JSON.parse(readFileSync(join(root, file), "utf8"));
  const off = JSON.parse(JSON.stringify(on)); delete off.layout; const strip = (n: any) => { delete n.box; delete n.fontSize; n.children?.forEach(strip); }; strip(off.root);
  const pOn = realPage(on, "none"), pOff = realPage(off, "none");
  rows.push({ id,
    normOn: time(() => normalize(on)), normOff: time(() => normalize(off)),
    planOn: time(() => realPage(on, "none")), planOff: time(() => realPage(off, "none")),
    cityOn: time(() => generateKitDistrict(pOn.fp, { profile: pOn.plan, time: "day", seed: 7 }), 3), cityOff: time(() => generateKitDistrict(pOff.fp, { profile: pOff.plan, time: "day", seed: 7 }), 3),
    docOn: JSON.stringify(normalize(on)).length, docOff: JSON.stringify(normalize(off)).length });
}
const col = (k: string) => rows.map((r) => r[k]);
const f = (v: number) => v.toFixed(1);
console.log(`pages ${rows.length}`);
console.log(`normalise  median ${f(med(col("normOff")))} → ${f(med(col("normOn")))} ms · worst ${f(Math.max(...col("normOff")))} → ${f(Math.max(...col("normOn")))} ms`);
console.log(`read+plan  median ${f(med(col("planOff")))} → ${f(med(col("planOn")))} ms · worst ${f(Math.max(...col("planOff")))} → ${f(Math.max(...col("planOn")))} ms · largest increase ${f(Math.max(...rows.map((r) => r.planOn - r.planOff)))} ms (${rows.sort((a, b) => (b.planOn - b.planOff) - (a.planOn - a.planOff))[0].id})`);
console.log(`build city median ${f(med(col("cityOff")))} → ${f(med(col("cityOn")))} ms · worst ${f(Math.max(...col("cityOff")))} → ${f(Math.max(...col("cityOn")))} ms`);
console.log(`document   median ${Math.round(med(col("docOff")) / 1024)} → ${Math.round(med(col("docOn")) / 1024)} KB · median increase ${Math.round(med(rows.map((r) => 100 * (r.docOn - r.docOff) / r.docOff)))}% · worst increase ${Math.round(Math.max(...rows.map((r) => 100 * (r.docOn - r.docOff) / r.docOff)))}%`);
