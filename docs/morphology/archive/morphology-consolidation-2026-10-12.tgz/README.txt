Consolidation of alternative C, 2026-10-12 (branch morphology/consolidation).

equal.mts, equal.json      the consolidated code against the previewed subset and against the same
                           snapshot without boxes, on the 97 measured pages (needs arms.mts and the
                           preview hashes of morphology-decision-2026-10-12.tgz)
auto.mts, auto.json        which capture the automatic strategy takes on 14 live pages
measure-cost.mjs, .json    the measuring pass timed inside the page on the same 14 pages
flow.mts, flow.json/.txt   whole rendered capture with and without the measuring pass (5 pages, twice each)
cost.mts                   normalising, reading and planning with and without boxes on the 97 pages
product-shot.mjs           photographs /pixel?url=… once the city is built (used for sheets/decision/product.jpg)
hash-all.mts               every city on the default path, to compare with the committed code

Integration probes (how the measured items can reach the product):
light.mts, light*.json     throwaway probe: the static HTML laid out with scripts off and only CSS loaded, measured,
                           compared with the full rendered capture (43 live pages)
auto-43.json               what the product's own static fetch does on the same 43 pages
nojs.mts                   the same page measured with scripts on and off (captures of the earlier study)
hints.mts                  how many pictures declare their size in the static markup
