// Existing data: the same page measured with scripts on and with scripts off (captures of the earlier study).
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...ids] = process.argv.slice(2);
const { tools } = await import(join(import.meta.dirname, "sig.mts"));
const T = await tools(root);
for (const id of ids) {
  const f = (m: string) => join(root, `docs/morphology/recapture/layout/${id}.${m}.json`);
  if (!existsSync(f("js")) || !existsSync(f("nojs"))) { console.log(`${id}: no pair`); continue; }
  const a = JSON.parse(readFileSync(f("js"), "utf8")), b = JSON.parse(readFileSync(f("nojs"), "utf8"));
  console.log(`${id.padEnd(11)} elements ${a.stats.elementCount} / ${b.stats.elementCount}\n    scripts on : ${T.says(T.governed(a))}\n    scripts off: ${T.says(T.governed(b))}`);
}
