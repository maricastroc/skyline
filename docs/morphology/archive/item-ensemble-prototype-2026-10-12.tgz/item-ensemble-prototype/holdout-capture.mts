import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const root = process.argv[2];
const { captureWithLocalBrowser } = await import(join(root, "src/lib/acquisition/rendered-capture.ts"));
const DIR = join(root, "docs/morphology/recapture/layout-holdout");
const SERVE = join(root, "docs/rendered-capture/snapshots");
const PAGES: Array<[string, string]> = [
  ["unsplash", "https://unsplash.com/"],
  ["dribbble", "https://dribbble.com/shots/popular"],
  ["letterboxd", "https://letterboxd.com/films/popular/"],
  ["bandcamp", "https://bandcamp.com/discover"],
  ["steam", "https://store.steampowered.com/"],
  ["itch", "https://itch.io/games"],
  ["bbc", "https://www.bbc.com/"],
  ["verge", "https://www.theverge.com/"],
  ["twitch", "https://www.twitch.tv/"],
  ["imdb", "https://www.imdb.com/chart/moviemeter/"],
  ["photopea", "https://www.photopea.com/"],
  ["tldraw", "https://www.tldraw.com/"],
  ["desmos", "https://www.desmos.com/calculator"],
  ["etsy", "https://www.etsy.com/"],
  ["flickr", "https://www.flickr.com/explore"],
  ["producthunt", "https://www.producthunt.com/"],
  ["sqlite", "https://www.sqlite.org/about.html"],
  ["gnu", "https://www.gnu.org/philosophy/free-sw.html"],
  ["lwn", "https://lwn.net/"],
  ["arxiv", "https://arxiv.org/list/cs.AI/recent"],
];
mkdirSync(DIR, { recursive: true });
for (const [id, url] of PAGES) {
  const file = join(DIR, `${id}.js.json`);
  if (existsSync(file)) continue;
  const t0 = Date.now();
  try {
    const snap = await captureWithLocalBrowser(new URL(url), { measure: true, javascript: true });
    writeFileSync(file, JSON.stringify(snap));
    writeFileSync(join(SERVE, `hold-${id}.json`), JSON.stringify(snap));
    console.log(`${id.padEnd(12)} ${String(snap.stats.elementCount).padStart(5)} elements · page ${snap.layout?.width}×${snap.layout?.height} · ${Date.now() - t0} ms`);
  } catch (err) {
    console.log(`${id.padEnd(12)} failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}
console.log("done");
