#!/bin/zsh
# usage: shoot-hold.sh <arm-dir> <exp> <ids for far> -- <ids for flat>
cd "/Users/marianacastro/Desktop/@dev/skyline"
export BASE=http://localhost:3100 FORCE=1
ARM=$1; EXP=$2; shift 2
FAR=(); FLAT=(); mode=far
for a in "$@"; do if [[ $a == "--" ]]; then mode=flat; continue; fi; if [[ $mode == far ]]; then FAR+=("hold-$a"); else FLAT+=("hold-$a"); fi; done
export ALSO="${(j:,:)FAR},${(j:,:)FLAT}"
export VIEW_QUERY="time=day&view=street&focus=0,0&zoom=0.5"
node scripts/morphology/shoot.mjs $ARM $EXP far $FAR 2>&1 | grep -E "^shot|pageerror|Error"
if (( ${#FLAT} )); then
  export VIEW_QUERY="time=day&flat=1&view=street&focus=0,0&zoom=0.5"
  node scripts/morphology/shoot.mjs $ARM $EXP flat $FLAT 2>&1 | grep -E "^shot|pageerror|Error"
fi
echo "done $ARM"
