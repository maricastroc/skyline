import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, features, ...ids] = process.argv.slice(2);
process.chdir(root);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { measureSnapshot, apart } = await import(join(root, "scripts/morphology/measure.ts"));
const { dropItems } = await import(join(root, "scripts/morphology/perturb.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const inner: any[] = JSON.parse(readFileSync(features, "utf8")).inner;
const fileOf = (id: string) => [`docs/morphology/recapture/layout/${id}.js.json`, `docs/morphology/recapture/layout-holdout/${id}.js.json`].map((f) => join(root, f)).find((f) => existsSync(f));
const ARMS = [["base", ""], ["series", "series"], ["ensemble", "ensemble"]] as const;
const lines: string[] = [];
const say = (s = "") => { console.log(s); lines.push(s); };

const rows: any[] = [];
for (const id of ids) {
  const f = fileOf(id);
  if (!f) continue;
  const snap = JSON.parse(readFileSync(f, "utf8"));
  const meta = { id, family: "feed" as const, what: id };
  const r: any = { id, snap };
  for (const [arm, exp] of ARMS) r[arm] = measureSnapshot(snap, meta, parseExperiments(exp));
  rows.push(r);
}
const SIX = ["spotify", "airbnb", "ikea", "pinterest", "apple", "excalidraw"];
say(`pages: ${rows.length}`);
for (const [arm] of ARMS) {
  const ms = rows.map((r) => r[arm]);
  const all = ms.flatMap((x: any, i: number) => ms.slice(i + 1).map((y: any) => apart(x, y)));
  const nn = ms.map((x: any) => ms.filter((y: any) => y !== x).map((y: any) => ({ id: y.id, d: apart(x, y) })).sort((a: any, b: any) => a.d - b.d)[0]);
  const twins = nn.map((n: any, k: number) => ({ a: ms[k].id, ...n })).filter((n: any) => n.d < 0.08);
  say(`${arm.padEnd(9)} all: mean distance ${(all.reduce((s: number, v: number) => s + v, 0) / all.length).toFixed(3)} · near twins (<0.08): ${twins.length} ${twins.map((t: any) => `${t.a}~${t.id}`).join(", ")}`);
  const six = ms.filter((m: any) => SIX.includes(m.id));
  if (six.length > 2) {
    const d6 = six.flatMap((x: any, i: number) => six.slice(i + 1).map((y: any) => ({ p: `${x.id}~${y.id}`, d: apart(x, y) })));
    say(`          the six media pages: mean ${(d6.reduce((s: number, v: any) => s + v.d, 0) / d6.length).toFixed(3)} · closest ${d6.sort((a: any, b: any) => a.d - b.d).slice(0, 4).map((x: any) => `${x.p} ${x.d.toFixed(2)}`).join(", ")}`);
  }
}
say();
say("how far each city moves from today (series · ensemble):");
say("  " + rows.map((r) => `${r.id} ${apart(r.base, r.series).toFixed(2)}·${apart(r.base, r.ensemble).toFixed(2)}`).join("  "));
say();
say("tops q50/q90/max and buildings, today → series → ensemble (pages that change):");
for (const r of rows) {
  if (apart(r.base, r.series) === 0 && apart(r.base, r.ensemble) === 0) continue;
  const f = (m: any) => `${m.q50.toFixed(1)}/${m.q90.toFixed(1)}/${m.max.toFixed(1)} (${m.buildings})`;
  say(`  ${r.id.padEnd(12)} ${f(r.base)} → ${f(r.series)} → ${f(r.ensemble)} · open ${Math.round(r.base.open * 100)}%/${Math.round(r.series.open * 100)}%/${Math.round(r.ensemble.open * 100)}%`);
}

const rank = (v: number[]) => { const s = v.map((x, i) => [x, i] as const).sort((a, b) => a[0] - b[0]); const r = new Array(v.length).fill(0); for (let i = 0; i < s.length; ) { let j = i; while (j < s.length && s[j][0] === s[i][0]) j++; for (let k = i; k < j; k++) r[s[k][1]] = (i + j - 1) / 2; i = j; } return r; };
const spearman = (x: number[], y: number[]) => { const a = rank(x), b = rank(y); const ma = a.reduce((s, v) => s + v, 0) / a.length, mb = b.reduce((s, v) => s + v, 0) / b.length; let n = 0, da = 0, db = 0; for (let i = 0; i < a.length; i++) { n += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; } return da && db ? n / Math.sqrt(da * db) : 0; };
const feat: Record<string, (r: any) => number> = { "items per row": (r) => Math.min(r.perRow, 10), "item shape": (r) => (r.items >= 4 && r.itemH > 0 ? Math.log2(Math.max(r.itemW, 1) / r.itemH) : 0), "largest heading": (r) => r.head };
if (rows.some((r) => inner.find((x) => x.id === r.id))) {
  say();
  say("city distance against page difference (Spearman over all pairs), today → series → ensemble:");
  for (const [name, f] of Object.entries(feat)) {
    const line: string[] = [];
    for (const [arm] of ARMS) {
      const px: number[] = [], cy: number[] = [];
      for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
        const a = inner.find((x) => x.id === rows[i].id), b = inner.find((x) => x.id === rows[j].id);
        if (!a || !b) continue;
        px.push(Math.abs(f(a) - f(b)));
        cy.push(apart(rows[i][arm], rows[j][arm]));
      }
      line.push(spearman(px, cy).toFixed(2));
    }
    say(`  ${name.padEnd(18)} ${line.join(" → ")}`);
  }
}

say();
say("stability of the ensemble arm with one item fewer in the main list:");
const cls = (s: any) => (s.arrangement === "tiles" ? "keys" : s.height / s.width >= 1.5 ? "portrait" : s.height / s.width < 0.75 ? "landscape" : "regular");
const sig = (p: any) => { const a = allocate(p.plan); return p.plan.territories.map((t: any, i: number) => ({ t, lots: a.lots[i] })).filter((x: any) => x.t.series && x.lots >= 8 && x.t.mix.some((m: any) => m.comp === "media")).map((x: any) => `${x.t.series.arrangement}/${Math.min(Math.max(x.t.series.perRow, 2), 8)}/${cls(x.t.series)}`).sort().join(" "); };
for (const r of rows) {
  const p0 = realPage(r.snap, "none", parseExperiments("ensemble"));
  if (!sig(p0)) continue;
  const less = dropItems(r.snap, 1);
  if (!less) { say(`  ${r.id.padEnd(12)} governed: ${sig(p0)} · no main list to edit`); continue; }
  const p1 = realPage(less, "none", parseExperiments("ensemble"));
  const meta = { id: r.id, family: "feed" as const, what: r.id };
  say(`  ${r.id.padEnd(12)} governed: ${sig(p0)} · one fewer: ${sig(p1) === sig(p0) ? "same" : sig(p1)} · city moves ${apart(r.ensemble, measureSnapshot(less, meta, parseExperiments("ensemble"))).toFixed(2)} (today ${apart(r.base, measureSnapshot(less, meta, parseExperiments(""))).toFixed(2)})`);
}
writeFileSync(join(out, `measure3-${ids.length}.txt`), lines.join("\n") + "\n");
