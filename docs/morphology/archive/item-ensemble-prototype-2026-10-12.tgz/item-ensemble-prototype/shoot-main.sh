#!/bin/zsh
# usage: shoot-main.sh <arm-dir> <exp>
cd "/Users/marianacastro/Desktop/@dev/skyline"
export BASE=http://localhost:3100 FORCE=1
ARM=$1; EXP=$2
CH="spotify airbnb ikea pinterest apple excalidraw guardian craigslist github"
CT="hn pg lobsters pydocs wikipedia mdn govuk linear vercel mastodon rayso youtube portfolio"
ids() { for i in ${=1}; do printf 'lay-%s ' $i; done; }
export ALSO="$(ids "$CH $CT" | tr ' ' ',' | sed 's/,$//')"
export VIEW_QUERY="time=day&view=street&focus=0,0&zoom=0.5"
node scripts/morphology/shoot.mjs $ARM $EXP far $(ids "$CH $CT") 2>&1 | grep -E "^shot|pageerror|Error"
export VIEW_QUERY="time=day&flat=1&view=street&focus=0,0&zoom=0.5"
node scripts/morphology/shoot.mjs $ARM $EXP flat $(ids "$CH hn pg pydocs") 2>&1 | grep -E "^shot|pageerror|Error"
for pair in "spotify:-28.2,-28.2" "airbnb:9.4,-28.2" "ikea:-28.2,-28.2" "pinterest:-28.2,-28.2" "excalidraw:-28.2,-28.2" "guardian:9.4,-9.4" "craigslist:-9.4,-9.4"; do
  id="${pair%%:*}"; f="${pair#*:}"
  export VIEW_QUERY="time=day&view=street&focus=$f&zoom=1.25"
  node scripts/morphology/shoot.mjs $ARM $EXP close lay-$id 2>&1 | grep -E "^shot|pageerror|Error"
done
echo "done $ARM"
