import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const root = process.argv[2];
const { captureWithLocalBrowser } = await import(join(root, "src/lib/acquisition/rendered-capture.ts"));
const DIR = join(root, "docs/morphology/recapture/layout-holdout");
const SERVE = join(root, "docs/rendered-capture/snapshots");
const PAGES: Array<[string, string]> = [
  ["openlibrary", "https://openlibrary.org/"],
  ["toscrape", "https://books.toscrape.com/"],
  ["gog", "https://www.gog.com/en/games"],
  ["applemusic", "https://music.apple.com/us/new"],
  ["soundcloud", "https://soundcloud.com/discover"],
  ["vimeo", "https://vimeo.com/watch"],
  ["behance", "https://www.behance.net/"],
  ["pexels", "https://www.pexels.com/"],
  ["commons", "https://commons.wikimedia.org/wiki/Commons:Featured_pictures"],
  ["ted", "https://www.ted.com/talks"],
  ["npr", "https://www.npr.org/"],
  ["archive", "https://archive.org/details/movies"],
  ["moma", "https://www.moma.org/collection/"],
  ["nasa", "https://www.nasa.gov/"],
];
mkdirSync(DIR, { recursive: true });
for (const [id, url] of PAGES) {
  const file = join(DIR, `${id}.js.json`);
  if (existsSync(file)) continue;
  const t0 = Date.now();
  try {
    const snap = await captureWithLocalBrowser(new URL(url), { measure: true, javascript: true });
    writeFileSync(file, JSON.stringify(snap));
    writeFileSync(join(SERVE, `hold-${id}.json`), JSON.stringify(snap));
    console.log(`${id.padEnd(12)} ${String(snap.stats.elementCount).padStart(5)} elements · page ${snap.layout?.width}×${snap.layout?.height} · ${Date.now() - t0} ms`);
  } catch (err) {
    console.log(`${id.padEnd(12)} failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}
console.log("done");
