import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const fileOf = (id: string) => [`docs/morphology/recapture/layout/${id}.js.json`, `docs/morphology/recapture/layout-holdout/${id}.js.json`].map((f) => join(root, f)).find((f) => existsSync(f));
const med = (v: number[]) => (v.length ? [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] : 0);
for (const id of ids) {
  const f = fileOf(id);
  if (!f) continue;
  const p = realPage(JSON.parse(readFileSync(f, "utf8")), "none", parseExperiments("ensemble"));
  const a = allocate(p.plan);
  const nodes = p.doc.nodes;
  p.plan.territories.forEach((t: any, i: number) => {
    if (a.lots[i] < 8 || !t.mix.some((m: any) => m.comp === "media" || m.comp === "grid")) return;
    const ids2 = t.scope ? scopeOf(nodes, t.scope.roots, t.scope.excluded) : [];
    const imgs = ids2.filter((k: number) => nodes[k].role === "image");
    const boxed = imgs.filter((k: number) => nodes[k].box && !nodes[k].cluster);
    const big = boxed.filter((k: number) => nodes[k].box[2] >= 24 && nodes[k].box[3] >= 24);
    const clustered = ids2.filter((k: number) => nodes[k].cluster).length;
    const lines = new Set(big.map((k: number) => Math.round(nodes[k].box[1] / 40)));
    console.log(`${id.padEnd(12)} T${i} ${String(a.lots[i]).padStart(3)} lots ${t.mix.map((m: any) => m.comp).join("+").padEnd(16)} series ${t.series ? `${t.series.arrangement} ${Math.round(t.series.width)}×${Math.round(t.series.height)} ${t.series.perRow}/row` : "none"} · images ${imgs.length}, boxed ${boxed.length}, ≥24px ${big.length} (median ${med(big.map((k: number) => nodes[k].box[2]))}×${med(big.map((k: number) => nodes[k].box[3]))}, on ${lines.size} lines) · clusters in scope ${clustered} · metrics images ${t.metrics.images}`);
  });
}
