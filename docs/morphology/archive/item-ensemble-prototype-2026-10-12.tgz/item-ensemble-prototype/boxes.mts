import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
for (const id of ids) {
  const p = realPage(JSON.parse(readFileSync(join(root, `docs/morphology/recapture/layout-holdout/${id}.js.json`), "utf8")));
  const imgs = p.doc.nodes.filter((n: any) => n.role === "image");
  const boxed = imgs.filter((n: any) => n.box);
  const sizes: Record<string, number> = {};
  for (const n of boxed) { const k = `${Math.round(n.box[2])}×${Math.round(n.box[3])}`; sizes[k] = (sizes[k] ?? 0) + 1; }
  const xs: Record<string, number> = {};
  for (const n of boxed.filter((n: any) => n.box[2] >= 24)) { const k = String(Math.round(n.box[0] / 10) * 10); xs[k] = (xs[k] ?? 0) + 1; }
  const top = (d: Record<string, number>, n = 8) => Object.entries(d).sort((a, b) => b[1] - a[1]).slice(0, n).map(([k, v]) => `${k} (${v})`).join(", ");
  console.log(`${id}: images ${imgs.length}, boxed ${boxed.length} · sizes: ${top(sizes)} · left edges: ${top(xs, 10)}`);
}
