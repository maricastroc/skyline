#!/bin/zsh
# ends a shoot.mjs process whose browser has already gone (it hangs on close); stops when no shooting script is left
typeset -A lone
idle=0
while true; do
  sleep 6
  pids=($(pgrep -f "node scripts/morphology/shoot.mjs"))
  if (( ${#pids} == 0 )); then
    idle=$((idle + 1))
    if (( idle > 8 )) && ! pgrep -f "shoot-(main|hold).sh" >/dev/null; then break; fi
    continue
  fi
  idle=0
  for p in $pids; do
    if pgrep -P $p >/dev/null 2>&1; then lone[$p]=0; continue; fi
    lone[$p]=$(( ${lone[$p]:-0} + 1 ))
    if (( ${lone[$p]} >= 4 )); then kill $p 2>/dev/null && echo "$(date +%T) ended stuck shoot process $p"; fi
  done
done
echo "watchdog done"
