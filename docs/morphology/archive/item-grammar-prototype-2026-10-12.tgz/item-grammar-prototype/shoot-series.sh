#!/bin/zsh
cd "/Users/marianacastro/Desktop/@dev/skyline"
export BASE=http://localhost:3100 FORCE=1
CH="spotify airbnb ikea pinterest apple excalidraw guardian craigslist github"
CT="hn pg lobsters pydocs wikipedia"
ids() { for i in ${=1}; do printf 'lay-%s ' $i; done; }
export ALSO="$(ids "$CH $CT" | tr ' ' ',' | sed 's/,$//')"
export VIEW_QUERY="time=day&view=street&focus=0,0&zoom=0.5"
node scripts/morphology/shoot.mjs ser-proto series far $(ids "$CH $CT") 2>&1 | grep -cE "^shot"
export VIEW_QUERY="time=day&flat=1&view=street&focus=0,0&zoom=0.5"
node scripts/morphology/shoot.mjs ser-base none flat $(ids "spotify airbnb ikea pinterest excalidraw guardian") 2>&1 | grep -cE "^shot"
node scripts/morphology/shoot.mjs ser-proto series flat $(ids "spotify airbnb ikea pinterest excalidraw guardian") 2>&1 | grep -cE "^shot"
for pair in "spotify:-28.2,-28.2" "airbnb:9.4,-28.2" "ikea:-28.2,-28.2" "pinterest:-28.2,-28.2" "excalidraw:-28.2,-28.2" "guardian:9.4,-9.4" "craigslist:-9.4,-9.4"; do
  id="${pair%%:*}"; f="${pair#*:}"
  export VIEW_QUERY="time=day&view=street&focus=$f&zoom=1.25"
  node scripts/morphology/shoot.mjs ser-base none close lay-$id 2>&1 | grep -cE "^shot"
  node scripts/morphology/shoot.mjs ser-proto series close lay-$id 2>&1 | grep -cE "^shot"
done
