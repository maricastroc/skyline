import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict, newTrace, blockCentre } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));

export function build(snap: any, exp: string) {
  const p = realPage(snap, "none", parseExperiments(exp));
  const trace = newTrace();
  const city = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
  const h = createHash("sha1");
  for (const q of city.parts) h.update(JSON.stringify([q.mesh, q.x, q.y, q.z, q.w, q.h, q.d, q.color, q.surf]));
  const tops: number[] = [];
  const fam: Record<string, number> = {};
  for (const b of trace.buildings) {
    let top = 0;
    for (let k = b.parts[0]; k < b.parts[1]; k++) top = Math.max(top, city.parts[k].y + city.parts[k].h);
    tops.push(top);
    fam[b.P.family] = (fam[b.P.family] ?? 0) + 1;
  }
  tops.sort((a, b) => a - b);
  const q = (f: number) => tops[Math.min(tops.length - 1, Math.floor(f * tops.length))] ?? 0;
  return { p, trace, city, hash: h.digest("hex"), q50: q(0.5), q90: q(0.9), max: q(1), buildings: tops.length, fam };
}

if (process.argv[1]?.endsWith("series-arms.mts")) {
  const focus: Record<string, [number, number]> = {};
  console.log("page".padEnd(11), "same city", "governed lots", "arrangements".padEnd(26), "buildings", "tops q50/q90/max: today → prototype".padEnd(40), "families in the prototype");
  for (const id of ids) {
    const f = join(dir, `${id}.js.json`);
    if (!existsSync(f)) continue;
    const snap = JSON.parse(readFileSync(f, "utf8"));
    const a = build(snap, "");
    const b = build(snap, "series");
    const al = b.trace.alloc!;
    let lots = 0;
    const arr: Record<string, number> = {};
    const blocks = new Map<string, number>();
    for (const pc of b.trace.pieces) {
      const t = b.p.plan.territories[pc.territory];
      if (!t.series || (pc.comp !== "media" && pc.comp !== "grid") || pc.piece.interior) continue;
      lots += pc.piece.lots;
      arr[t.series.arrangement] = (arr[t.series.arrangement] ?? 0) + pc.piece.lots;
      if (pc.piece.type === "full") blocks.set(`${pc.block[0]},${pc.block[1]}`, al.lots[pc.territory]);
    }
    const best = [...blocks].sort((x, y) => y[1] - x[1])[0];
    if (best) {
      const [i, j] = best[0].split(",").map(Number);
      focus[id] = blockCentre(i, j);
    }
    const top = (d: Record<string, number>) => Object.entries(d).sort((x, y) => y[1] - x[1]).slice(0, 4).map(([k, v]) => `${k} ${v}`).join(", ");
    console.log(id.padEnd(11), String(a.hash === b.hash).padStart(9), String(lots).padStart(13), Object.entries(arr).map(([k, v]) => `${k} ${v}`).join(", ").padEnd(26), `${a.buildings}→${b.buildings}`.padStart(9), `${a.q50.toFixed(1)}/${a.q90.toFixed(1)}/${a.max.toFixed(1)} → ${b.q50.toFixed(1)}/${b.q90.toFixed(1)}/${b.max.toFixed(1)}`.padEnd(40), top(b.fam));
  }
  writeFileSync(join(dir, "series-focus.json"), JSON.stringify(focus));
}
