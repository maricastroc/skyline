import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
process.chdir(root);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { measureSnapshot, apart } = await import(join(root, "scripts/morphology/measure.ts"));
const { dropItems, keepItems } = await import(join(root, "scripts/morphology/perturb.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const inner: any[] = JSON.parse(readFileSync(join(dir, "evaluation.json"), "utf8")).inner;

const rows: any[] = [];
for (const id of ids) {
  const f = join(dir, `${id}.js.json`);
  if (!existsSync(f)) continue;
  const snap = JSON.parse(readFileSync(f, "utf8"));
  const meta = { id, family: "feed" as const, what: id };
  rows.push({ id, snap, base: measureSnapshot(snap, meta, parseExperiments("")), proto: measureSnapshot(snap, meta, parseExperiments("series")) });
}
const SIX = ["spotify", "airbnb", "ikea", "pinterest", "apple", "excalidraw"];
for (const arm of ["base", "proto"] as const) {
  const ms = rows.map((r) => r[arm]);
  const all = ms.flatMap((x: any, i: number) => ms.slice(i + 1).map((y: any) => apart(x, y)));
  const nn = ms.map((x: any) => ms.filter((y: any) => y !== x).map((y: any) => ({ id: y.id, d: apart(x, y) })).sort((a: any, b: any) => a.d - b.d)[0]);
  const twins = nn.map((n: any, k: number) => ({ a: ms[k].id, ...n })).filter((n: any) => n.d < 0.08);
  console.log(`${arm.padEnd(6)} all 22: mean distance ${(all.reduce((s: number, v: number) => s + v, 0) / all.length).toFixed(3)} · near twins (<0.08): ${twins.length} ${twins.map((t: any) => `${t.a}~${t.id}`).join(", ")}`);
  const six = ms.filter((m: any) => SIX.includes(m.id));
  const d6 = six.flatMap((x: any, i: number) => six.slice(i + 1).map((y: any) => ({ p: `${x.id}~${y.id}`, d: apart(x, y) })));
  console.log(`       the six media pages: mean ${(d6.reduce((s: number, v: any) => s + v.d, 0) / d6.length).toFixed(3)} · closest ${d6.sort((a: any, b: any) => a.d - b.d).slice(0, 4).map((x: any) => `${x.p} ${x.d.toFixed(2)}`).join(", ")}`);
}
console.log("\nhow far each city moves:", rows.map((r) => `${r.id} ${apart(r.base, r.proto).toFixed(2)}`).join(" · "));
console.log("open land, today → prototype:", rows.filter((r) => apart(r.base, r.proto) > 0).map((r) => `${r.id} ${Math.round(r.base.open * 100)}%→${Math.round(r.proto.open * 100)}%`).join(" · "));

const rank = (v: number[]) => { const s = v.map((x, i) => [x, i] as const).sort((a, b) => a[0] - b[0]); const r = new Array(v.length).fill(0); for (let i = 0; i < s.length; ) { let j = i; while (j < s.length && s[j][0] === s[i][0]) j++; for (let k = i; k < j; k++) r[s[k][1]] = (i + j - 1) / 2; i = j; } return r; };
const spearman = (x: number[], y: number[]) => { const a = rank(x), b = rank(y); const ma = a.reduce((s, v) => s + v, 0) / a.length, mb = b.reduce((s, v) => s + v, 0) / b.length; let n = 0, da = 0, db = 0; for (let i = 0; i < a.length; i++) { n += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; } return da && db ? n / Math.sqrt(da * db) : 0; };
const feat: Record<string, (r: any) => number> = { "items per row": (r) => Math.min(r.perRow, 10), "item shape": (r) => (r.items >= 4 && r.itemH > 0 ? Math.log2(Math.max(r.itemW, 1) / r.itemH) : 0), "largest heading": (r) => r.head };
console.log("\ncity distance against page difference (Spearman, all pairs):");
for (const [name, f] of Object.entries(feat)) {
  const line: string[] = [];
  for (const arm of ["base", "proto"] as const) {
    const px: number[] = [], cy: number[] = [];
    for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
      const a = inner.find((x) => x.id === rows[i].id), b = inner.find((x) => x.id === rows[j].id);
      if (!a || !b) continue;
      px.push(Math.abs(f(a) - f(b)));
      cy.push(apart(rows[i][arm], rows[j][arm]));
    }
    line.push(spearman(px, cy).toFixed(2));
  }
  console.log(`  ${name.padEnd(18)} today ${line[0]} → prototype ${line[1]}`);
}

console.log("\nstability of the prototype: one item fewer, and half of the items");
for (const r of rows) {
  const p0 = realPage(r.snap, "none", parseExperiments("series"));
  const a0 = allocate(p0.plan);
  const gov = p0.plan.territories.map((t: any, i: number) => ({ t, lots: a0.lots[i] })).filter((x: any) => x.t.series && x.lots >= 8 && x.t.mix.some((m: any) => m.comp === "media" || m.comp === "grid"));
  if (!gov.length) continue;
  const sig = (p: any) => { const a = allocate(p.plan); return p.plan.territories.map((t: any, i: number) => ({ t, lots: a.lots[i] })).filter((x: any) => x.t.series && x.lots >= 8).map((x: any) => `${x.t.series.arrangement}/${x.t.series.perRow}`).sort().join(" "); };
  const less = dropItems(r.snap, 1);
  const half = keepItems ? null : null;
  const notes = [`governed: ${sig(p0)}`];
  if (less) {
    const p1 = realPage(less, "none", parseExperiments("series"));
    notes.push(`one fewer: ${sig(p1) === sig(p0) ? "same arrangements" : sig(p1)} · city moves ${apart(r.proto, measureSnapshot(less, { id: r.id, family: "feed", what: r.id }, parseExperiments("series"))).toFixed(2)} (today ${apart(r.base, measureSnapshot(less, { id: r.id, family: "feed", what: r.id }, parseExperiments(""))).toFixed(2)})`);
  } else notes.push("no main list to edit");
  console.log(`  ${r.id.padEnd(11)} ${notes.join(" · ")}`);
}
