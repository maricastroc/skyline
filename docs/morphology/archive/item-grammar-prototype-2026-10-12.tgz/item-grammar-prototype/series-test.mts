import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { seriesOf } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
for (const id of ids) {
  const f = join(dir, `${id}.js.json`);
  if (!existsSync(f)) continue;
  const p = realPage(JSON.parse(readFileSync(f, "utf8")));
  const a = allocate(p.plan);
  p.plan.territories.forEach((t: any, i: number) => {
    const lots = a.lots[i] ?? 0;
    if (lots < 8 || !t.scope) return;
    const comps = t.mix.map((m: any) => m.comp);
    if (!comps.includes("media") && !comps.includes("grid")) return;
    const s = seriesOf(p.doc, t.scope);
    console.log(id.padEnd(11), `${lots}`.padStart(4), comps.join("+").padEnd(18), (t.label ?? t.kind).slice(0, 22).padEnd(23), s ? `${s.arrangement.padEnd(5)} ${s.units} units ${s.width}×${s.height} · ${s.perRow}/row × ${s.rows} · ${s.groups} group(s) · head ×${s.head.toFixed(2)} · heights ${Math.min(...s.sizes.map((x: number[]) => x[1]))}–${Math.max(...s.sizes.map((x: number[]) => x[1]))}` : "— no series: today's recipe");
  });
}
