import { generateKitDistrict, newTrace } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import { planChange, raster } from "./geometry";
import { pages } from "./stability";

const only = process.argv.slice(2);
const all = pages();
let n = 0;
let inert = 0;
let tall = 0;
for (const pg of all) {
  if (only.length && !only.includes(pg.id)) continue;
  const run = (flags: string) => {
    const p = realPage(pg.snap, "none", parseExperiments(flags));
    const trace = newTrace();
    const c = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, flat: true, trace });
    return { p, trace, c, r: raster(c.parts) };
  };
  const a = run("");
  const b = run("p-l");
  const L = b.trace.layout!;
  const par = b.trace.pieces.filter((x) => x.comp === "parcelled" && !x.piece.interior);
  if (par.reduce((s, x) => s + x.piece.lots, 0) < 64) continue;
  const heads = par.filter((x) => (L.briefs.get(x.piece)?.dominants ?? 0) > 0).length;
  const groups = new Set(par.map((x) => x.territory)).size ? [...new Set(par.map((x) => x.territory))].reduce((s, ti) => s + L.territories[ti].groups.length, 0) : 0;
  const d = planChange(a.r, b.r);
  const corners = (t: typeof a.trace) => t.buildings.filter((x) => x.comp === "parcelled" && x.P.family === "corner").length;
  const rows = (t: typeof a.trace) => t.buildings.filter((x) => x.comp === "parcelled" && x.P.family === "rows").length;
  n++;
  if (heads <= 1) inert++;
  if (heads >= 0.7 * par.length) tall++;
  if (only.length || heads > 1) console.log(`${pg.id.padEnd(24)} parcelled pieces ${String(par.length).padStart(3)} · groups ${String(groups).padStart(3)} · heads ${String(heads).padStart(3)} · corners ${corners(a.trace)} → ${corners(b.trace)} · rows ${rows(a.trace)} → ${rows(b.trace)} · buildings ${a.trace.buildings.length} → ${b.trace.buildings.length} · plan changed any ${(d.any * 100).toFixed(1)}% built/open ${(d.foot * 100).toFixed(1)}%`);
}
console.log(`\n${n} pages with a quarter or more of parcelled land · one head or none (city unchanged or one building taller): ${inert} · a head on 70% or more of the pieces (uniform): ${tall}`);
