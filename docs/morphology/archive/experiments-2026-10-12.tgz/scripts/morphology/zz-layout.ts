import { generateKitDistrict, newTrace } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import { pages } from "./stability";

const only = process.argv.slice(2);
const rows: string[] = [];
for (const pg of pages()) {
  if (only.length && !only.includes(pg.id)) continue;
  const p = realPage(pg.snap, "none", parseExperiments("census"));
  const trace = newTrace();
  generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, flat: true, trace });
  const L = trace.layout!;
  let lots = 0;
  let groups = 0;
  let clusters = 0;
  let ensembles = 0;
  let pieces = 0;
  let grouped = 0;
  const per: string[] = [];
  p.plan.territories.forEach((t, ti) => {
    const mine = trace.pieces.filter((x) => x.territory === ti && x.comp === "parcelled" && !x.piece.interior);
    if (!mine.length) return;
    const l = mine.reduce((s, x) => s + x.piece.lots, 0);
    const g = L.territories[ti].groups.length;
    const f = trace.frontage.find((x) => x.territory === ti);
    const e = new Set(mine.map((x) => L.briefs.get(x.piece)?.ensemble)).size;
    lots += l;
    groups += g;
    clusters += f?.clusters ?? (g ? 1 : 0);
    ensembles += g ? e : 0;
    pieces += mine.length;
    if (g >= 2) grouped++;
    if (only.length) per.push(`    ${t.kind} “${(t.label ?? "").slice(0, 24)}” lots ${l} pieces ${mine.length} items ${L.territories[ti].counts.items} groups ${g} · frontage clusters ${f?.clusters ?? "-"} (passages ${f?.passages ?? 0}) · layout ensembles ${e}`);
  });
  rows.push(`${pg.id.padEnd(24)} elements ${String(pg.snap.stats.elementCount).padStart(5)} · parcelled lots ${String(lots).padStart(3)} pieces ${String(pieces).padStart(3)} · groups ${String(groups).padStart(3)} in ${grouped} grouped territories · frontage clusters ${String(clusters).padStart(3)} · layout ensembles ${String(ensembles).padStart(3)}`);
  rows.push(...per);
}
console.log(rows.join("\n"));
