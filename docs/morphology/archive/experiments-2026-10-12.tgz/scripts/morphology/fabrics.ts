import { existsSync, readFileSync } from "node:fs";
import type { NNode } from "../../src/lib/model/types";
import { listAnatomy, listSays } from "../../src/lib/pixelcity/kit/plan";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { contentImages } from "../../src/lib/semantics/hygiene";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import type { DomSnapshot } from "../../src/lib/snapshot/types";
import { BENCH, EXTRA, holdoutFile } from "./dataset";
import { HOLDOUT, HOLDOUT_B } from "./holdout-set";

const exp = parseExperiments("coverage,lists2,transient,item-form3,avatars");
const files = [
  ...[...BENCH, ...EXTRA].map((b) => ({ id: b.id, file: b.file })),
  ...HOLDOUT.map((h) => ({ id: h.id, file: holdoutFile(h.id) })),
  ...HOLDOUT_B.map((h) => ({ id: h.id, file: holdoutFile(h.id, "holdout2") })),
].filter((f) => existsSync(f.file));

const q = (xs: number[], f: number) => [...xs].sort((a, b) => a - b)[Math.min(xs.length - 1, Math.floor(f * xs.length))] ?? 0;
const cv = (xs: number[]) => {
  const m = xs.reduce((a, b) => a + b, 0) / (xs.length || 1);
  return m ? Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length || 1)) / m : 0;
};
const rows: Array<Record<string, number | string>> = [];
for (const f of files) {
  const snap = JSON.parse(readFileSync(f.file, "utf8")) as DomSnapshot;
  if (snap.stats.elementCount < 60 || snap.stats.elementCount > 12000) continue;
  const p = realPage(snap, "none", exp);
  const nodes = p.doc.nodes;
  for (const t of p.plan.territories) {
    if (t.weight < 0.1 || t.region < 0) continue;
    const comp = [...t.mix].sort((a, b) => b.share - a.share)[0].comp;
    const r = p.sem.regions[t.region];
    const root = nodes[r.node];
    const sub = nodes.slice(r.node, root.end);
    const controls = sub.filter((n: NNode) => n.role === "control" || n.role === "button");
    const groups = sub.filter((n: NNode) => n.children.filter((c) => nodes[c].role === "control" || nodes[c].role === "button" || nodes[c].controls > 0).length >= 3).length;
    const seen = r.items.filter((c) => !nodes[c].cluster);
    const sizes = seen.map((c) => nodes[c].chars + 150 * contentImages(nodes[c]));
    const a = listAnatomy(p.doc, r.items);
    rows.push({ page: f.id, kind: t.kind, comp, land: t.weight, items: a.count, chars: a.chars, pictured: a.pictured, says: listSays(p.doc, r.items), spread: cv(sizes), controls: controls.length, groups, headings: sub.filter((n: NNode) => n.heading).length, depth: Math.max(...sub.map((n: NNode) => n.level)) - root.level });
  }
}
const num = (r: Record<string, number | string>, k: string) => r[k] as number;
for (const comp of ["grid", "interactive", "media", "parcelled", "continuous", "archive"]) {
  const rs = rows.filter((r) => r.comp === comp);
  if (!rs.length) continue;
  const line = (k: string, d = 0) => `${k} ${q(rs.map((r) => num(r, k)), 0.1).toFixed(d)} / ${q(rs.map((r) => num(r, k)), 0.5).toFixed(d)} / ${q(rs.map((r) => num(r, k)), 0.9).toFixed(d)}`;
  console.log(`\n${comp}: ${rs.length} territories of 10% or more, in ${new Set(rs.map((r) => r.page)).size} pages (p10 / median / p90)`);
  console.log(`  ${line("items")} · ${line("chars")} · ${line("says")} · ${line("pictured", 2)} · size spread ${line("spread", 2)}`);
  console.log(`  ${line("controls")} · control ${line("groups")} · ${line("headings")} · ${line("depth")}`);
  if (comp === "grid" || comp === "interactive")
    for (const r of rs.sort((x, y) => num(y, "land") - num(x, "land")).slice(0, 14))
      console.log(`    ${String(r.page).padEnd(22)} ${String(r.kind).padEnd(9)} ${`${Math.round(num(r, "land") * 100)}%`.padStart(4)} · ${String(r.items).padStart(3)} items, ${String(Math.round(num(r, "chars"))).padStart(4)} chars, ${Math.round(num(r, "pictured") * 100)}% pictured, spread ${num(r, "spread").toFixed(2)} · ${String(r.controls).padStart(3)} controls in ${r.groups} groups, ${r.headings} headings`);
}
