import { existsSync, readFileSync } from "node:fs";
import { listAnatomy, listSays, mixFor, SAYS_SOMETHING } from "../../src/lib/pixelcity/kit/plan";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import type { DomSnapshot } from "../../src/lib/snapshot/types";
import { BENCH, EXTRA, holdoutFile } from "./dataset";
import { HOLDOUT, HOLDOUT_B } from "./holdout-set";

const sets = process.argv.slice(2);
const exp = parseExperiments("coverage,lists2,transient");

const pages: Array<{ id: string; file: string; expect: string }> = [];
if (!sets.length || sets.includes("bench")) for (const b of [...BENCH, ...EXTRA]) pages.push({ id: b.id, file: b.file, expect: b.family });
if (!sets.length || sets.includes("a")) for (const h of HOLDOUT) if (existsSync(holdoutFile(h.id))) pages.push({ id: h.id, file: holdoutFile(h.id), expect: h.expect });
if (sets.includes("b")) for (const h of HOLDOUT_B) if (existsSync(holdoutFile(h.id, "holdout2"))) pages.push({ id: h.id, file: holdoutFile(h.id, "holdout2"), expect: h.expect });

const rows = [];
for (const pg of pages) {
  const p = realPage(JSON.parse(readFileSync(pg.file, "utf8")) as DomSnapshot, "none", exp);
  for (const t of p.plan.territories) {
    if (t.kind !== "feed" || t.weight < 0.05 || t.region < 0) continue;
    const items = p.sem.regions[t.region].items;
    rows.push({ ...pg, weight: t.weight, ...listAnatomy(p.doc, items), says: listSays(p.doc, items) });
  }
}
rows.sort((a, b) => a.says - b.says);
const mix = (m: ReturnType<typeof mixFor>) => m.map((x) => `${x.comp.slice(0, 5)} ${Math.round(x.share * 100)}`).join("+");
console.log(`${"page".padEnd(22)} ${"expected".padEnd(10)} land  items  chars/item  pictured  says · by chars (220)        · by what it says: at 70, at ${SAYS_SOMETHING}, at 140`);
for (const r of rows)
  console.log(`${r.id.padEnd(22)} ${r.expect.padEnd(10)} ${`${Math.round(r.weight * 100)}%`.padStart(4)} ${String(r.count).padStart(5)} ${String(Math.round(r.chars)).padStart(10)} ${`${Math.round(r.pictured * 100)}%`.padStart(8)} ${String(Math.round(r.says)).padStart(6)} · ${mix(mixFor(r.chars, r.pictured)).padEnd(24)} · ${mix(mixFor(r.says, r.pictured, 70)).padEnd(24)} | ${mix(mixFor(r.says, r.pictured, SAYS_SOMETHING)).padEnd(24)} | ${mix(mixFor(r.says, r.pictured, 140))}`);
