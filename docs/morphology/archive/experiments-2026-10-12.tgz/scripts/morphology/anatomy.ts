import { readFileSync } from "node:fs";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { itemMix, extentOf } from "../../src/lib/pixelcity/kit/plan";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import type { DomSnapshot } from "../../src/lib/snapshot/types";
import { BENCH } from "./dataset";

const [expArg = "none", ...only] = process.argv.slice(2);
const experiments = parseExperiments(expArg === "none" ? "" : expArg);
for (const b of BENCH.filter((x) => !only.length || only.includes(x.id))) {
  const p = realPage(JSON.parse(readFileSync(b.file, "utf8")) as DomSnapshot, "none", experiments);
  console.log(`${b.id.padEnd(22)} ${b.family.padEnd(9)} elements ${String(p.doc.stats.elements).padStart(5)} · nodes ${String(p.doc.nodes.length).padStart(4)} · chars ${String(p.doc.nodes[0].chars).padStart(6)} · extent ${extentOf(p.doc).toFixed(2)}`);
  for (const t of p.plan.territories) {
    if (t.weight < 0.05 || !t.items || t.items.source !== "series") continue;
    const it = t.items;
    const mix = itemMix(it);
    console.log(`   ${Math.round(t.weight * 100).toString().padStart(3)}% ${t.kind.padEnd(10)} ${(t.label ?? "").slice(0, 22).padEnd(22)} now ${t.mix.map((m) => `${m.comp} ${Math.round(m.share * 100)}`).join("+").padEnd(26)} items ${String(it.count).padStart(3)} × ${it.shape.padEnd(14)} ${String(Math.round(it.charsPerItem)).padStart(4)} chars, ${it.linksPerItem.toFixed(1)} links, ${it.mediaPerItem.toFixed(1)} pictures (${it.confidence}) → ${mix ? mix.map((m) => `${m.comp} ${Math.round(m.share * 100)}`).join("+") : "-"}`);
  }
}
