import { generateKitDistrict } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import { planChange, raster } from "./geometry";
import { pages } from "./stability";

const arms = process.argv.slice(2);
const city = (snap: Parameters<typeof realPage>[0], flags: string) => {
  const p = realPage(snap, "none", parseExperiments(flags));
  const c = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, flat: true });
  return { plan: JSON.stringify(p.plan.territories.map((t) => [t.key, t.kind, t.weight, t.mix])), parts: JSON.stringify(c.parts), r: raster(c.parts), n: p.plan.territories.length, b: c.parts.length };
};
const all = pages();
for (const arm of arms) {
  let samePlan = 0;
  let sameCity = 0;
  const moved: string[] = [];
  for (const pg of all) {
    const a = city(pg.snap, "");
    const b = city(pg.snap, arm);
    if (a.plan === b.plan) samePlan++;
    if (a.parts === b.parts) sameCity++;
    else {
      const d = planChange(a.r, b.r);
      moved.push(`${pg.id} territories ${a.n}→${b.n} any ${(d.any * 100).toFixed(0)}% built/open ${(d.foot * 100).toFixed(0)}%${a.plan === b.plan ? " (same plan)" : ""}`);
    }
  }
  console.log(`\n${arm}: ${all.length} pages · plan identical ${samePlan} · city identical (every part) ${sameCity}`);
  for (const m of moved) console.log("  " + m);
}
