import { existsSync, readFileSync } from "node:fs";
import { generateKitDistrict, newTrace } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import type { DomSnapshot } from "../../src/lib/snapshot/types";
import { BENCH, EXTRA, holdoutFile } from "./dataset";

const READING = "coverage,lists2,whole,nodir,transient,item-form3,avatars";
const SETS: Record<string, { pages: string[]; arms: Record<string, string>; comp: string }> = {
  catalogue: {
    pages: ["airbnb-rendered", "books-toscrape", "hiut", "gog", "oxylabs-products", "shop"],
    arms: { baseline: "", reading: READING, "G-a": `${READING},g-a`, "G-b": `${READING},g-b`, "G-c": `${READING},g-c` },
    comp: "grid",
  },
  interactive: {
    pages: ["rayso-rendered", "squoosh-rendered", "regex101-rendered", "desmos-rendered", "steam-top", "lesswrong"],
    arms: { baseline: "", reading: `${READING},wrappers`, "I-a": `${READING},wrappers,i-a`, "I-b": `${READING},wrappers,i-b` },
    comp: "interactive",
  },
  lists: {
    pages: ["hn", "forum", "oldweb", "pinboard", "hn-algolia-rendered", "tildes", "bsky-rendered", "directory", "app", "gutenberg-top"],
    arms: { baseline: "", reading: READING, T1: `${READING},t1`, T2: `${READING},t2`, "T1+T2": `${READING},t1,t2` },
    comp: "parcelled",
  },
};
const fileOf = (id: string) => [...BENCH, ...EXTRA].find((b) => b.id === id)?.file ?? (existsSync(holdoutFile(id)) ? holdoutFile(id) : holdoutFile(id, "holdout2"));
const q = (xs: number[], f: number) => [...xs].sort((a, b) => a - b)[Math.min(xs.length - 1, Math.floor(f * xs.length))] ?? 0;
const cv = (xs: number[]) => {
  const m = xs.reduce((a, b) => a + b, 0) / (xs.length || 1);
  return m ? Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length || 1)) / m : 0;
};

const which = process.argv[2] ?? "catalogue";
const set = SETS[which];
for (const id of set.pages) {
  const snap = JSON.parse(readFileSync(fileOf(id), "utf8")) as DomSnapshot;
  console.log(`\n${id}`);
  for (const [arm, flags] of Object.entries(set.arms)) {
    const p = realPage(snap, "none", parseExperiments(flags));
    const trace = newTrace();
    const city = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
    const mine = trace.buildings.filter((b) => b.comp === set.comp);
    const fam: Record<string, number> = {};
    const tops: number[] = [];
    const foot: number[] = [];
    for (const b of mine) {
      fam[b.P.family] = (fam[b.P.family] ?? 0) + 1;
      let top = 0;
      for (let k = b.parts[0]; k < b.parts[1]; k++) top = Math.max(top, city.parts[k].y + city.parts[k].h);
      tops.push(top);
      foot.push(b.w * b.d);
    }
    const lots = trace.alloc!.segments.filter((s) => s.comp === set.comp).reduce((s, x) => s + x.count, 0);
    const built = foot.reduce((a, b) => a + b, 0) / Math.max(1, lots * 3.5 * 3.5);
    const t = [...p.plan.territories].filter((x) => x.mix.some((m) => m.comp === set.comp)).sort((a, b) => b.weight - a.weight)[0];
    const c = t?.census;
    console.log(`  ${arm.padEnd(9)} ${String(lots).padStart(3)} lots of ${set.comp} · ${String(mine.length).padStart(3)} buildings · ${Object.entries(fam).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(", ").padEnd(44)} · footprint ${Math.round(built * 100).toString().padStart(3)}% of the land · tops ${q(tops, 0.5).toFixed(1)}/${q(tops, 0.9).toFixed(1)} spread ${cv(tops).toFixed(2)}${c ? ` · reads ${c.items} items, ${c.controls} controls in ${c.groups.length} groups${c.sizes.length ? `, item size spread ${cv(c.sizes).toFixed(2)}` : ""}` : ""}`);
  }
}
