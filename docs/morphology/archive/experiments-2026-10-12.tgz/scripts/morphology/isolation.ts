import { generateKitDistrict, newTrace } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import { pages } from "./stability";

const READING = "coverage,lists2,whole,nodir,transient,item-form3,avatars";
const TARGET: Record<string, string> = { "g-a": "grid", "g-b": "grid", "g-c": "grid", "i-a": "interactive", "i-b": "interactive", t1: "parcelled", t2: "parcelled" };
const only = process.argv.slice(2);

function city(snap: Parameters<typeof realPage>[0], flags: string) {
  const p = realPage(snap, "none", parseExperiments(flags));
  const trace = newTrace();
  const c = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
  const sig = (comp: (c: string) => boolean) =>
    trace.buildings
      .filter((b) => comp(b.comp))
      .map((b) => `${b.comp}:${b.P.family}:${b.P.floors}:${b.w.toFixed(2)}x${b.d.toFixed(2)}:${b.parts[1] - b.parts[0]}`)
      .join("|");
  return { sig, parts: c.parts.length, has: (comp: string) => trace.alloc!.segments.some((s) => s.comp === comp && s.count > 0) };
}

const all = pages();
for (const [flag, target] of Object.entries(TARGET)) {
  if (only.length && !only.includes(flag)) continue;
  let touched = 0;
  let leaked = 0;
  let withTarget = 0;
  const leaks: string[] = [];
  for (const b of all) {
    const a = city(b.snap, READING);
    const z = city(b.snap, `${READING},${flag}`);
    if (a.has(target)) withTarget++;
    if (a.sig((c) => c === target) !== z.sig((c) => c === target)) touched++;
    if (a.sig((c) => c !== target) !== z.sig((c) => c !== target)) {
      leaked++;
      leaks.push(b.id);
    }
  }
  console.log(`${flag.padEnd(4)} target ${target.padEnd(11)} · pages with that fabric ${String(withTarget).padStart(3)} of ${all.length} · pages where it changes ${String(touched).padStart(3)} · pages where any other fabric changes ${leaked}${leaks.length ? ` (${leaks.slice(0, 6).join(", ")})` : ""}`);
}
