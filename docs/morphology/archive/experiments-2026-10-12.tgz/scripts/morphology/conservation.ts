import { generateKitDistrict, newTrace } from "../../src/lib/pixelcity/kit/district";
import { realPage } from "../../src/lib/pixelcity/kit/real-page";
import { parseExperiments } from "../../src/lib/semantics/experiments";
import { READING } from "./geometry";
import { pages } from "./stability";

const ARMS: Record<string, string> = {
  "today's fabrics": `${READING},wrappers,census`,
  t2: `${READING},wrappers,t2`,
  "g-a": `${READING},wrappers,g-a`,
  "g-c": `${READING},wrappers,g-c`,
  "i-a": `${READING},wrappers,i-a`,
  "i-c": `${READING},wrappers,i-c`,
};
const rank = (xs: number[]) => {
  const order = xs.map((v, i) => [v, i] as const).sort((a, b) => a[0] - b[0]);
  const r = new Array<number>(xs.length);
  for (let i = 0; i < order.length; ) {
    let j = i;
    while (j < order.length && order[j][0] === order[i][0]) j++;
    for (let k = i; k < j; k++) r[order[k][1]] = (i + j - 1) / 2;
    i = j;
  }
  return r;
};
const spearman = (x: number[], y: number[]) => {
  if (x.length < 3) return NaN;
  const a = rank(x);
  const b = rank(y);
  const ma = a.reduce((s, v) => s + v, 0) / a.length;
  const mb = b.reduce((s, v) => s + v, 0) / b.length;
  let num = 0;
  let da = 0;
  let db = 0;
  for (let i = 0; i < a.length; i++) {
    num += (a[i] - ma) * (b[i] - mb);
    da += (a[i] - ma) ** 2;
    db += (b[i] - mb) ** 2;
  }
  return da && db ? num / Math.sqrt(da * db) : NaN;
};
const q = (xs: number[], f: number) => [...xs].sort((a, b) => a - b)[Math.min(xs.length - 1, Math.floor(f * xs.length))] ?? 0;

interface Row {
  page: string;
  comp: string;
  lots: number;
  items: number;
  controls: number;
  groups: number;
  units: number;
  kiosks: number;
  bars: number;
}
const all = pages();
const only = process.argv[2];
for (const [arm, flags] of Object.entries(ARMS)) {
  if (only && only !== arm) continue;
  const rows: Row[] = [];
  for (const b of all) {
    const p = realPage(b.snap, "none", parseExperiments(flags));
    const trace = newTrace();
    generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
    const lots = trace.alloc!.lots;
    p.plan.territories.forEach((t, ti) => {
      if (lots[ti] < 12 || !t.census) return;
      const mine = trace.buildings.filter((x) => x.territory === ti);
      const comp = [...t.mix].sort((x, y) => y.share - x.share)[0].comp;
      rows.push({
        page: b.id,
        comp,
        lots: lots[ti],
        items: t.census.items,
        controls: t.census.controls,
        groups: t.census.groups.length,
        units: mine.reduce((s, x) => s + (x.P.family === "rows" ? (x.P.units ?? Math.round(x.w / 1.6)) : x.P.family === "kiosk" ? 0 : 1), 0),
        kiosks: mine.filter((x) => x.P.family === "kiosk").length,
        bars: mine.filter((x) => x.P.family === "slab").length,
      });
    });
  }
  console.log(`\n${arm}`);
  for (const comp of ["parcelled", "grid", "continuous", "archive", "media"]) {
    const rs = rows.filter((r) => r.comp === comp && r.items >= 5);
    if (rs.length < 4) continue;
    const built = (r: Row) => (comp === "grid" && (arm === "g-c" || arm === "g-b") ? r.kiosks : r.units);
    const rep = rs.map((r) => built(r) / r.items);
    console.log(`  ${comp.padEnd(11)} ${String(rs.length).padStart(3)} list territories · built units per item: p10 ${q(rep, 0.1).toFixed(2)} · median ${q(rep, 0.5).toFixed(2)} · p90 ${q(rep, 0.9).toFixed(1)} · within half to double ${rs.filter((_, i) => rep[i] >= 0.5 && rep[i] <= 2).length} · rank correlation items × units ${spearman(rs.map((r) => r.items), rs.map(built)).toFixed(2)} · per lot ${spearman(rs.map((r) => r.items / r.lots), rs.map((r) => built(r) / r.lots)).toFixed(2)}`);
  }
  const it = rows.filter((r) => r.comp === "interactive" && r.controls >= 1);
  if (it.length >= 4) {
    const rep = it.map((r) => r.kiosks / r.controls);
    console.log(`  ${"interactive".padEnd(11)} ${String(it.length).padStart(3)} territories · kiosks per control: p10 ${q(rep, 0.1).toFixed(2)} · median ${q(rep, 0.5).toFixed(2)} · p90 ${q(rep, 0.9).toFixed(1)} · rank correlation controls × kiosks ${spearman(it.map((r) => r.controls), it.map((r) => r.kiosks)).toFixed(2)} · arcades per group: median ${q(it.filter((r) => r.groups > 0).map((r) => r.bars / r.groups), 0.5).toFixed(1)} · p90 ${q(it.filter((r) => r.groups > 0).map((r) => r.bars / r.groups), 0.9).toFixed(1)} · groups × arcades ${spearman(it.map((r) => r.groups), it.map((r) => r.bars)).toFixed(2)}`);
    const big = it.filter((r) => r.lots >= 51);
    console.log(`               of which with a fifth of the city or more: ${big.length} · groups ${big.map((r) => `${r.page.replace("-rendered", "")} ${r.groups}g/${r.controls}c/${Math.round(r.lots / 16)}q→${r.bars}a,${r.kiosks}k`).join(" · ")}`);
    console.log(`               all ${it.length}: with 4 groups or more ${it.filter((r) => r.groups >= 4).length} · with 2 or 3 ${it.filter((r) => r.groups === 2 || r.groups === 3).length} · with 0 or 1 ${it.filter((r) => r.groups <= 1).length}`);
  }
}
