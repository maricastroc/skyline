export const EXPERIMENTS = ["steady", "runs", "ids", "quads", "coverage", "amount", "majority", "avatars", "decorative", "wrappers", "lists", "lists2", "whole", "narrow", "nodir", "min6", "nesting", "transient", "dialogs", "image-led", "item-form", "item-form2", "item-form3", "feed-soft", "cards", "rhythm", "extent", "g-a", "g-b", "g-c", "i-a", "i-b", "i-c", "t1", "t2", "t2s", "census", "p-l"] as const;
export const PROTOTYPES: Experiment[] = ["g-a", "g-b", "g-c", "i-a", "i-b", "i-c", "t1", "t2", "t2s", "census", "p-l"];
export type Experiment = (typeof EXPERIMENTS)[number];
export type Experiments = ReadonlySet<Experiment>;

export const NO_EXPERIMENTS: Experiments = new Set();

export function parseExperiments(value: string | null | undefined): Experiments {
  if (!value) return NO_EXPERIMENTS;
  const asked = value.split(",").map((s) => s.trim());
  if (asked.includes("all")) return new Set(EXPERIMENTS);
  return new Set(EXPERIMENTS.filter((e) => asked.includes(e)));
}
