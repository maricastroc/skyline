# Territory by territory: did the reading produce a series, why not, and what do the repeated siblings of the same capture say the unit is.
import json, os, sys, collections
trace_dir, out = sys.argv[1], sys.argv[2]
ids = sys.argv[3:]
def kind(r):
    if r["images"] >= 0.5:
        if r["picShare"] >= 0.8: return "image"
        if r["picShare"] >= 0.2: return "card"
        return "row+thumb"
    if r["controls"] >= 0.5 or (r["w"] <= 72 and r["h"] <= 72): return "key"
    return "text"
def merged(reps):
    out = []
    for r in reps:
        for m in out:
            if m["tag"] == r["tag"] and m["level"] == r["level"] and abs(m["w"] - r["w"]) <= 0.15 * m["w"]:
                tot = m["n"] + r["n"]
                for k in ["images", "chars", "links", "controls", "picShare", "h"]: m[k] = (m[k] * m["n"] + r[k] * r["n"]) / tot
                m["n"] = tot; m["area"] += r["area"]; m["hidden"] += r["hidden"]; m["parents"] += 1; m["boxes"] += r["boxes"]; m["perRowMax"] = max(m["perRowMax"], r["perRow"]); break
        else:
            out.append({**r, "parents": 1, "perRowMax": r["perRow"], "boxes": list(r["boxes"])})
    return sorted(out, key=lambda m: -m["area"])
def inside(a, b):  # box a within box b
    return a[0] >= b[0] - 2 and a[1] >= b[1] - 2 and a[0] + a[2] <= b[0] + b[2] + 2 and a[1] + a[3] <= b[1] + b[3] + 2
rows = []
for pid in ids:
    f = os.path.join(trace_dir, pid + ".json")
    if not os.path.exists(f): continue
    t = json.load(open(f))
    for T in t["territories"]:
        if T["lots"] < 8: continue
        tr = T["trace"]; s = T["series"]
        cands = merged(T["reps"])
        for c in cands:
            c["kind"] = kind(c); c["share"] = c["area"] / max(1, tr["area"])
            c["nested"] = any(o is not c and o["w"] * o["h"] > 2 * c["w"] * c["h"] and sum(1 for b in c["boxes"] if any(inside(b, ob) for ob in o["boxes"])) >= 0.6 * len(c["boxes"]) for o in cands)
        match = None
        if s:
            for k, c in enumerate(cands):
                if abs(c["w"] - s["w"]) <= 0.25 * s["w"] and abs(c["h"] - s["h"]) <= 0.35 * s["h"]: match = k; break
        rows.append(dict(page=pid, i=T["i"], lots=T["lots"], mix=T["mix"], label=T["label"], media="media" in T["mix"], series=s, why=tr["why"], st=tr["st"], counts=tr["counts"], tiled=tr["tiled"], dropped=tr.get("dropped"),
                         cands=[{k: c[k] for k in ["tag", "n", "hidden", "w", "h", "perRowMax", "lines", "share", "kind", "nested", "images", "chars", "links", "controls", "picShare", "parents"]} for c in cands[:5]], match=match))
json.dump(rows, open(out, "w"))
media = [r for r in rows if r["media"]]
lots = sum(r["lots"] for r in media)
ser = [r for r in media if r["series"]]
print(f"pages {len(set(r['page'] for r in rows))} · territories ≥8 lots: {len(rows)} · media: {len(media)} ({lots} lots) · with a series: {len(ser)} ({sum(r['lots'] for r in ser)} lots, {round(100*sum(r['lots'] for r in ser)/max(1,lots))}%)")
why = collections.defaultdict(lambda: [0, 0])
for r in media:
    if not r["series"]: why[r["why"]][0] += 1; why[r["why"]][1] += r["lots"]
for k, v in sorted(why.items(), key=lambda kv: -kv[1][1]): print(f"   no series · {k}: {v[0]} territories, {v[1]} lots ({round(100*v[1]/max(1,lots))}%)")
im = {k: sum(r["st"][k] for r in media) for k in ["imageNodes", "noBox", "small", "pictures", "bgNodes", "inClusters", "carried", "imagesTotal"]}
print("   images in media territories:", im)
agree = [r for r in ser if r["match"] == 0]; other = [r for r in ser if r["match"] not in (0, None)]; none = [r for r in ser if r["match"] is None]
print(f"   reading's unit = largest repeated-sibling group: {len(agree)} · = a smaller group: {len(other)} · = no group: {len(none)}")
for r in rows:
    s = r["series"]
    c = r["cands"][0] if r["cands"] else None
    line = f"{r['page']:12} T{r['i']:<2} {r['lots']:3}l {r['mix'][:16]:16} " + (f"{s['arrangement']:5} {round(s['w'])}x{round(s['h'])} {s['perRow']}/row n{s['units']}" if s else f"- {r['why'][:38]}").ljust(46)
    if c: line += f"| top group {c['tag']} {round(c['w'])}x{round(c['h'])} n{c['n']}+{c['hidden']} {c['perRowMax']}/row {round(100*c['share'])}% {c['kind']}{' nested' if c['nested'] else ''}" + (f" | match #{r['match']}" if r["match"] is not None else (" | NO MATCH" if s else ""))
    if r["media"] or s or (c and c["share"] > 0.3): print(line)
