# One tile per page: left, the live page with the units its DOM repeats; right, what the capture measured and which units the reading chose.
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
probe_dir, probe_json, trace_dir, out, cols = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])
ids = sys.argv[6:]
SC, PW, PH, GAP = 0.25, 360, 660, 8
font = ImageFont.load_default(size=15); small = ImageFont.load_default(size=13)
units = {r["id"]: r for r in json.load(open(probe_json)) if r.get("ok")}
RED, GREEN, BLUE, ORANGE, GREY = (226, 60, 50), (40, 170, 90), (60, 110, 220), (240, 150, 30), (205, 208, 214)
def box(d, b, col, w=2, fill=None, ox=0, oy=0):
    x0, y0, x1, y1 = ox + b[0] * SC, oy + b[1] * SC, ox + (b[0] + b[2]) * SC, oy + (b[1] + b[3]) * SC
    if y0 > oy + PH: return
    d.rectangle([x0, y0, x1, min(y1, oy + PH)], outline=col, width=w, fill=fill)
tiles = []
for pid in ids:
    tile = Image.new("RGB", (2 * PW + GAP, PH + 64), (16, 16, 20)); d = ImageDraw.Draw(tile)
    shot = os.path.join(probe_dir, pid + ".jpg")
    if os.path.exists(shot):
        im = Image.open(shot).convert("RGB"); im = im.resize((PW, round(im.height * PW / im.width)), Image.LANCZOS).crop((0, 0, PW, PH)); tile.paste(im, (0, 64))
    u = units.get(pid, {}).get("units", [])
    for k, g in enumerate(u[:2]):
        for b in g["boxes"]: box(d, b, GREEN if k == 0 else BLUE, 2 if k == 0 else 1, None, 0, 64)
    tf = next((os.path.join(d0, pid + ".json") for d0 in trace_dir.split(",") if os.path.exists(os.path.join(d0, pid + ".json"))), "")
    stale = tf and not tf.startswith(trace_dir.split(",")[0])
    lines = []
    ox = PW + GAP
    d.rectangle([ox, 64, ox + PW, 64 + PH], fill=(248, 248, 246))
    if os.path.exists(tf):
        t = json.load(open(tf))
        for T in t["territories"]:
            if T["lots"] < 8: continue
            tr = T["trace"]
            for b in tr["rootBoxes"]: box(d, b, (150, 150, 165), 1, None, ox, 64)
            for b in tr["pictures"]: box(d, b, GREY, 1, GREY, ox, 64)
            for b in tr["keys"]: box(d, b, ORANGE, 1, None, ox, 64)
            if T["reps"]:
                for b in T["reps"][0]["boxes"]: box(d, b, GREEN, 1, None, ox, 64)
            for b in tr.get("alike", []): box(d, b, RED, 2, None, ox, 64)
            s = T["series"]
            lines.append(f"T{T['i']} {T['lots']}l {T['mix'][:14]}: " + (f"{s['arrangement']} {round(s['w'])}x{round(s['h'])} {s['perRow']}/row" if s else f"- ({(tr['why'] or '')[:34]})") + (f" | rep {T['reps'][0]['tag']} {round(T['reps'][0]['w'])}x{round(T['reps'][0]['h'])} n{T['reps'][0]['n']}" if T["reps"] else ""))
    d.text((4, 2), pid + ("*" if stale else ""), fill=(255, 207, 90), font=font)
    if u: d.text((110, 3), f"live: {u[0]['sig'][:22]} {round(u[0]['w'])}x{round(u[0]['h'])} n{u[0]['n']} img {round(u[0]['iw'])}x{round(u[0]['ih'])}", fill=(120, 220, 150), font=small)
    for k, l in enumerate(lines[:3]): d.text((4, 20 + 14 * k), l[:112], fill=(235, 235, 235), font=small)
    tiles.append(tile)
rows = [tiles[i:i + cols] for i in range(0, len(tiles), cols)]
W = cols * (2 * PW + GAP) + (cols - 1) * 14; H = len(rows) * (PH + 64 + 12)
LEG = 34
sheet = Image.new("RGB", (W, H + LEG), (0, 0, 0))
dl = ImageDraw.Draw(sheet)
x = 6
for col, text in [((255, 207, 90), "Em cada pagina: a esquerda, a pagina ao vivo; a direita, o que a captura mediu."), (GREEN, "Verde: itens irmaos repetidos (o DOM)."), (GREY, "Cinza: imagens com caixa."), (RED, "Vermelho: unidades que a leitura escolheu."), (ORANGE, "Laranja: controles de ate 72 px.")]:
    dl.text((x, 8), text, fill=col, font=font); x += int(dl.textlength(text, font=font)) + 22
for r, row in enumerate(rows):
    for c, t in enumerate(row): sheet.paste(t, (c * (2 * PW + GAP + 14), LEG + r * (PH + 64 + 12)))
sheet.save(out, quality=80); print(out, sheet.size)
