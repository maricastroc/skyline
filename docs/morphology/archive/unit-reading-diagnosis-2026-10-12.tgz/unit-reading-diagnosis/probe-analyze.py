# Compares, image by image, the page measured with placeholder images (what the capture does), with real images and after scrolling.
import json, os, sys, statistics as st
probe_dir, out = sys.argv[1], sys.argv[2]
only = set(sys.argv[3:])
def content(i): return i["t"] == "img" and not i.get("svg")
def big(i, m=24): return i["b"][2] >= m and i["b"][3] >= m
def near(a, b, tol=0.15): return abs(a - b) <= tol * max(a, b, 1)
def state(i, W, H):
    # the same order of tests the capture applies
    b = i["b"]
    if not i["v"]: return "invisible"
    if (b[2] >= 2 or b[3] >= 2) and (b[0] + b[2] <= 0 or b[1] + b[3] <= 0 or b[0] >= W or b[1] >= H): return "away"
    if b[2] < 2 or b[3] < 2: return "collapsed"
    if not big(i): return "small"
    return "shown"
rows = []
for f in sorted(os.listdir(probe_dir)):
    if not f.endswith(".json"): continue
    pid = f[:-5]
    if only and pid not in only: continue
    d = json.load(open(os.path.join(probe_dir, f)))
    P, R = (d.get("placeholder") or {}).get("first"), (d.get("real") or {}).get("first")
    S = (d.get("real") or {}).get("scrolled")
    if not P or not R: rows.append({"id": pid, "ok": False, "snapshot": d.get("snapshot")}); continue
    pk = {i["k"]: i for i in P["imgs"]}
    allR = [i for i in R["imgs"] if content(i)]
    sR = {k: 0 for k in ["shown", "small", "collapsed", "away", "invisible"]}
    for i in allR: sR[state(i, R["W"], R["H"])] += 1
    sP = {k: 0 for k in ["shown", "small", "collapsed", "away", "invisible"]}
    for i in P["imgs"]:
        if content(i): sP[state(i, P["W"], P["H"])] += 1
    real = [i for i in allR if state(i, R["W"], R["H"]) == "shown"]
    c = dict(same=0, squared=0, reshaped=0, collapsed=0, small=0, away=0, invisible=0, missing=0)
    decl = {True: [0, 0], False: [0, 0]}
    for i in real:
        declared = bool((i.get("aw") and i.get("ah")) or i.get("ar"))
        q = pk.get(i["k"])
        if not q: s = "missing"
        else:
            s = state(q, P["W"], P["H"])
            if s == "shown":
                if near(q["b"][2], i["b"][2]) and near(q["b"][3], i["b"][3]): s = "same"
                elif abs(q["b"][2] - q["b"][3]) <= 2 and not near(i["b"][2], i["b"][3], 0.1): s = "squared"
                else: s = "reshaped"
        c[s] += 1
        if s != "missing": decl[declared][0] += 1; decl[declared][1] += s == "same"
    loaded = sum(1 for i in real if i["nat"] and i["nat"][0] > 1)
    late = None
    if S:
        shownS = [i for i in S["imgs"] if content(i) and state(i, S["W"], S["H"]) == "shown"]
        late = max(0, len(shownS) - len(real))
    groups = {}
    for i in real:
        r = i.get("rep")
        if not r or r["b"][2] < 24 or r["b"][3] < 24: continue
        groups.setdefault(r["sig"] + f"/{r['d']}", []).append((r, i))
    units = []
    for sig, g in groups.items():
        seen, uniq = set(), []
        for r, i in g:
            k = tuple(r["b"])
            if k in seen: continue
            seen.add(k); uniq.append((r, i))
        if len(uniq) < 4: continue
        units.append(dict(sig=sig, n=len(uniq), w=st.median([r["b"][2] for r, _ in uniq]), h=st.median([r["b"][3] for r, _ in uniq]), area=sum(r["b"][2] * r["b"][3] for r, _ in uniq), imgs=st.median([r["imgs"] for r, _ in uniq]), txt=st.median([r["txt"] for r, _ in uniq]),
                          links=st.median([r["links"] for r, _ in uniq]), ctl=st.median([r["ctl"] for r, _ in uniq]), iw=st.median([i["b"][2] for _, i in uniq]), ih=st.median([i["b"][3] for _, i in uniq]), boxes=[r["b"] for r, _ in uniq][:80]))
    units.sort(key=lambda u: -u["area"])
    bg = [b for b in R["bgs"] if b["v"] and b["b"][2] >= 60 and b["b"][3] >= 60 and b["b"][0] < R["W"]]
    rows.append({"id": pid, "ok": True, "W": R["W"], "H": R["H"], "Hp": P["H"], "Hs": S["H"] if S else None, "elements": R["elements"], "elementsS": S["elements"] if S else None, "imgs": len(allR), "stateR": sR, "stateP": sP, "real": len(real), "loaded": loaded, **c, "late": late,
                 "declared": decl[True], "undeclared": decl[False], "bg": len(bg), "bg_inline": sum(b["inline"] for b in bg), "bg_repeat": sum(1 for b in bg if b.get("rep") and b["rep"]["n"] >= 4), "keys": len(R["keys"]), "units": units[:5]})
json.dump(rows, open(out, "w"))
ok = [r for r in rows if r["ok"]]
print(f"pages {len(ok)} (+{len(rows)-len(ok)} without both modes: {[r['id'] for r in rows if not r['ok']]})")
print(f"{'page':13} imgs | real: shown small coll away invis | of shown, capture has: same sqrd resh coll small away invis miss | +scroll  bg≥60(rep) | H real/plh/scroll")
for r in ok:
    s = r["stateR"]
    print(f"{r['id']:13} {r['imgs']:4} | {s['shown']:11} {s['small']:5} {s['collapsed']:4} {s['away']:4} {s['invisible']:5} | {r['same']:26} {r['squared']:4} {r['reshaped']:4} {r['collapsed']:4} {r['small']:5} {r['away']:4} {r['invisible']:5} {r['missing']:4} | {str(r['late']):7}  {r['bg']:3}({r['bg_repeat']:2})   | {r['H']}/{r['Hp']}/{r['Hs']}")
keys = ["real", "same", "squared", "reshaped", "collapsed", "small", "away", "invisible", "missing"]
tot = {k: sum(r[k] for r in ok) for k in keys}
print("TOTAL shown in the real page:", tot["real"], "→ in the capture:", {k: f"{tot[k]} ({round(100*tot[k]/max(1,tot['real']))}%)" for k in keys[1:]})
for name in ["stateR", "stateP"]:
    t = {k: sum(r[name][k] for r in ok) for k in ["shown", "small", "collapsed", "away", "invisible"]}; n = sum(t.values())
    print(f"all <img> by state, {'real images' if name == 'stateR' else 'placeholders '}:", {k: f"{v} ({round(100*v/max(1,n))}%)" for k, v in t.items()})
d = [sum(r["declared"][k] for r in ok) for k in (0, 1)]; u = [sum(r["undeclared"][k] for r in ok) for k in (0, 1)]
print(f"images with a declared size or aspect ratio: {d[1]}/{d[0]} keep their box ({round(100*d[1]/max(1,d[0]))}%) · without: {u[1]}/{u[0]} ({round(100*u[1]/max(1,u[0]))}%)")
print("more images shown after scrolling:", sum(r["late"] or 0 for r in ok), "on", sum(1 for r in ok if (r["late"] or 0) > 0), "pages · background images ≥60 px:", sum(r["bg"] for r in ok), "of which in a repeated unit:", sum(r["bg_repeat"] for r in ok))
