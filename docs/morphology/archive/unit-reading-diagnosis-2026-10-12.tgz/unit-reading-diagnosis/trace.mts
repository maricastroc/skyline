// Follows every image and every territory of a snapshot through capture → normalisation → unit selection → pooling, without changing any of it.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, outDir, ...specs] = process.argv.slice(2); // spec: id=path
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
mkdirSync(outDir, { recursive: true });
const TILE = 72, MIN_UNITS = 4, MIN_PICTURE = 24, WRAP = 6;
const median = (v: number[]) => (v.length ? [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] : 0);
type B = [number, number, number, number];

function rawFunnel(snap: any) {
  const f = { images: 0, img: 0, bg: 0, unseen: 0, nobox: 0, small: 0, measured: 0, square: 0, declared: 0, declaredNobox: 0, noboxUndeclared: 0, media: 0, elements: 0, boxedElements: 0 };
  const walk = (n: any) => {
    f.elements++;
    if (n.box) f.boxedElements++;
    const isImg = n.tag === "img" || n.tag === "picture" || n.attrs?.role === "img";
    if (n.tag === "video" || n.tag === "canvas") f.media++;
    if (n.image || isImg) {
      f.images++;
      if (isImg) f.img++; else f.bg++;
      const declared = Number(n.attrs?.width) > 0 && Number(n.attrs?.height) > 0;
      if (declared) f.declared++;
      if (n.unseen) f.unseen++;
      else if (!n.box) { f.nobox++; if (declared) f.declaredNobox++; else f.noboxUndeclared++; }
      else if (n.box.w < MIN_PICTURE || n.box.h < MIN_PICTURE) f.small++;
      else { f.measured++; if (Math.abs(n.box.w - n.box.h) <= 2) f.square++; }
    }
    for (const c of n.children) walk(c);
  };
  walk(snap.root);
  return f;
}

function traceTerritory(doc: any, scope: { roots: number[]; excluded: number[] }) {
  const nodes = doc.nodes;
  const ids: number[] = scopeOf(nodes, scope.roots, scope.excluded);
  const inScope = new Set(ids);
  const boxed = (n: any) => !!n.box && !n.cluster;
  const imageNodes = ids.filter((i) => nodes[i].role === "image");
  const st = { imageNodes: imageNodes.length, noBox: 0, small: 0, pictures: 0, bgNodes: 0, bgBoxed: 0, inClusters: 0, clusters: 0, imagesTotal: 0, carried: 0 };
  for (const i of imageNodes) { const n = nodes[i]; if (!boxed(n)) st.noBox++; else if (n.box[2] < MIN_PICTURE || n.box[3] < MIN_PICTURE) st.small++; else st.pictures++; }
  for (const i of ids) { const n = nodes[i]; if (n.image && n.role !== "image") { st.bgNodes++; if (boxed(n) && n.box[2] >= MIN_PICTURE && n.box[3] >= MIN_PICTURE) st.bgBoxed++; } if (n.cluster) { st.clusters++; st.inClusters += n.images; } }
  const own = (i: number) => Math.max(0, nodes[i].images - nodes[i].children.reduce((s: number, c: number) => s + nodes[c].images, 0));
  st.imagesTotal = ids.reduce((s, i) => s + (nodes[i].cluster ? nodes[i].images : own(i)), 0);
  st.carried = ids.filter((i) => !nodes[i].cluster && nodes[i].role !== "image" && !nodes[i].image && own(i) > 0).reduce((s, i) => s + own(i), 0);
  const area = scope.roots.reduce((s, r) => s + (nodes[r].box ? nodes[r].box[2] * nodes[r].box[3] : 0), 0);
  const rootBoxes: B[] = scope.roots.filter((r) => nodes[r].box).map((r) => nodes[r].box);

  const pictures = imageNodes.filter((i) => boxed(nodes[i]) && nodes[i].box[2] >= MIN_PICTURE && nodes[i].box[3] >= MIN_PICTURE);
  const prefix = new Int32Array(nodes.length + 1);
  const isPicture = new Set(pictures);
  for (let i = 0; i < nodes.length; i++) prefix[i + 1] = prefix[i] + (isPicture.has(i) ? 1 : 0);
  const held = (i: number) => prefix[nodes[i].end] - prefix[i];
  const cards: Array<{ pic: number; at: number; b: B; pb: B; stop: string }> = [];
  const seen = new Set<number>();
  for (const i of pictures) {
    const a = nodes[i].box[2] * nodes[i].box[3];
    let at = i, stop = "root";
    for (let p = nodes[at].parent; ; p = nodes[p].parent) {
      if (p < 0) { stop = "root"; break; }
      if (!inScope.has(p)) { stop = "scope"; break; }
      if (!boxed(nodes[p])) { stop = "unboxed parent"; break; }
      if (held(p) !== 1) { stop = "parent holds more pictures"; break; }
      if (nodes[p].box[2] * nodes[p].box[3] > WRAP * a) { stop = "parent too large"; break; }
      at = p;
    }
    if (seen.has(at)) continue;
    seen.add(at);
    cards.push({ pic: i, at, b: nodes[at].box, pb: nodes[i].box, stop });
  }
  const keyIds = ids.filter((i) => (nodes[i].role === "button" || nodes[i].role === "control") && boxed(nodes[i]) && nodes[i].box[2] <= TILE && nodes[i].box[3] <= TILE && nodes[i].box[2] >= 12 && nodes[i].box[3] >= 12);
  const keys: B[] = keyIds.map((i) => nodes[i].box);
  const U = (b: B) => ({ x: b[0], y: b[1], w: b[2], h: b[3] });
  const cardU = cards.map((c) => U(c.b));
  const small = cardU.filter((u) => u.w <= TILE && u.h <= TILE);
  const large = cardU.filter((u) => u.w > TILE || u.h > TILE);
  const tiles = [...small, ...keys.map(U)];
  const tiled = tiles.length >= MIN_UNITS && tiles.length >= 2 * large.length;
  const pool = tiled ? tiles : large;
  const t: any = { st, area, rootBoxes, pictures: pictures.map((i) => nodes[i].box), cards: cards.map((c) => ({ b: c.b, pb: c.pb, climbed: c.at !== c.pic, stop: c.stop })), keys, counts: { pictures: pictures.length, cards: cards.length, smallCards: small.length, largeCards: large.length, keys: keys.length, climbed: cards.filter((c) => c.at !== c.pic).length }, tiled, pool: pool.length };
  const fin = (why: string | null, extra: any = {}) => ({ ...t, why, ...extra });
  if (pool.length < MIN_UNITS) return fin(pictures.length + keys.length === 0 ? (st.imageNodes === 0 ? (st.bgNodes || st.inClusters || st.carried ? "no image node (background, cluster or carried by a parent)" : "no image in the territory") : st.noBox === st.imageNodes ? "no image node has a box" : "images boxed but under 24 px") : "fewer than 4 units");
  const width = median(pool.map((u) => u.w));
  const alike = pool.filter((u) => Math.abs(u.w - width) <= 0.35 * width).sort((a, b) => a.y - b.y || a.x - b.x);
  if (alike.length < MIN_UNITS) return fin("fewer than 4 units of a like width", { width });
  const height = median(alike.map((u) => u.h));
  const lines: Array<typeof alike> = [];
  for (const u of alike) { const line = lines[lines.length - 1]; if (line && Math.abs(u.y - line[0].y) <= 0.5 * height) line.push(u); else lines.push([u]); }
  const perRow = median(lines.map((l) => l.length));
  const base = { width, height, alike: alike.map((u) => [u.x, u.y, u.w, u.h]), dropped: pool.length - alike.length, lines: lines.length, perRow, lineLengths: lines.map((l) => l.length) };
  if (perRow < 2) return fin("one unit per row", base);
  return fin(null, { ...base, arrangement: tiled ? "tiles" : "units" });
}

// Repeated siblings of a like size: what the DOM says the unit is, measured with the same boxes.
function repeats(doc: any, scope: { roots: number[]; excluded: number[] }) {
  const nodes = doc.nodes;
  const ids: number[] = scopeOf(nodes, scope.roots, scope.excluded);
  const inScope = new Set(ids);
  const parents = new Set<number>(ids);
  for (const i of ids) if (nodes[i].parent >= 0) parents.add(nodes[i].parent);
  const out: any[] = [];
  for (const p of parents) {
    const groups = new Map<string, number[]>();
    for (const c of nodes[p].children) { if (!inScope.has(c)) continue; const n = nodes[c]; const k = `${n.cluster ? "*" : n.role}|${n.cluster?.tag ?? n.tag}`; groups.set(k, [...(groups.get(k) ?? []), c]); }
    for (const [k, members] of groups) {
      const tag = k.split("|")[1];
      const shown = members.filter((c) => nodes[c].box && !nodes[c].cluster && nodes[c].box[2] >= 12 && nodes[c].box[3] >= 12);
      if (shown.length < MIN_UNITS) continue;
      const w = median(shown.map((c) => nodes[c].box[2])), h = median(shown.map((c) => nodes[c].box[3]));
      const like = shown.filter((c) => Math.abs(nodes[c].box[2] - w) <= 0.35 * w && Math.abs(nodes[c].box[3] - h) <= 0.6 * h).sort((a, b) => nodes[a].box[1] - nodes[b].box[1] || nodes[a].box[0] - nodes[b].box[0]);
      if (like.length < MIN_UNITS) continue;
      const hidden = nodes[p].children.filter((c: number) => nodes[c].cluster && nodes[c].cluster.tag === tag).reduce((s: number, c: number) => s + nodes[c].cluster.count, 0);
      const lines: number[][] = [];
      for (const c of like) { const line = lines[lines.length - 1]; if (line && Math.abs(nodes[c].box[1] - nodes[line[0]].box[1]) <= 0.5 * h) line.push(c); else lines.push([c]); }
      const avg = (f: (n: any) => number) => like.reduce((s, c) => s + f(nodes[c]), 0) / like.length;
      const picArea = avg((n) => { let a = 0; for (let j = n.id; j < n.end; j++) { const m = nodes[j]; if ((m.role === "image" || m.image) && m.box && !m.cluster) a = Math.max(a, m.box[2] * m.box[3]); } return Math.min(1, a / (n.box[2] * n.box[3])); });
      out.push({ parent: p, sel: nodes[p].selector, tag, n: like.length, hidden, w, h, perRow: median(lines.map((l) => l.length)), lines: lines.length, area: like.reduce((s, c) => s + nodes[c].box[2] * nodes[c].box[3], 0), images: avg((n) => n.images), chars: avg((n) => n.chars), links: avg((n) => n.links), controls: avg((n) => n.controls), picShare: picArea, boxes: like.map((c) => nodes[c].box), level: nodes[like[0]].level });
    }
  }
  return out.sort((a, b) => b.area - a.area);
}

const rows: any[] = [];
for (const spec of specs) {
  const [id, file] = spec.split("=");
  if (!existsSync(file)) continue;
  const snap = JSON.parse(readFileSync(file, "utf8"));
  const p = realPage(snap, "none", parseExperiments("ensemble"));
  const alloc = allocate(p.plan);
  const nodes = p.doc.nodes;
  const raw = rawFunnel(snap);
  const norm = { nodes: nodes.length, pruned: p.doc.stats.pruned, images: nodes[0].images, imageNodes: nodes.filter((n: any) => n.role === "image").length, imageBoxed: nodes.filter((n: any) => n.role === "image" && n.box && !n.cluster).length, bgNodes: nodes.filter((n: any) => n.image && n.role !== "image").length, inClusters: nodes.filter((n: any) => n.cluster).reduce((s: number, n: any) => s + n.images, 0), clusters: nodes.filter((n: any) => n.cluster).length, bigPage: snap.stats.elementCount > 4000 };
  const territories = p.plan.territories.map((t: any, i: number) => {
    const lots = alloc.lots[i];
    if (!t.scope || lots < 4) return null;
    const tr = traceTerritory(p.doc, t.scope);
    const reps = repeats(p.doc, t.scope).slice(0, 6);
    return { i, lots, label: (t.label ?? t.kind).slice(0, 28), kind: t.kind, mix: t.mix.map((m: any) => m.comp).join("+"), metricImages: t.metrics.images, series: t.series ? { arrangement: t.series.arrangement, units: t.series.units, w: t.series.width, h: t.series.height, perRow: t.series.perRow, rows: t.series.rows, groups: t.series.groups, head: t.series.head } : null, trace: tr, reps };
  }).filter(Boolean);
  const rec = { id, layout: snap.layout, elements: snap.stats.elementCount, raw, norm, territories };
  writeFileSync(join(outDir, `${id}.json`), JSON.stringify(rec));
  rows.push(rec);
  const media = territories.filter((t: any) => t.mix.includes("media") && t.lots >= 8);
  console.log(`${id.padEnd(13)} raw images ${String(raw.images).padStart(4)}: measured≥24 ${String(raw.measured).padStart(3)}, <24 ${String(raw.small).padStart(3)}, no box ${String(raw.nobox).padStart(3)}, hidden ${String(raw.unseen).padStart(3)} · image nodes ${String(norm.imageNodes).padStart(3)} (boxed ${norm.imageBoxed}) · in clusters ${String(norm.inClusters).padStart(3)} · media territories ${media.length}, with series ${media.filter((t: any) => t.series).length}`);
}
