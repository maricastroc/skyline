// Measures the same live page three ways: images replaced by 1×1 placeholders (what the capture does), images loaded, and images loaded after scrolling.
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, outDir, snapDir, group, ...only] = process.argv.slice(2);
const { launchLocalBrowser } = await import(join(root, "src/lib/acquisition/local-browser.ts"));
const { USER_AGENT } = await import(join(root, "src/lib/acquisition/safe-fetch.ts"));
const { captureWithLocalBrowser } = await import(join(root, "src/lib/acquisition/rendered-capture.ts"));
const sets = await import(join(import.meta.dirname, "pages.mts"));
const PAGES: Array<[string, string]> = (sets as any)[group];
mkdirSync(outDir, { recursive: true });
mkdirSync(snapDir, { recursive: true });
const BLANK = Buffer.from("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", "base64");
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const MEASURE = `(() => {
  const sx = scrollX, sy = scrollY, body = document.body, root = document.documentElement;
  if (!body) return null;
  const W = Math.max(root.scrollWidth, body.scrollWidth), H = Math.max(root.scrollHeight, body.scrollHeight);
  const sig = (el) => el.localName + "." + (el.classList && el.classList[0] || "");
  const rect = (el) => { const r = el.getBoundingClientRect(); return [Math.round(r.left + sx), Math.round(r.top + sy), Math.round(r.width), Math.round(r.height)]; };
  const vis = (el) => (!el.checkVisibility || el.checkVisibility({ visibilityProperty: true })) ? 1 : 0;
  const seen = new Map();
  const key = (s) => { s = (s || "").split("?")[0].slice(-90); const n = seen.get(s) || 0; seen.set(s, n + 1); return s + "#" + n; };
  const repeat = (el) => {
    for (let a = el, d = 0; a && a !== body && d < 14; a = a.parentElement, d++) {
      const p = a.parentElement; if (!p) break;
      let same = 0; for (const c of p.children) if (sig(c) === sig(a)) same++;
      if (same >= 3) return { b: rect(a), n: same, d, imgs: a.querySelectorAll("img,picture>img").length, txt: Math.min(999, (a.innerText || "").trim().length), links: a.querySelectorAll("a[href]").length + (a.matches("a[href]") ? 1 : 0), ctl: a.querySelectorAll("button,input,select,[role=button]").length, sig: sig(a) };
    }
    return null;
  };
  const imgs = [];
  for (const el of body.querySelectorAll("img, video, canvas")) {
    if (imgs.length >= 1500) break;
    const pic = el.parentElement && el.parentElement.localName === "picture" ? el.parentElement : null;
    const cs = getComputedStyle(el);
    imgs.push({ t: el.localName, k: key(el.currentSrc || el.getAttribute("src") || el.getAttribute("data-src") || el.getAttribute("data-lazy-src") || ""), b: rect(el), v: vis(el),
      nat: el.localName === "img" ? [el.naturalWidth, el.naturalHeight] : null, aw: el.getAttribute("width"), ah: el.getAttribute("height"), lazy: el.getAttribute("loading") || "",
      src: (el.currentSrc || el.getAttribute("src")) ? 1 : 0, svg: /\\.svg(\\?|#|$)|^data:image\\/svg/.test(el.currentSrc || el.getAttribute("src") || "") ? 1 : 0,
      ar: cs.aspectRatio && cs.aspectRatio !== "auto" ? 1 : 0, fit: cs.objectFit, pic: pic ? { b: rect(pic), d: getComputedStyle(pic).display } : null, rep: repeat(el) });
  }
  const bgs = [];
  let checked = 0;
  for (const el of body.querySelectorAll("*")) {
    if (checked > 6000 || bgs.length >= 400) break;
    if (el.localName === "img") continue;
    const r = el.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) continue;
    checked++;
    const bi = getComputedStyle(el).backgroundImage;
    if (!bi || bi.indexOf("url(") < 0) continue;
    const u = /url\\(["']?([^"')]+)/.exec(bi);
    if (!u || /^data:image\\/svg|\\.svg(\\?|#|$)/.test(u[1])) continue;
    bgs.push({ t: "bg", k: key(u[1]), b: rect(el), v: vis(el), inline: /background(-image)?\\s*:[^;]*url\\(/i.test(el.getAttribute("style") || "") ? 1 : 0, kids: el.children.length, rep: repeat(el) });
  }
  const keys = [];
  for (const el of body.querySelectorAll("button, [role=button], input, select, a[href], [role=tab], [role=menuitem], [role=radio], [role=checkbox]")) {
    if (keys.length >= 600) break;
    const r = el.getBoundingClientRect();
    if (r.width < 12 || r.height < 12 || r.width > 72 || r.height > 72 || !vis(el)) continue;
    keys.push({ t: el.localName, b: rect(el), txt: Math.min(99, (el.innerText || el.value || "").trim().length), pic: el.querySelector("img,svg,canvas") ? 1 : 0, role: el.getAttribute("role") || "", rep: (() => { const q = repeat(el); return q ? { n: q.n, d: q.d, b: q.b } : null; })() });
  }
  return { W, H, vw: innerWidth, elements: document.getElementsByTagName("*").length, text: Math.min(999999, (body.innerText || "").length), imgs, bgs, keys };
})()`;

async function settle(page: any) {
  const until = Date.now() + 12000;
  await page.waitForNetworkIdle({ idleTime: 500, timeout: 8000 }).catch(() => undefined);
  let last = -1, since = Date.now();
  while (Date.now() < until) {
    const count = (await page.evaluate(`document.getElementsByTagName("*").length`).catch(() => last)) ?? last;
    if (count !== last) { last = count; since = Date.now(); } else if (Date.now() - since >= 500) return "quiet";
    await sleep(125);
  }
  return "deadline";
}

async function session(url: string, mode: "placeholder" | "real", shot?: string) {
  const browser = await launchLocalBrowser();
  const kill = setTimeout(() => void browser.process()?.kill("SIGKILL"), 70000);
  try {
    const context = await browser.createBrowserContext();
    const page = await context.newPage();
    await page.setUserAgent(USER_AGENT);
    await page.setViewport({ width: 1440, height: 900 });
    page.on("dialog", (d: any) => void d.dismiss().catch(() => undefined));
    let placeholders = 0, imageRequests = 0;
    await page.setRequestInterception(true);
    page.on("request", (req: any) => {
      if (req.isInterceptResolutionHandled()) return;
      const type = req.resourceType();
      const done = (p: Promise<void>) => void p.catch(() => undefined);
      if (/^(data|blob|about):/i.test(req.url())) return done(req.continue());
      if (type === "image") {
        imageRequests++;
        if (mode === "placeholder") { placeholders++; return done(req.respond({ status: 200, contentType: "image/gif", headers: { "access-control-allow-origin": "*" }, body: BLANK })); }
        return done(req.continue());
      }
      if (type === "media" || type === "font") return done(req.abort("blockedbyclient"));
      done(req.continue());
    });
    const res = await page.goto(url, { waitUntil: "domcontentloaded", timeout: Number(process.env.NAV_MS ?? 15000) });
    const settled = await settle(page);
    if (mode === "real") await sleep(1200);
    const first = await page.evaluate(MEASURE);
    const out: any = { mode, status: res?.status() ?? 0, settled, imageRequests, first };
    if (mode === "real" && first) {
      if (shot) await page.screenshot({ path: shot, type: "jpeg", quality: 62, clip: { x: 0, y: 0, width: 1440, height: Math.min(first.H, 2700) }, captureBeyondViewport: true }).catch(() => undefined);
      const steps = Math.min(8, Math.ceil(first.H / 900));
      for (let k = 1; k <= steps; k++) { await page.evaluate(`window.scrollTo(0, ${k * 900})`); await sleep(450); }
      await page.evaluate(`window.scrollTo(0, 0)`);
      await sleep(600);
      out.scrolled = await page.evaluate(MEASURE);
    }
    return out;
  } finally {
    clearTimeout(kill);
    const closing = browser.close().catch(() => undefined);
    if ((await Promise.race([closing.then(() => "closed"), sleep(3000).then(() => "stuck")])) === "stuck") browser.process()?.kill("SIGKILL");
  }
}

const todo = PAGES.filter(([id]) => !only.length || only.includes(id)).filter(([id]) => !existsSync(join(outDir, `${id}.json`)));
let next = 0;
async function worker() {
  for (;;) {
    const job = todo[next++];
    if (!job) return;
    const [id, url] = job;
    const t0 = Date.now();
    const rec: any = { id, url, at: new Date().toISOString() };
    if (!existsSync(join(snapDir, `${id}.js.json`))) {
      try { const snap = await captureWithLocalBrowser(new URL(url), { measure: true, javascript: true }); writeFileSync(join(snapDir, `${id}.js.json`), JSON.stringify(snap)); rec.snapshot = `${snap.stats.elementCount} elements`; }
      catch (e) { rec.snapshot = `failed: ${(e as Error).message}`; }
    } else rec.snapshot = "kept";
    for (const mode of ["placeholder", "real"] as const) {
      try { rec[mode] = await Promise.race([session(url, mode, mode === "real" ? join(outDir, `${id}.jpg`) : undefined), sleep(85000).then(() => { throw new Error("probe timed out"); })]); }
      catch (e) { rec[mode] = { error: (e as Error).message.slice(0, 120) }; }
    }
    writeFileSync(join(outDir, `${id}.json`), JSON.stringify(rec));
    const n = (m: any) => (m?.first ? `${m.first.imgs.length} img/${m.first.bgs.length} bg` : `× ${m?.error ?? "none"}`);
    console.log(`${id.padEnd(15)} snapshot ${String(rec.snapshot).padEnd(22)} placeholder ${n(rec.placeholder).padEnd(18)} real ${n(rec.real).padEnd(18)} scrolled ${rec.real?.scrolled ? rec.real.scrolled.imgs.length + " img" : "-"} · ${Math.round((Date.now() - t0) / 1000)} s`);
  }
}
await Promise.all(Array.from({ length: Number(process.env.WORKERS ?? 4) }, () => worker()));
console.log(`done ${group}`);
