import type { DomSnapshot, SnapshotNode } from "./types";

export function pruneUnseen(snapshot: DomSnapshot): DomSnapshot {
  if (!snapshot.layout) return snapshot;
  const shown = (n: SnapshotNode): boolean => !!n.box || n.children.some(shown);
  const keep = (n: SnapshotNode): SnapshotNode | null => (n.unseen && !shown(n) ? null : { ...n, children: n.children.map(keep).filter((c): c is SnapshotNode => c !== null) });
  return { ...snapshot, root: keep(snapshot.root) ?? { ...snapshot.root, children: [] } };
}
