import type { NNode, NormalizedDocument } from "../../model/types";
import { scopeOf } from "./structure";

export type Arrangement = "strip" | "grid" | "tiles";

export interface Series {
  arrangement: Arrangement;
  units: number;
  width: number;
  height: number;
  perRow: number;
  rows: number;
  groups: number;
  head: number;
  sizes: Array<[number, number]>;
}

const TILE = 72;
const MIN_UNITS = 4;
const MIN_PICTURE = 24;
const WRAP = 6;

interface Unit {
  x: number;
  y: number;
  w: number;
  h: number;
}

const median = (v: number[]) => (v.length ? [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] : 0);

export function seriesOf(doc: NormalizedDocument, scope: { roots: number[]; excluded: number[] }): Series | null {
  const nodes = doc.nodes;
  const ids = scopeOf(nodes, scope.roots, scope.excluded);
  const inScope = new Set(ids);
  const boxed = (n: NNode): n is NNode & { box: [number, number, number, number] } => !!n.box && !n.cluster;
  const pictures = ids.filter((i) => nodes[i].role === "image" && boxed(nodes[i]) && nodes[i].box![2] >= MIN_PICTURE && nodes[i].box![3] >= MIN_PICTURE);
  const prefix = new Int32Array(nodes.length + 1);
  const isPicture = new Set(pictures);
  for (let i = 0; i < nodes.length; i++) prefix[i + 1] = prefix[i] + (isPicture.has(i) ? 1 : 0);
  const held = (i: number) => prefix[nodes[i].end] - prefix[i];

  const cards: Unit[] = [];
  const seen = new Set<number>();
  for (const i of pictures) {
    const area = nodes[i].box![2] * nodes[i].box![3];
    let at = i;
    for (let p = nodes[at].parent; p >= 0 && inScope.has(p) && boxed(nodes[p]) && held(p) === 1 && nodes[p].box![2] * nodes[p].box![3] <= WRAP * area; p = nodes[p].parent) at = p;
    if (seen.has(at)) continue;
    seen.add(at);
    const b = nodes[at].box!;
    cards.push({ x: b[0], y: b[1], w: b[2], h: b[3] });
  }
  const keys: Unit[] = ids
    .filter((i) => (nodes[i].role === "button" || nodes[i].role === "control") && boxed(nodes[i]) && nodes[i].box![2] <= TILE && nodes[i].box![3] <= TILE && nodes[i].box![2] >= 12 && nodes[i].box![3] >= 12)
    .map((i) => ({ x: nodes[i].box![0], y: nodes[i].box![1], w: nodes[i].box![2], h: nodes[i].box![3] }));

  const small = cards.filter((u) => u.w <= TILE && u.h <= TILE);
  const large = cards.filter((u) => u.w > TILE || u.h > TILE);
  const tiles = [...small, ...keys];
  const tiled = tiles.length >= MIN_UNITS && tiles.length >= 2 * large.length;
  const pool = tiled ? tiles : large;
  if (pool.length < MIN_UNITS) return null;

  const width = median(pool.map((u) => u.w));
  const alike = pool.filter((u) => Math.abs(u.w - width) <= 0.35 * width).sort((a, b) => a.y - b.y || a.x - b.x);
  if (alike.length < MIN_UNITS) return null;
  const height = median(alike.map((u) => u.h));

  const lines: Unit[][] = [];
  for (const u of alike) {
    const line = lines[lines.length - 1];
    if (line && Math.abs(u.y - line[0].y) <= 0.5 * height) line.push(u);
    else lines.push([u]);
  }
  const perRow = median(lines.map((l) => l.length));
  if (perRow < 2) return null;

  const headings = ids.filter((i) => nodes[i].heading && boxed(nodes[i]) && nodes[i].fontSize).map((i) => ({ y: nodes[i].box![1], px: nodes[i].fontSize! }));
  const heads: number[] = [];
  let groups = 1;
  const first = headings.filter((h) => h.y < lines[0][0].y && h.y >= lines[0][0].y - 2 * height);
  if (first.length) heads.push(Math.max(...first.map((h) => h.px)));
  for (let k = 1; k < lines.length; k++) {
    const above = lines[k - 1][0].y + lines[k - 1][0].h;
    const between = headings.filter((h) => h.y >= above - 4 && h.y < lines[k][0].y);
    if (!between.length) continue;
    groups++;
    heads.push(Math.max(...between.map((h) => h.px)));
  }
  const body = median(ids.filter((i) => nodes[i].fontSize && nodes[i].ownChars > 0).map((i) => nodes[i].fontSize!)) || 16;
  const rows = Math.max(1, Math.round(lines.length / groups));

  return {
    arrangement: tiled ? "tiles" : rows <= 1 ? "strip" : "grid",
    units: alike.length,
    width,
    height,
    perRow,
    rows,
    groups,
    head: heads.length ? median(heads) / body : 0,
    sizes: alike.slice(0, 32).map((u) => [u.w, u.h]),
  };
}
