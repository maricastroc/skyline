import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { simpleIndex } = await import(join(root, "src/lib/pixelcity/kit/compose.ts"));
const { itemsOf } = await import(join(import.meta.dirname, "items-nodes.ts"));

const med = (v: number[]) => (v.length ? [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] : 0);
const cv = (v: number[]) => {
  if (v.length < 2) return 0;
  const m = v.reduce((s, x) => s + x, 0) / v.length;
  return m ? Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / v.length) / m : 0;
};

export function measure(nodes: any[], ids: number[], scope: Set<number>) {
  const b = ids.map((i) => nodes[i]).filter((n) => n.box && !n.cluster);
  if (b.length < 3) return null;
  const w = med(b.map((n) => n.box[2]));
  const h = med(b.map((n) => n.box[3]));
  const parents = [...new Set(b.map((n) => n.parent))];
  const perRow: number[] = [];
  const rowsPer: number[] = [];
  for (const p of parents) {
    const rows = new Map<number, number>();
    for (const n of b.filter((x) => x.parent === p)) {
      const key = Math.round(n.box[1] / Math.max(h * 0.5, 8));
      rows.set(key, (rows.get(key) ?? 0) + 1);
    }
    perRow.push(...rows.values());
    rowsPer.push(rows.size);
  }
  let ink = 0, pictures = 0;
  for (const n of b) for (let k = n.id; k < n.end; k++) { ink += nodes[k].ink ?? 0; }
  for (const n of b) pictures += n.images > 0 ? 1 : 0;
  const area = b.reduce((s, n) => s + n.box[2] * n.box[3], 0) || 1;
  const heads: number[] = [];
  for (const p of parents) {
    let px = 0;
    const chain = [p, nodes[p].parent].filter((x) => x >= 0);
    for (const c of chain) {
      const up = nodes[c].parent;
      if (up < 0) continue;
      const sibs = nodes[up].children;
      const at = sibs.indexOf(c);
      for (let j = at - 1; j >= Math.max(0, at - 2) && !px; j--) for (let k = sibs[j]; k < nodes[sibs[j]].end; k++) if (nodes[k].heading && nodes[k].fontSize && nodes[k].box) px = Math.max(px, nodes[k].fontSize);
      if (px) break;
    }
    if (px) heads.push(px);
  }
  return {
    boxed: b.length, groups: parents.length, w, h, aspect: w / Math.max(h, 1), perRow: Math.max(1, med(perRow)), rows: med(rowsPer),
    cvH: cv(b.map((n) => n.box[3])), cover: Math.min(1, ink / area), pictured: pictures / b.length, heads: heads.length, headPx: med(heads),
    font: med(b.flatMap((n) => { const o: number[] = []; for (let k = n.id; k < n.end; k++) if (nodes[k].fontSize && nodes[k].ownChars > 0) o.push(nodes[k].fontSize); return o; })),
    sizes: b.slice(0, 40).map((n) => [n.box[2], n.box[3]]),
  };
}

export const measuredClass = (s: any) => (s.w <= 72 && s.h <= 72 ? "tile" : s.perRow <= 1 ? (s.aspect >= 3 ? "row" : "block") : s.aspect < 0.67 ? "portrait" : "card");
export const domClass = (f: any) => (f.controlsPerItem >= 0.5 && f.charsPerItem < 24 ? "tile" : f.mediaPerItem >= 0.5 ? "card" : f.charsPerItem >= 300 ? "block" : "row");

if (process.argv[1]?.endsWith("anatomy2.mts")) {
  const out: any[] = [];
  console.log("page".padEnd(11), "lots", "fabric".padEnd(11), "| what the plan holds: repeat → houses per row; item form; groups".padEnd(84), "| measured on screen → class (class from the DOM alone)");
  for (const id of ids) {
    const f = join(dir, `${id}.js.json`);
    if (!existsSync(f)) continue;
    const p = realPage(JSON.parse(readFileSync(f, "utf8")));
    const nodes = p.doc.nodes;
    const a = allocate(p.plan);
    p.plan.territories.forEach((t: any, i: number) => {
      const lots = a.lots[i] ?? 0;
      if (lots < 16 || !t.scope) return;
      const top = [...t.mix].sort((x: any, y: any) => y.share - x.share)[0].comp;
      const scope = new Set<number>(scopeOf(nodes, t.scope.roots, t.scope.excluded));
      const form = itemsOf(p.doc, t.scope.roots, t.scope.excluded, t.structure);
      const region = t.region >= 0 ? p.sem.regions[t.region] : null;
      const fromForm = form.source === "series" ? measure(nodes, form.nodes, scope) : null;
      const fromRegion = region && region.items.length >= 3 ? measure(nodes, region.items, scope) : null;
      const s = fromForm ?? fromRegion;
      const units = Math.max(2, Math.min(6, Math.round(2 + t.repeat / 6)));
      const known = `rep ${t.repeat} → ${units}/row; ${form.source === "series" ? `${form.count} × ${form.shape}, ${Math.round(form.charsPerItem)} chars, ${form.linksPerItem.toFixed(1)} links, ${form.mediaPerItem.toFixed(1)} img` : "no series"}; ${t.structure?.groups.length ?? 0} groups${simpleIndex(t) ? "; index" : ""}`;
      const row: any = { id, i, lots, comp: top, repeat: t.repeat, units, form: form.source === "series" ? { count: form.count, shape: form.shape, chars: form.charsPerItem, links: form.linksPerItem, media: form.mediaPerItem, controls: form.controlsPerItem, parents: form.parents } : null, groupsKnown: t.structure?.groups.length ?? 0, series: s, label: (t.label ?? t.kind).slice(0, 24) };
      if (s) row.cls = measuredClass(s);
      if (form.source === "series") row.dom = domClass(form);
      out.push(row);
      console.log(id.padEnd(11), `${lots}`.padStart(4), top.padEnd(11), `| ${known}`.padEnd(84), s ? `| ${s.boxed} in ${s.groups} group(s): ${s.w}×${s.h}, ${s.perRow}/row × ${s.rows} rows, ${Math.round(s.pictured * 100)}% pictured, head ${s.headPx || "-"} px → ${row.cls} (${row.dom ?? "-"})` : "| nothing measurable");
    });
  }
  writeFileSync(join(dir, "anatomy.json"), JSON.stringify(out));
}
