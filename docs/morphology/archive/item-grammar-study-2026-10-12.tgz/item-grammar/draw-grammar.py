import sys
from PIL import Image, ImageDraw, ImageFont

out = sys.argv[1]
BG, FG, MUTED, PANEL = (18, 18, 22), (240, 240, 240), (150, 150, 160), (30, 30, 36)
TEXT, PICT, TILE, BLOCK = (224, 142, 69), (150, 104, 196), (104, 178, 104), (86, 132, 201)
GROUND, YARD, PLAZA, HEAD = (58, 58, 66), (86, 128, 86), (190, 180, 150), (214, 72, 72)
f = ImageFont.load_default(size=14)
fs = ImageFont.load_default(size=12)
fb = ImageFont.load_default(size=19)
U = 10

CASES = [
    dict(name="Hacker News (controle)", fabric="sobrados", w=700, h=19, per=1, rows=30, groups=1, head=0, body=13, pict=False, today=("terraces", 6), note="30 linhas de 700x19, uma por fileira"),
    dict(name="Python docs (controle)", fabric="quadras", w=800, h=351, per=1, rows=9, groups=1, head=32, body=16, pict=False, today=("court", 0), note="blocos de 800x351, um por fileira"),
    dict(name="Spotify", fabric="midia", w=168, h=212, per=8, rows=1, groups=8, head=24, body=16, pict=True, today=("tower", 0), note="8 carrosseis de 8 cartoes de 168x212"),
    dict(name="Airbnb", fabric="midia", w=180, h=240, per=8, rows=1, groups=7, head=14, body=12, pict=True, today=("tower", 0), note="carrosseis de 8 cartoes de 180x240"),
    dict(name="IKEA", fabric="midia", w=232, h=434, per=3, rows=5, groups=1, head=40, body=16, pict=True, today=("tower", 0), note="grade de 3 por fileira, 232x434"),
    dict(name="Pinterest", fabric="midia", w=273, h=276, per=5, rows=4, groups=1, head=0, body=12, pict=True, today=("tower", 0), note="grade de 5 por fileira, 273x276"),
    dict(name="Apple", fabric="midia", w=702, h=580, per=2, rows=3, groups=1, head=56, body=17, pict=True, today=("tower", 0), note="grade de 2 por fileira, 702x580"),
    dict(name="Excalidraw", fabric="midia", w=36, h=36, per=13, rows=1, groups=3, head=0, body=16, pict=True, today=("tower", 0), note="13 teclas de 36x36; o resto e palco"),
]

def arrangement(c):
    if c["w"] <= 72 and c["h"] <= 72: return "teclas"
    if c["per"] <= 1: return "pilha" if c["w"] / c["h"] >= 3 else "blocos"
    return "faixa" if c["rows"] <= 1 else "grade"

def page_panel(d, c, x, y, W=250, H=150):
    d.rectangle([x, y, x + W, y + H], fill=(246, 246, 242))
    n = min(c["per"], 13)
    rows = min(c["rows"], 7 if c["per"] == 1 else 2)
    gap = 3 if c["per"] == 1 else 2
    sc = min((W - 20) / (n * c["w"] * 1.08), (H - 40 - rows * gap) / (rows * c["h"]), 1.2)
    ox, oy = x + 10, y + 8
    if c["head"]:
        hh = max(6, c["head"] * sc * 0.9)
        d.rectangle([ox, oy, ox + min(W - 20, c["head"] * sc * 7), oy + hh], fill=(60, 60, 70))
        oy += hh + 6
    col = TILE if arrangement(c) == "teclas" else PICT if c["pict"] else BLOCK if arrangement(c) == "blocos" else TEXT
    for r in range(rows):
        for k in range(n):
            bx = ox + k * c["w"] * 1.08 * sc
            by = oy + r * (c["h"] * sc + gap)
            d.rectangle([bx, by, bx + max(2, c["w"] * sc), by + max(2, c["h"] * sc)], fill=col)

def block(d, x, y):
    d.rectangle([x, y, x + 14 * U, y + 14 * U], fill=GROUND)

def rect(d, x, y, a, b, w, h, col):
    d.rectangle([x + a * U, y + b * U, x + (a + w) * U - 1, y + (b + h) * U - 1], fill=col, outline=(14, 14, 18))

def plan_today(d, c, x, y):
    kind, units = c["today"]
    block(d, x, y)
    if kind == "terraces":
        rect(d, x, y, 4.2, 4.2, 5.6, 5.6, YARD)
        for (a, b, w, h, horiz) in ((4.3, 10, 5.4, 4, True), (4.3, 0, 5.4, 4, True), (0, 4.3, 4, 5.4, False), (10, 4.3, 4, 5.4, False)):
            for k in range(units):
                if horiz: rect(d, x, y, a + k * w / units, b, w / units, h, TEXT)
                else: rect(d, x, y, a, b + k * h / units, w, h / units, TEXT)
        for (a, b) in ((0, 0), (10, 0), (0, 10), (10, 10)): rect(d, x, y, a, b, 4, 4, (200, 120, 60))
        return [(14 / 16.0, 5.7)] * 16
    if kind == "court":
        rect(d, x, y, 0, 0, 14, 14, BLOCK)
        rect(d, x, y, 3.6, 3.6, 6.8, 6.8, YARD)
        return [(14, 6.0)]
    rect(d, x, y, 0, 0, 14, 14, PLAZA)
    rect(d, x, y, 0.1, 5.9, 8, 8, PICT)
    rect(d, x, y, 8.9, 0.1, 5, 5, (120, 90, 160))
    return [(8, 11.5), (1, 0), (5, 4.0)]

def plan_grammar(d, c, x, y):
    arr = arrangement(c)
    block(d, x, y)
    aspect = c["w"] / c["h"]
    ratio = c["head"] / c["body"] if c["head"] else 0
    col = PICT if c["pict"] else TEXT
    if arr == "pilha": return plan_today(d, c, x, y), arr
    if arr == "blocos":
        rect(d, x, y, 0, 0, 14, 14, BLOCK)
        rect(d, x, y, 3.6, 3.6, 6.8, 6.8, YARD)
        return [(14, 6.0)], arr
    if arr == "teclas":
        rect(d, x, y, 0, 0, 14, 14, PLAZA)
        k = min(c["per"], 8)
        for i in range(k): rect(d, x, y, 0.4 + i * 13.2 / k, 12.4, 13.2 / k - 0.3, 1.2, TILE)
        return [(13.2 / k - 0.3, 1.1), (0.3, 0)] * k, arr
    n = min(c["per"], 8)
    head = ratio >= 1.25
    if arr == "faixa":
        rect(d, x, y, 0, 0, 14, 9.6, YARD)
        span = 14 - (3.2 if head else 0)
        fw = span / n
        hu = max(1.5, min(9, (14 / n) / aspect))
        el = []
        if head:
            rect(d, x, y, 0, 9.8, 3.2, 4.2, HEAD)
            el.append((3.2, min(11, max(hu + 1, hu * ratio))))
        for i in range(n): rect(d, x, y, (3.2 if head else 0) + i * fw, 9.8, fw, 4.2, col)
        return el + [(fw, hu)] * n, arr
    fw = (14 - 0.5 * (n - 1)) / n
    depth = min(fw, 4.0)
    m = max(1, int((14 + 0.5) // (depth + 0.5)))
    hu = max(1.5, min(9, fw / aspect))
    for r in range(m):
        for i in range(n): rect(d, x, y, i * (fw + 0.5), 14 - depth - r * (depth + 0.5), fw, depth, col)
    el = []
    for i in range(n):
        el.append((fw, hu))
        if i < n - 1: el.append((0.5, 0))
    if head: el[0] = (fw, min(11, max(hu + 1, hu * ratio)))
    return el, arr

def elevation(d, el, x, y, colour):
    base = y + 12 * U
    d.line([x, base, x + 14 * U, base], fill=MUTED)
    cx = x
    for w, h in el:
        if h > 0: d.rectangle([cx, base - h * U, cx + w * U - 1, base - 1], fill=colour, outline=(14, 14, 18))
        cx += w * U

CW, CH = 250 + 2 * (14 * U + 14 * U + 26) + 60, 224
img = Image.new("RGB", (CW + 28, len(CASES) * CH + 70), BG)
d = ImageDraw.Draw(img)
d.text((14, 12), "esquema a partir dos numeros medidos; nao e a cidade renderizada", fill=MUTED, font=f)
X0 = 14
XT = X0 + 250 + 30
XG = XT + 2 * 14 * U + 26 + 30
for k, (label, xx) in enumerate((("um grupo na pagina", X0), ("hoje: planta e fachada de uma quadra", XT), ("pela estrutura dos itens: planta e fachada", XG))):
    d.text((xx, 38), label, fill=MUTED, font=f)
for i, c in enumerate(CASES):
    y = 64 + i * CH
    d.text((X0, y), c["name"], fill=FG, font=fb)
    d.text((X0, y + 24), c["note"], fill=MUTED, font=fs)
    page_panel(d, c, X0, y + 44)
    el = plan_today(d, c, XT, y + 44)
    elevation(d, el, XT + 14 * U + 26, y + 44 + 20, PICT if c["today"][0] == "tower" else TEXT if c["today"][0] == "terraces" else BLOCK)
    d.text((XT, y + 24), {"terraces": "fileiras: %d casas por fileira" % c["today"][1], "court": "quadra perimetral", "tower": "torre e anexo em cada peca"}[c["today"][0]], fill=MUTED, font=fs)
    el2, arr = plan_grammar(d, c, XG, y + 44)
    elevation(d, el2, XG + 14 * U + 26, y + 44 + 20, PICT if c["pict"] and arr not in ("teclas",) else TILE if arr == "teclas" else TEXT if arr == "pilha" else BLOCK)
    same = arr in ("pilha", "blocos")
    d.text((XG, y + 24), {"pilha": "pilha: igual a hoje", "blocos": "blocos: igual a hoje", "faixa": "faixa: uma rua de %d frentes por grupo" % min(c["per"], 8), "grade": "grade: %d modulos por fileira" % min(c["per"], 8), "teclas": "teclas: quiosques na borda de uma praca"}[arr], fill=FG if not same else MUTED, font=fs)
img.save(out, quality=92)
print(out, img.size)
