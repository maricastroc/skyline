import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const med = (v: number[]) => (v.length ? [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] : 0);
const cv = (v: number[]) => { if (v.length < 2) return 0; const m = v.reduce((s, x) => s + x, 0) / v.length; return m ? Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / v.length) / m : 0; };

export function unitsOf(nodes: any[], scope: number[]) {
  const inScope = new Set(scope);
  let hull: number[] | null = null;
  for (const k of scope) { const b = nodes[k].box; if (!b) continue; hull = hull ? [Math.min(hull[0], b[0]), Math.min(hull[1], b[1]), Math.max(hull[2], b[0] + b[2]), Math.max(hull[3], b[1] + b[3])] : [b[0], b[1], b[0] + b[2], b[1] + b[3]]; }
  if (!hull) return [];
  const pools = new Map<string, any[]>();
  for (const p of scope) {
    const kids = nodes[p].children.filter((c: number) => inScope.has(c) && nodes[c].box && !nodes[c].cluster);
    const byTag = new Map<string, number[]>();
    for (const c of kids) byTag.set(nodes[c].tag, [...(byTag.get(nodes[c].tag) ?? []), c]);
    for (const [tag, cs] of byTag) {
      if (cs.length < 3) continue;
      const key = `${nodes[p].tag} > ${tag}`;
      pools.set(key, [...(pools.get(key) ?? []), ...cs.map((id) => ({ id, parent: p }))]);
    }
  }
  const out: any[] = [];
  for (const [shape, members] of pools) {
    if (members.length < 4) continue;
    const b = members.map((m) => nodes[m.id]);
    const w = med(b.map((n) => n.box[2])), h = med(b.map((n) => n.box[3]));
    const alike = b.filter((n) => Math.abs(n.box[2] - w) <= 0.35 * w && Math.abs(n.box[3] - h) <= 0.5 * h);
    if (alike.length < 4 || alike.length < 0.6 * b.length) continue;
    const parents = [...new Set(members.map((m) => m.parent))];
    const perRow: number[] = [], rowsPer: number[] = [];
    for (const p of parents) {
      const rows = new Map<number, number>();
      for (const n of alike.filter((x) => x.parent === p)) { const key = Math.round(n.box[1] / Math.max(h * 0.5, 8)); rows.set(key, (rows.get(key) ?? 0) + 1); }
      if (rows.size) { perRow.push(...rows.values()); rowsPer.push(rows.size); }
    }
    let x0 = Infinity, y0 = Infinity, x1 = 0, y1 = 0;
    for (const n of alike) { x0 = Math.min(x0, n.box[0]); y0 = Math.min(y0, n.box[1]); x1 = Math.max(x1, n.box[0] + n.box[2]); y1 = Math.max(y1, n.box[1] + n.box[3]); }
    const weight = alike.reduce((s, n) => s + n.weight, 0);
    const heads: number[] = [];
    for (const p of parents) {
      let px = 0;
      for (const c of [p, nodes[p].parent, nodes[nodes[p].parent]?.parent].filter((x) => x !== undefined && x >= 0)) {
        const up = nodes[c].parent; if (up < 0) continue;
        const sibs = nodes[up].children; const at = sibs.indexOf(c);
        for (let j = at - 1; j >= Math.max(0, at - 2) && !px; j--) for (let k = sibs[j]; k < nodes[sibs[j]].end; k++) if (nodes[k].heading && nodes[k].fontSize && nodes[k].box) px = Math.max(px, nodes[k].fontSize);
        if (px) break;
      }
      if (px) heads.push(px);
    }
    out.push({ shape, n: alike.length, groups: parents.length, w, h, aspect: w / Math.max(h, 1), perRow: Math.max(1, med(perRow)), rows: med(rowsPer), span: [(x1 - x0), (y1 - y0)], fill: alike.reduce((s, n) => s + n.box[2] * n.box[3], 0) / Math.max((hull[2] - hull[0]) * (hull[3] - hull[1]), 1), weight, pictured: alike.filter((n) => n.images > 0).length / alike.length, chars: med(alike.map((n) => n.chars)), controls: alike.reduce((s, n) => s + n.controls, 0) / alike.length, cvH: cv(alike.map((n) => n.box[3])), headPx: med(heads), heads: heads.length, font: med(alike.flatMap((n) => { const o: number[] = []; for (let k = n.id; k < n.end; k++) if (nodes[k].fontSize && nodes[k].ownChars > 0) o.push(nodes[k].fontSize); return o; })), sample: alike.slice(0, 24).map((n) => n.box) });
  }
  const total = scope.reduce((s, i) => s + nodes[i].selfWeight, 0) || 1;
  for (const o of out) o.share = o.weight / total;
  return out.sort((a, b) => b.share - a.share);
}

if (process.argv[1]?.endsWith("units.mts")) {
  const all: any[] = [];
  for (const id of ids) {
    const f = join(dir, `${id}.js.json`);
    if (!existsSync(f)) continue;
    const p = realPage(JSON.parse(readFileSync(f, "utf8")));
    const nodes = p.doc.nodes;
    const a = allocate(p.plan);
    p.plan.territories.forEach((t: any, i: number) => {
      const lots = a.lots[i] ?? 0;
      if (lots < 24 || !t.scope) return;
      const top = [...t.mix].sort((x: any, y: any) => y.share - x.share)[0].comp;
      const u = unitsOf(nodes, scopeOf(nodes, t.scope.roots, t.scope.excluded)).filter((s) => s.share >= 0.25).slice(0, 3);
      console.log(`${id} · ${top} ${lots} lots · rep ${t.repeat}`);
      for (const s of u) console.log(`    ${s.shape.padEnd(16)} ${String(s.n).padStart(3)} alike in ${s.groups} group(s) · ${s.w}×${s.h} (${s.aspect.toFixed(2)}) · ${s.perRow}/row × ${s.rows} · weight ${Math.round(s.share * 100)}% · fills ${Math.round(s.fill * 100)}% · pictured ${Math.round(s.pictured * 100)}% · ${Math.round(s.chars)} chars · head ${s.headPx || "-"}/${s.font || "-"} px`);
      all.push({ id, lots, comp: top, repeat: t.repeat, units: u });
    });
  }
  writeFileSync(join(dir, "units.json"), JSON.stringify(all));
}
