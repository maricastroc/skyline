// Runs the current reading and the new one on the same snapshots, side by side. Neither result reaches a city.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...specs] = process.argv.slice(2); // set:id=path
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { seriesOf, unitsOf } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
const slim = (s: any) => (s ? { arrangement: s.arrangement, units: s.units, w: Math.round(s.width), h: Math.round(s.height), per: s.perRow, rows: s.rows, groups: s.groups, head: Math.round(s.head * 100) / 100, kind: s.kind ?? null } : null);
const rows: any[] = [];
for (const spec of specs) {
  const [left, file] = spec.split("=");
  const [set, id] = left.split(":");
  if (!existsSync(file)) { console.log("missing", file); continue; }
  const p = realPage(JSON.parse(readFileSync(file, "utf8")), "none", parseExperiments("ensemble"));
  const alloc = allocate(p.plan);
  p.plan.territories.forEach((t: any, i: number) => {
    if (!t.scope || alloc.lots[i] < 4) return;
    const again = seriesOf(p.doc, t.scope);
    if (JSON.stringify(slim(again)) !== JSON.stringify(slim(t.series ?? null))) throw new Error(`${id} T${i}: the plan's reading and the reference differ`);
    rows.push({ set, page: id, territory: i, lots: alloc.lots[i], mix: t.mix.map((m: any) => m.comp).join("+"), label: (t.label ?? t.kind).slice(0, 30), old: slim(t.series ?? null), new: slim(unitsOf(p.doc, t.scope)) });
  });
}
writeFileSync(out, JSON.stringify(rows));
console.log(`${rows.length} territories → ${out}`);
