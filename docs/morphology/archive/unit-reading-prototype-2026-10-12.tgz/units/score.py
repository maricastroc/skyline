# Scores both readings against the units written down beforehand.
import json, sys, collections
truth_file, compare_file = sys.argv[1], sys.argv[2]
sets = sys.argv[3].split(",") if len(sys.argv) > 3 else None
verbose = "-v" in sys.argv
T = json.load(open(truth_file)); tol = T["tolerance"]
C = {(r["set"], r["page"], r["territory"]): r for r in json.load(open(compare_file))}
def same(s, u, alt=None):
    for cand in [u] + ([alt] if alt else []):
        if abs(s["w"] - cand["w"]) <= tol["w"] * cand["w"] and abs(s["h"] - cand["h"]) <= tol["h"] * cand["h"]: return True
    return False
def verdict(s, t):
    u = t["unit"]
    if u == "none": return "right" if s is None else "extra"
    if u == "outside the capture": return "missed" if s is None else "wrong"
    if s is None: return "missed"
    return "right" if same(s, u, t.get("alt")) else "wrong"
def level(s, u):
    a, b = s["w"] * s["h"], u["w"] * u["h"]
    return "deeper" if a < b / 1.6 else "shallower" if a > b * 1.6 else "same size"
out = {}
for which in ["old", "new"]:
    R = collections.OrderedDict()
    for t in T["territories"]:
        if sets and t["set"] not in sets: continue
        if not t["scored"]: continue
        c = C.get((t["set"], t["page"], t["territory"]))
        if c is None: print("no comparison row for", t["set"], t["page"], t["territory"]); continue
        s = c[which]; v = verdict(s, t); u = t["unit"]
        row = dict(t=t, s=s, v=v)
        if isinstance(u, dict) and s is not None:
            row["level"] = "right" if v == "right" else level(s, u)
            if v == "right":
                row["per"] = abs(s["per"] - u["per"]) <= tol["per"]
                if u.get("kind") and which == "new": row["kind"] = s["kind"] == u["kind"]
                if u.get("kind") and which == "old": row["kind"] = (s["arrangement"] == "tiles") == (u["kind"] == "key")
                if u.get("arr"): row["arr"] = (s["arrangement"] == u["arr"]) if u["arr"] != "tiles" else s["arrangement"] == "tiles"
        R[(t["set"], t["page"], t["territory"])] = row
    out[which] = R
def summary(R, name):
    rows = list(R.values())
    produced = [r for r in rows if r["s"] is not None]
    withunit = [r for r in rows if r["t"]["truth"] == "C"]
    keys = [r for r in rows if r["t"]["truth"] == "K"]
    nounit = [r for r in rows if r["t"]["unit"] == "none"]
    right = lambda rs: sum(r["v"] == "right" for r in rs)
    frac = lambda a, b: f"{a}/{b}" + (f" ({round(100*a/b)}%)" if b else "")
    lv = collections.Counter(r.get("level") for r in produced if isinstance(r["t"]["unit"], dict))
    print(f"  {name:4} precision {frac(right(produced), len(produced))} · coverage of content units {frac(right(withunit), len(withunit))} · key territories {frac(right(keys), len(keys))} · no unit, no series {frac(right(nounit), len(nounit))}"
          f" · level: right {lv['right']}, deeper {lv['deeper']}, shallower {lv['shallower']}, same size {lv['same size']}"
          f" · kind {frac(sum(1 for r in rows if r.get('kind') is True), sum(1 for r in rows if 'kind' in r))} · per row {frac(sum(1 for r in rows if r.get('per') is True), sum(1 for r in rows if 'per' in r))} · strip/grid {frac(sum(1 for r in rows if r.get('arr') is True), sum(1 for r in rows if 'arr' in r))}")
for label, pick in [("known", ["known"]), ("unseen", ["unseen"]), ("fresh", ["fresh"]), ("unseen+fresh", ["unseen", "fresh"])]:
    if sets and not set(pick) <= set(sets): continue
    print(label)
    for which in ["old", "new"]: summary({k: v for k, v in out[which].items() if k[0] in pick}, which)
kept = [(k, out["new"][k]) for k, r in out["old"].items() if r["v"] == "right" and r["s"] is not None]
lost = [(k, r) for k, r in kept if r["v"] != "right"]
print(f"series the old reading had right: {len(kept)} · still right: {len(kept)-len(lost)} · lost: {[(k[1], k[2], r['v']) for k, r in lost]}")
gained = [(k[1], k[2]) for k, r in out["new"].items() if r["v"] == "right" and r["s"] is not None and out["old"][k]["v"] != "right"]
print(f"gained: {len(gained)} {gained}")
if verbose:
    f = lambda s: "-" if s is None else f"{s['arrangement'][:5]} {s['w']}x{s['h']} {s['per']}/row n{s['units']}" + (f" {s['kind']}" if s.get("kind") else "")
    for k, r in out["new"].items():
        o = out["old"][k]; u = r["t"]["unit"]
        tu = u if isinstance(u, str) else f"{u['w']}x{u['h']} {u['per']}/row {u['kind'] or '?'}"
        flag = "" if r["v"] == o["v"] else "  <<"
        print(f"  {k[0]:6} {k[1]:12} T{k[2]:<2} truth {tu:26} | old {f(o['s']):34} {o['v']:6} | new {f(r['s']):40} {r['v']:6} {r.get('level','') if r['v']=='wrong' else ''}{flag}")
json.dump({w: [dict(set=k[0], page=k[1], territory=k[2], verdict=r["v"], level=r.get("level"), kind=r.get("kind"), per=r.get("per"), arr=r.get("arr"), series=r["s"]) for k, r in R.items()] for w, R in out.items()}, open(compare_file.replace(".json", "-scored.json"), "w"))
