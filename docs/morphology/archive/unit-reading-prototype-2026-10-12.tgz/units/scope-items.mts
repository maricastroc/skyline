// Explanation only: what the capture holds inside one territory.
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, file, ti] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const p = realPage(JSON.parse(readFileSync(file, "utf8")), "none", parseExperiments("ensemble"));
const t = p.plan.territories[Number(ti)];
const nodes = p.doc.nodes;
const ex = new Set<number>(t.scope.excluded);
const seen: number[] = [];
const walk = (i: number) => { if (ex.has(i)) return; seen.push(i); for (const c of nodes[i].children) walk(c); };
for (const r of t.scope.roots) walk(r);
console.log(`T${ti} ${t.lots?.length ?? "?"} lots · roots`, t.scope.roots.map((r: number) => `${nodes[r].selector} ${JSON.stringify(nodes[r].box)}`).join(" ; "), "· nodes in scope", seen.length);
const by = new Map<string, number[]>();
for (const i of seen) { const n = nodes[i]; const k = `${n.role}|${n.tag}|${n.box ? "boxed" : "unboxed"}${n.cluster ? `|cluster×${n.cluster.count}` : ""}`; by.set(k, [...(by.get(k) ?? []), i]); }
for (const [k, list] of [...by].sort((a, b) => b[1].length - a[1].length).slice(0, 14)) {
  const first = nodes[list[0]];
  console.log(`  ${String(list.length).padStart(4)} × ${k.padEnd(34)} e.g. ${first.selector} ${JSON.stringify(first.box ?? null)} under ${nodes[first.parent]?.selector}`);
}
