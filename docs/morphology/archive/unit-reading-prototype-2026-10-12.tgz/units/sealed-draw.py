# Labelling sheet for the sealed pages: the live page and the territories only. No reading is drawn.
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
probe_dir, plain_json, out, cols = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
ids = sys.argv[5:]
SC, PW, PH, GAP = 0.25, 360, 680, 8
font = ImageFont.load_default(size=15); small = ImageFont.load_default(size=13)
plain = json.load(open(plain_json))
COL = [(226, 60, 50), (40, 120, 220), (30, 160, 90), (200, 120, 20), (150, 60, 190), (20, 150, 160), (120, 120, 120), (200, 60, 140)]
tiles = []
for pid in ids:
    tile = Image.new("RGB", (2 * PW + GAP, PH + 76), (16, 16, 20)); d = ImageDraw.Draw(tile)
    shot = os.path.join(probe_dir, pid + ".jpg")
    if os.path.exists(shot):
        im = Image.open(shot).convert("RGB"); im = im.resize((PW, round(im.height * PW / im.width)), Image.LANCZOS).crop((0, 0, PW, PH)); tile.paste(im, (0, 76))
    ox = PW + GAP
    d.rectangle([ox, 76, ox + PW, 76 + PH], fill=(248, 248, 246))
    T = plain.get(pid, {}).get("territories", [])
    for k, t in enumerate(T):
        c = COL[k % len(COL)]
        for b in t["images"]:
            if b[1] * SC < PH: d.rectangle([ox + b[0] * SC, 76 + b[1] * SC, ox + (b[0] + b[2]) * SC, 76 + min(PH, (b[1] + b[3]) * SC)], fill=(210, 212, 218))
        for b in t["roots"]:
            if b[1] * SC < PH:
                d.rectangle([ox + b[0] * SC, 76 + b[1] * SC, ox + (b[0] + b[2]) * SC, 76 + min(PH, (b[1] + b[3]) * SC)], outline=c, width=2)
                d.text((ox + b[0] * SC + 3, 76 + b[1] * SC + 2), f"T{t['i']}", fill=c, font=small)
    d.text((4, 2), pid, fill=(255, 207, 90), font=font)
    for k, t in enumerate(T[:8]):
        d.text((4 + (k % 2) * 360, 20 + 14 * (k // 2)), f"T{t['i']} {t['lots']}l {t['mix'][:16]} {t['label'][:18]} y{min([b[1] for b in t['roots']] or [0])}", fill=COL[k % len(COL)], font=small)
    tiles.append(tile)
rows = [tiles[i:i + cols] for i in range(0, len(tiles), cols)]
W = cols * (2 * PW + GAP) + (cols - 1) * 14; H = len(rows) * (PH + 76 + 12)
sheet = Image.new("RGB", (W, H), (0, 0, 0))
for r, row in enumerate(rows):
    for c, t in enumerate(row): sheet.paste(t, (c * (2 * PW + GAP + 14), r * (PH + 76 + 12)))
sheet.save(out, quality=82); print(out, sheet.size)
