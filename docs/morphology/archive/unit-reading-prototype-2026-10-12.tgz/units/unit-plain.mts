// Evidence only: the boxes of the unit the new reading selects in one territory, beside the measured pictures.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, out, ...specs] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { unitGroups } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
const res: any[] = [];
const pages = new Map<string, any>();
for (const spec of specs) {
  const [id, ti] = spec.split(":");
  if (!pages.has(id)) pages.set(id, realPage(JSON.parse(readFileSync(join(dir, `${id}.js.json`), "utf8")), "none", parseExperiments("ensemble")));
  const p = pages.get(id); const nodes = p.doc.nodes; const t = p.plan.territories[Number(ti)];
  const roots = t.scope.roots.filter((r: number) => nodes[r].box).map((r: number) => nodes[r].box);
  const groups = unitGroups(p.doc, t.scope).sort((a: any, b: any) => b.covered - a.covered);
  const best = groups.find((g: any) => g.role === "unit");
  res.push({ page: id, territory: Number(ti), roots,
    images: scopeOf(nodes, t.scope.roots, t.scope.excluded).filter((k: number) => (nodes[k].role === "image" || nodes[k].image) && nodes[k].box && !nodes[k].cluster).map((k: number) => nodes[k].box),
    unit: best ? best.members.map((i: number) => nodes[i].box) : [],
    others: groups.filter((g: any) => g !== best && g.kind).slice(0, 3).map((g: any) => ({ role: g.role, boxes: g.members.map((i: number) => nodes[i].box) })) });
}
writeFileSync(out, JSON.stringify(res));
console.log(res.length, "territories →", out);
