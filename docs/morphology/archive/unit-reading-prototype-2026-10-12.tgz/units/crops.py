# Contact sheets of the territory regions photographed on the live pages. Nothing from either reading is drawn.
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
shots, out_prefix, per = sys.argv[1], sys.argv[2], int(sys.argv[3])
plains = [json.load(open(p)) for p in sys.argv[4:]]
font = ImageFont.load_default(size=14)
TW, TH, cols = 545, 470, 4
items = []
for plain in plains:
    for pid, v in plain.items():
        for t in v["territories"]:
            f = os.path.join(shots, f"{pid}-T{t['i']}.jpg")
            if t.get("want") and os.path.exists(f):
                w = max(b[0] + b[2] for b in t["roots"]) - min(b[0] for b in t["roots"]); h = min(2200, max(b[1] + b[3] for b in t["roots"]) - min(b[1] for b in t["roots"]))
                items.append((pid, t, f, w, h))
for s in range(0, len(items), per):
    chunk = items[s:s + per]
    rows = (len(chunk) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (TW + 8), rows * (TH + 40)), (14, 14, 18)); d = ImageDraw.Draw(sheet)
    for k, (pid, t, f, w, h) in enumerate(chunk):
        x, y = (k % cols) * (TW + 8), (k // cols) * (TH + 40)
        im = Image.open(f).convert("RGB"); sc = min(TW / im.width, TH / im.height, 1.0)
        im = im.resize((max(1, round(im.width * sc)), max(1, round(im.height * sc))), Image.LANCZOS)
        sheet.paste(im, (x, y + 36))
        d.text((x + 2, y + 2), f"{pid} T{t['i']} {t['lots']}l {t['mix'][:18]}", fill=(255, 207, 90), font=font)
        d.text((x + 2, y + 18), f"{t['label'][:26]} · region {w}x{h} px, drawn {im.width}x{im.height}", fill=(200, 200, 200), font=font)
    name = f"{out_prefix}-{s // per + 1}.jpg"; sheet.save(name, quality=80); print(name, sheet.size, len(chunk))
