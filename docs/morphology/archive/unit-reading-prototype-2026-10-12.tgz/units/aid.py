# For each territory to label: sizes measured on the live page inside its region, to read dimensions off once the unit has been chosen by eye.
import json, os, sys, statistics as st, collections
plain_json, probe_dir = sys.argv[1], sys.argv[2]
plain = json.load(open(plain_json))
def inside(b, r): return b[0] + b[2] / 2 >= r[0] and b[0] + b[2] / 2 <= r[0] + r[2] and b[1] + b[3] / 2 >= r[1] and b[1] + b[3] / 2 <= r[1] + r[3]
for pid, v in plain.items():
    f = os.path.join(probe_dir, pid + ".json")
    if not os.path.exists(f): print(pid, "no probe"); continue
    R = (json.load(open(f)).get("real") or {}).get("first")
    if not R: print(pid, "no live measurement"); continue
    for t in v["territories"]:
        if not t.get("want") or not t["roots"]: continue
        imgs = [i for i in R["imgs"] if i["t"] == "img" and i["v"] and i["b"][2] >= 12 and i["b"][3] >= 12 and any(inside(i["b"], r) for r in t["roots"])]
        groups = collections.defaultdict(list)
        for i in imgs:
            r = i.get("rep")
            if r: groups[(r["sig"], r["d"])].append(r["b"])
        rows = []
        for (sig, d), bs in groups.items():
            uniq = sorted(set(map(tuple, bs)), key=lambda b: (b[1], b[0]))
            if len(uniq) < 3: continue
            lines = collections.Counter(round(b[1] / 20) for b in uniq)
            rows.append((sum(b[2] * b[3] for b in uniq), f"{sig[:26]} {round(st.median([b[2] for b in uniq]))}x{round(st.median([b[3] for b in uniq]))} n{len(uniq)} ~{st.median(sorted(lines.values()))}/row"))
        sizes = collections.Counter((round(i["b"][2] / 10) * 10, round(i["b"][3] / 10) * 10) for i in imgs).most_common(4)
        keys = [k for k in R["keys"] if any(inside(k["b"], r) for r in t["roots"])]
        print(f"{pid:12} T{t['i']:<2} {t['lots']:3}l {t['mix'][:16]:16} region {max(b[2] for b in t['roots'])}x{sum(b[3] for b in t['roots'])} | images {len(imgs)} {sizes} | small controls {len(keys)} | repeated: " + " ; ".join(r[1] for r in sorted(rows, reverse=True)[:4]))
