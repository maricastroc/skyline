// Prints every repeated group the new reading considers in a territory, with the role it was given.
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, file, ...only] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { unitGroups } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
const p = realPage(JSON.parse(readFileSync(file, "utf8")), "none", parseExperiments("ensemble"));
const alloc = allocate(p.plan);
const nodes = p.doc.nodes;
p.plan.territories.forEach((t: any, i: number) => {
  if (!t.scope || (only.length ? !only.includes(String(i)) : alloc.lots[i] < 8)) return;
  console.log(`T${i} ${alloc.lots[i]} lots ${t.mix.map((m: any) => m.comp).join("+")} “${(t.label ?? t.kind).slice(0, 30)}”`);
  for (const g of unitGroups(p.doc, t.scope).sort((a: any, b: any) => b.covered - a.covered).slice(0, 9)) {
    const m = nodes[g.members[0]];
    const avg = (f: (n: any) => number) => (g.members.reduce((s: number, k: number) => s + f(nodes[k]), 0) / g.members.length).toFixed(1);
    console.log(`   ${g.role.padEnd(8)} ${String(g.members.length).padStart(3)}+${g.hidden} × ${m.role}|${m.tag} ${Math.round(g.width)}x${Math.round(g.height)} · ${g.perRow}/row × ${g.lines.length} · kind ${g.kind} · pictured ${g.pictured.toFixed(2)} · chars ${avg((n) => n.chars)} links ${avg((n) => n.links)} images ${avg((n) => n.images)} controls ${avg((n) => n.controls)} · covered ${Math.round(g.covered / 1000)}k · level ${m.level} under ${nodes[m.parent]?.selector?.slice(0, 30)}`);
  }
});
