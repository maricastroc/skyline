import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, file, ti, which = "0"] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { unitGroups } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
const p = realPage(JSON.parse(readFileSync(file, "utf8")), "none", parseExperiments("ensemble"));
const t = p.plan.territories[Number(ti)];
const g = unitGroups(p.doc, t.scope).sort((a: any, b: any) => b.covered - a.covered)[Number(which)];
console.log(g.role, g.kind, g.members.length, "members; roots", t.scope.roots.map((r: number) => p.doc.nodes[r].box));
for (const i of g.members.slice(0, 14)) { const n = p.doc.nodes[i]; console.log("  ", n.box, n.selector, "| parent", p.doc.nodes[n.parent].selector, "| label", (n.label ?? "").slice(0, 40), "| chars", n.chars, "links", n.links, "images", n.images); }
