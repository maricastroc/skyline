// Territories and measured picture boxes of a sealed snapshot, with no reading in the output.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, out, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const res: any = {};
for (const id of ids) {
  const snap = JSON.parse(readFileSync(join(dir, `${id}.js.json`), "utf8"));
  const p = realPage(snap, "none", parseExperiments("ensemble"));
  const alloc = allocate(p.plan);
  const nodes = p.doc.nodes;
  res[id] = { layout: snap.layout, territories: p.plan.territories.map((t: any, i: number) => (t.scope && alloc.lots[i] >= 8 ? { i, lots: alloc.lots[i], mix: t.mix.map((m: any) => m.comp).join("+"), label: (t.label ?? t.kind).slice(0, 26), roots: t.scope.roots.filter((r: number) => nodes[r].box).map((r: number) => nodes[r].box), images: scopeOf(nodes, t.scope.roots, t.scope.excluded).filter((k: number) => nodes[k].role === "image" && nodes[k].box && !nodes[k].cluster && nodes[k].box[2] >= 24 && nodes[k].box[3] >= 24).map((k: number) => nodes[k].box) } : null)).filter(Boolean) };
  console.log(id, res[id].layout, res[id].territories.map((t: any) => `T${t.i} ${t.lots}l ${t.mix}`).join(" · "));
}
writeFileSync(out, JSON.stringify(res));
