// Photographs the region of each territory to be labelled on the live page. Used only to see the page; no reading is involved.
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, plainJson, outDir, ...ids] = process.argv.slice(2);
const { launchLocalBrowser } = await import(join(root, "src/lib/acquisition/local-browser.ts"));
const { USER_AGENT } = await import(join(root, "src/lib/acquisition/safe-fetch.ts"));
const sets = await import(join(import.meta.dirname, "../read/pages.mts"));
const URLS = new Map<string, string>([...sets.SEALED, ...sets.SEALED2, ...sets.FRESH2]);
const plain = JSON.parse(readFileSync(plainJson, "utf8"));
mkdirSync(outDir, { recursive: true });
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const todo = ids.filter((id) => plain[id] && URLS.has(id));
let next = 0;
async function worker() {
  for (;;) {
    const id = todo[next++];
    if (!id) return;
    const regions = plain[id].territories.filter((t: any) => t.want && t.roots.length).map((t: any) => {
      const x0 = Math.min(...t.roots.map((b: number[]) => b[0])), y0 = Math.min(...t.roots.map((b: number[]) => b[1]));
      const x1 = Math.max(...t.roots.map((b: number[]) => b[0] + b[2])), y1 = Math.max(...t.roots.map((b: number[]) => b[1] + b[3]));
      return { i: t.i, x: Math.max(0, x0), y: Math.max(0, y0), w: Math.min(1440, x1) - Math.max(0, x0), h: Math.min(2200, y1 - y0) };
    }).filter((r: any) => r.w > 20 && r.h > 20 && !existsSync(join(outDir, `${id}-T${r.i}.jpg`)));
    if (!regions.length) continue;
    const browser = await launchLocalBrowser();
    const kill = setTimeout(() => void browser.process()?.kill("SIGKILL"), 80000);
    try {
      const page = await (await browser.createBrowserContext()).newPage();
      await page.setUserAgent(USER_AGENT);
      await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 0.5 });
      page.on("dialog", (d: any) => void d.dismiss().catch(() => undefined));
      await page.goto(URLS.get(id)!, { waitUntil: "domcontentloaded", timeout: 30000 });
      await page.waitForNetworkIdle({ idleTime: 500, timeout: 8000 }).catch(() => undefined);
      const H = (await page.evaluate(`Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)`)) as number;
      for (let k = 1; k <= Math.min(12, Math.ceil(H / 900)); k++) { await page.evaluate(`window.scrollTo(0, ${k * 900})`); await sleep(350); }
      await page.evaluate(`window.scrollTo(0, 0)`); await sleep(500);
      for (const r of regions) await page.screenshot({ path: join(outDir, `${id}-T${r.i}.jpg`), type: "jpeg", quality: 70, clip: { x: r.x, y: r.y, width: r.w, height: r.h }, captureBeyondViewport: true }).catch((e: Error) => console.log(id, r.i, e.message.slice(0, 60)));
      console.log(id, regions.map((r: any) => `T${r.i} ${r.w}x${r.h}@${r.y}`).join(" "));
    } catch (e) { console.log(id, "failed:", (e as Error).message.slice(0, 80)); }
    finally { clearTimeout(kill); const c = browser.close().catch(() => undefined); if ((await Promise.race([c.then(() => 1), sleep(3000).then(() => 0)])) === 0) browser.process()?.kill("SIGKILL"); }
  }
}
await Promise.all([worker(), worker()]);
console.log("done");
