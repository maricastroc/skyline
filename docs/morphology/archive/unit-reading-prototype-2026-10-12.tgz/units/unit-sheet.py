# Evidence sheet: the live territory beside what the capture measured and the unit the new reading selects.
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
shots, plain_json, truth_json, scored_json, out, cols = sys.argv[1:7]; cols = int(cols)
want = [tuple(s.split(":")) for s in sys.argv[7:]]
plain = {(r["page"], r["territory"]): r for r in json.load(open(plain_json))}
T = json.load(open(truth_json)); truth = {(r["page"], r["territory"]): r for r in T["territories"] + T["other_fabrics"]}
S = json.load(open(scored_json)); sc_old = {(r["page"], r["territory"]): r for r in S["old"]}; sc_new = {(r["page"], r["territory"]): r for r in S["new"]}
font = ImageFont.load_default(size=15); small = ImageFont.load_default(size=13)
PW, PH, HEAD, GAP = 430, 400, 84, 8
f = lambda s: "none" if s is None else f"{s['arrangement']} {s['w']}x{s['h']}, {s['per']}/row, {s['units']} units" + (f", {s['kind']}" if s.get("kind") else "")
COL = {"right": (70, 200, 110), "wrong": (240, 90, 80), "missed": (240, 170, 60), "extra": (240, 90, 80)}
tiles = []
for pid, ti in want:
    k = (pid, int(ti)); p = plain[k]; t = truth[k]; o = sc_old[k]; n = sc_new[k]
    tile = Image.new("RGB", (2 * PW + GAP, PH + HEAD), (16, 16, 20)); d = ImageDraw.Draw(tile)
    x0 = max(0, min(b[0] for b in p["roots"])); y0 = max(0, min(b[1] for b in p["roots"]))
    shot = os.path.join(shots, f"{pid}-T{ti}.jpg"); s = 0.3
    if os.path.exists(shot):
        im = Image.open(shot).convert("RGB"); s = min(PW / im.width, PH / im.height, 1.0)
        tile.paste(im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.LANCZOS), (0, HEAD)); s *= 0.5
    ox = PW + GAP
    d.rectangle([ox, HEAD, ox + PW, HEAD + PH], fill=(246, 246, 244))
    def rect(b, **kw):
        xa, ya, xb, yb = ox + (b[0] - x0) * s, HEAD + (b[1] - y0) * s, ox + (b[0] + b[2] - x0) * s, HEAD + (b[1] + b[3] - y0) * s
        if ya > HEAD + PH or xa > ox + PW or yb < HEAD or xb < ox: return
        d.rectangle([max(ox, xa), max(HEAD, ya), min(ox + PW, xb), min(HEAD + PH, yb)], **kw)
    for b in p["images"]: rect(b, fill=(206, 208, 214))
    for b in p["unit"]: rect(b, outline=(20, 150, 80), width=3)
    u = t["unit"]; tu = u if isinstance(u, str) else f"{u['w']}x{u['h']}, {u['per']}/row, {u['kind'] or '?'}"
    d.text((4, 2), f"{pid} T{ti} - {t['lots']} lots, {t['mix']}", fill=(255, 207, 90), font=font)
    d.text((4, 22), f"label: {tu}" + (f"  ({t['note'].strip()})" if t["note"].strip() else ""), fill=(225, 225, 225), font=small)
    d.text((4, 40), f"before: {f(o['series'])}", fill=(200, 200, 200), font=small); d.text((2 * PW - 60, 40), o["verdict"], fill=COL[o["verdict"]], font=small)
    d.text((4, 58), f"new: {f(n['series'])}", fill=(200, 200, 200), font=small); d.text((2 * PW - 60, 58), n["verdict"], fill=COL[n["verdict"]], font=small)
    tiles.append(tile)
rows = [tiles[i:i + cols] for i in range(0, len(tiles), cols)]
W = cols * (2 * PW + GAP) + (cols - 1) * 14; H = len(rows) * (PH + HEAD + 12) + 26
sheet = Image.new("RGB", (W, H), (0, 0, 0)); d = ImageDraw.Draw(sheet)
d.text((4, 4), "left: the live page inside the territory   right: pictures the capture measured (grey) and the unit the new reading selects (green)", fill=(170, 170, 170), font=small)
for r, row in enumerate(rows):
    for c, t in enumerate(row): sheet.paste(t, (c * (2 * PW + GAP + 14), 26 + r * (PH + HEAD + 12)))
sheet.save(out, quality=80); print(out, sheet.size)
