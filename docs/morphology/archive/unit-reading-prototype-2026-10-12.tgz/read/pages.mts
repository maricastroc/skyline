export const KNOWN: Array<[string, string]> = [
  ["hn", "https://news.ycombinator.com/"], ["lobsters", "https://lobste.rs/"], ["pg", "https://www.paulgraham.com/articles.html"],
  ["pydocs", "https://docs.python.org/3/library/itertools.html"], ["mdn", "https://developer.mozilla.org/en-US/docs/Web/HTML"],
  ["wikipedia", "https://en.wikipedia.org/wiki/City"], ["linear", "https://linear.app/"], ["vercel", "https://vercel.com/"],
  ["apple", "https://www.apple.com/"], ["govuk", "https://www.gov.uk/"], ["guardian", "https://www.theguardian.com/international"],
  ["github", "https://github.com/vercel/next.js"], ["craigslist", "https://www.craigslist.org/about/sites"], ["spotify", "https://open.spotify.com/"],
  ["airbnb", "https://www.airbnb.com/"], ["pinterest", "https://www.pinterest.com/"], ["mastodon", "https://mastodon.social/explore"],
  ["rayso", "https://ray.so/"], ["excalidraw", "https://excalidraw.com/"], ["youtube", "https://www.youtube.com/"],
  ["ikea", "https://www.ikea.com/us/en/cat/chairs-fu002/"], ["portfolio", "https://brittanychiang.com/"],
];
export const UNSEEN: Array<[string, string]> = [
  ["itch", "https://itch.io/games"], ["bbc", "https://www.bbc.com/"], ["verge", "https://www.theverge.com/"], ["twitch", "https://www.twitch.tv/"],
  ["photopea", "https://www.photopea.com/"], ["tldraw", "https://www.tldraw.com/"], ["desmos", "https://www.desmos.com/calculator"],
  ["flickr", "https://www.flickr.com/explore"], ["sqlite", "https://www.sqlite.org/about.html"], ["gnu", "https://www.gnu.org/philosophy/free-sw.html"],
  ["lwn", "https://lwn.net/"], ["arxiv", "https://arxiv.org/list/cs.AI/recent"], ["openlibrary", "https://openlibrary.org/"],
  ["toscrape", "https://books.toscrape.com/"], ["gog", "https://www.gog.com/en/games"], ["applemusic", "https://music.apple.com/us/new"],
  ["soundcloud", "https://soundcloud.com/discover"], ["vimeo", "https://vimeo.com/watch"], ["behance", "https://www.behance.net/"],
  ["pexels", "https://www.pexels.com/"], ["commons", "https://commons.wikimedia.org/wiki/Commons:Featured_pictures"], ["ted", "https://www.ted.com/talks"],
  ["npr", "https://www.npr.org/"], ["moma", "https://www.moma.org/collection/"], ["nasa", "https://www.nasa.gov/"],
];
export const FRESH: Array<[string, string]> = [
  ["artic", "https://www.artic.edu/collection"], ["met", "https://www.metmuseum.org/art/collection/search?showOnly=highlights"],
  ["emojipedia", "https://emojipedia.org/people"], ["lucide", "https://lucide.dev/icons/"], ["devto", "https://dev.to/"],
  ["ghtrending", "https://github.com/trending"], ["goodreads", "https://www.goodreads.com/list/show/1.Best_Books_Ever"],
  ["allrecipes", "https://www.allrecipes.com/"], ["jspaint", "https://jspaint.app/"], ["piskel", "https://www.piskelapp.com/p/create/sprite"],
  ["drawio", "https://app.diagrams.net/"], ["squoosh", "https://squoosh.app/"], ["apnews", "https://apnews.com/"],
  ["arstechnica", "https://arstechnica.com/"], ["ebay", "https://www.ebay.com/"], ["coursera", "https://www.coursera.org/"],
  ["lego", "https://www.lego.com/en-us/themes"], ["googlefonts", "https://fonts.google.com/"], ["stackoverflow", "https://stackoverflow.com/questions"],
  ["tubi", "https://tubitv.com/"],
];
export const SEALED: Array<[string, string]> = [
  ["rijks", "https://www.rijksmuseum.nl/en/collection"], ["europeana", "https://www.europeana.eu/en/collections/topic/190-art"],
  ["flaticon", "https://www.flaticon.com/free-icons/city"], ["medium", "https://medium.com/tag/design"], ["indiehackers", "https://www.indiehackers.com/"],
  ["rottentomatoes", "https://www.rottentomatoes.com/"], ["letterboxd", "https://letterboxd.com/films/"], ["geogebra", "https://www.geogebra.org/calculator"],
  ["pixlr", "https://pixlr.com/e/"], ["hoppscotch", "https://hoppscotch.io/"], ["aljazeera", "https://www.aljazeera.com/"], ["wired", "https://www.wired.com/"],
  ["newegg", "https://www.newegg.com/"], ["uniqlo", "https://www.uniqlo.com/us/en/women"], ["khan", "https://www.khanacademy.org/"],
  ["npmjs", "https://www.npmjs.com/search?q=react"], ["crunchyroll", "https://www.crunchyroll.com/"], ["natgeo", "https://www.nationalgeographic.com/"],
  ["unsplasht", "https://unsplash.com/t/architecture"], ["smashing", "https://www.smashingmagazine.com/articles/"],
];
export const FRESH2: Array<[string, string]> = [
  ["tmdb", "https://www.themoviedb.org/movie"], ["lastfm", "https://www.last.fm/music"], ["kickstarter", "https://www.kickstarter.com/discover/advanced?sort=popularity"],
  ["bootstrap", "https://getbootstrap.com/docs/5.3/examples/"], ["heroicons", "https://heroicons.com/"], ["colorhunt", "https://colorhunt.co/"],
  ["wikiart", "https://www.wikiart.org/en/popular-paintings"], ["gutenberg", "https://www.gutenberg.org/"], ["allbirds", "https://www.allbirds.com/collections/mens"],
  ["minipaint", "https://viliusle.github.io/miniPaint/"], ["kleki", "https://kleki.com/"], ["methodac", "https://editor.method.ac/"],
  ["calculator", "https://www.calculator.net/"], ["osm", "https://www.openstreetmap.org/"], ["shadertoy", "https://www.shadertoy.com/browse"],
  ["nytimes", "https://www.nytimes.com/"], ["loc", "https://www.loc.gov/pictures/"], ["printables", "https://www.printables.com/model"],
];
export const SEALED2: Array<[string, string]> = [
  ["discogs", "https://www.discogs.com/"], ["genius", "https://genius.com/"], ["meetup", "https://www.meetup.com/find/"],
  ["awwwards", "https://www.awwwards.com/websites/"], ["fontawesome", "https://fontawesome.com/icons"], ["coolors", "https://coolors.co/palettes/trending"],
  ["bookshop", "https://bookshop.org/"], ["patagonia", "https://www.patagonia.com/shop/mens"], ["muji", "https://www.muji.us/collections/all"],
  ["pixilart", "https://www.pixilart.com/draw"], ["regexr", "https://regexr.com/"], ["tsplay", "https://www.typescriptlang.org/play"],
  ["desmossci", "https://www.desmos.com/scientific"], ["leaflet", "https://leafletjs.com/"], ["sketchfab", "https://sketchfab.com/3d-models/popular"],
  ["economist", "https://www.economist.com/"], ["si", "https://www.si.edu/openaccess"], ["thingiverse", "https://www.thingiverse.com/"],
];
