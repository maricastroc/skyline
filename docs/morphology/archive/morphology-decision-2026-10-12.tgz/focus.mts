// Where to point the close camera: the block centre holding most governed lots of a territory, per arm.
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...specs] = process.argv.slice(2);
const { build } = await import(join(import.meta.dirname, "../eval/arms.mts"));
const { blockCentre } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
for (const spec of specs) {
  const [id, file, exp, ti] = spec.split("|");
  const r = build(JSON.parse(readFileSync(join(root, file), "utf8")), exp);
  const blocks = new Map<string, { lots: number; types: string[] }>();
  for (const pc of r.trace.pieces) {
    if (pc.territory !== Number(ti) || pc.comp !== "media" || pc.piece.interior) continue;
    const k = `${pc.block[0]},${pc.block[1]}`; const b = blocks.get(k) ?? { lots: 0, types: [] };
    b.lots += pc.piece.lots; b.types.push(pc.piece.type); blocks.set(k, b);
  }
  const best = [...blocks].sort((a, b) => b[1].lots - a[1].lots).slice(0, 3);
  console.log(id, `T${ti}`, best.map(([k, b]) => { const [i, j] = k.split(",").map(Number); const c = blockCentre(i, j); return `${c[0].toFixed(1)},${c[1].toFixed(1)} (${b.lots} lots: ${b.types.join("+")})`; }).join(" · "));
}
