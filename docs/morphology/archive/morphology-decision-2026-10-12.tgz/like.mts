import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, file, ti, w] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const p = realPage(JSON.parse(readFileSync(join(root, file), "utf8")), "none", parseExperiments("ensemble"));
const nodes = p.doc.nodes; const t = p.plan.territories[Number(ti)];
for (const i of scopeOf(nodes, t.scope.roots, t.scope.excluded)) { const n = nodes[i]; if (n.role === "image" && n.box && !n.cluster && Math.abs(n.box[2] - Number(w)) <= 0.35 * Number(w)) console.log(JSON.stringify(n.box), n.selector, "under", nodes[n.parent].selector, "<", nodes[nodes[n.parent].parent]?.selector); }
