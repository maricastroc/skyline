// Three arms on the same snapshots: today, ensemble fed by the old reading, ensemble fed by the new reading.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...specs] = process.argv.slice(2);
const { build } = await import(join(import.meta.dirname, "../eval/arms.mts"));
const { ROOM_FOR_SERIES } = await import(join(root, "src/lib/pixelcity/kit/compose.ts"));
const sig = (s: any) => s && ({ arrangement: s.arrangement, kind: s.kind ?? null, units: s.units, w: Math.round(s.width), h: Math.round(s.height), aspect: +(s.height / s.width).toFixed(2), perRow: s.perRow, rows: s.rows, groups: s.groups, head: +s.head.toFixed(2) });
const rows: any[] = [];
for (const spec of specs) {
  const [set, rest] = spec.split(":"); const [id, file] = rest.split("=");
  const snap = JSON.parse(readFileSync(join(root, file), "utf8"));
  const a = build(snap, ""), b = build(snap, "ensemble"), c = build(snap, "ensemble,units");
  const lots = b.trace.alloc!.lots;
  const terr = b.p.plan.territories.map((t: any, ti: number) => {
    const media = t.mix.some((m: any) => m.comp === "media");
    const n = c.p.plan.territories[ti];
    if (!t.series && !n.series) return null;
    return { ti, lots: lots[ti], mix: t.mix.map((m: any) => m.comp).join("+"), label: (t.label ?? t.kind).slice(0, 26), governable: media && lots[ti] >= ROOM_FOR_SERIES, old: sig(t.series), new: sig(n.series) };
  }).filter(Boolean);
  const gov = (r: any) => { let g = 0; const al = r.trace.alloc!; for (const pc of r.trace.pieces) { const t = r.p.plan.territories[pc.territory]; if (t.series && pc.comp === "media" && !pc.piece.interior && al.lots[pc.territory] >= ROOM_FOR_SERIES) g += pc.piece.lots; } return g; };
  const stat = (r: any) => ({ hash: r.hash, buildings: r.buildings, q50: +r.q50.toFixed(1), q90: +r.q90.toFixed(1), max: +r.max.toFixed(1), clashes: r.clashes, fam: r.fam, governed: gov(r) });
  rows.push({ set, id, base: stat(a), old: stat(b), new: stat(c), territories: terr });
  console.log(`${set}:${id} governed old ${rows.at(-1).old.governed} new ${rows.at(-1).new.governed} · old=base ${a.hash === b.hash} · new=old ${b.hash === c.hash} · new=base ${a.hash === c.hash}`);
}
writeFileSync(out, JSON.stringify(rows));
