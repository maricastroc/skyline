# Decision sheets: one row per site, three columns (today | ensemble with the old reading | ensemble with the new reading).
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
arms_json, shots, out, view = sys.argv[1:5]
rows = [a.split(":") for a in sys.argv[5:]]   # prefix:id[:Title]
A = {r["id"]: r for r in json.load(open(arms_json))}
font = ImageFont.load_default(size=17); small = ImageFont.load_default(size=13)
CW, CH, HEAD, GAP = 600, 375, 44, 6
DIRS = {"base": "itm-base", "old": "itm-ensemble", "new": "itm-units"}
def shot(prefix, pid, arm):
    f = os.path.join(shots, DIRS[arm], f"{prefix}-{pid}-{view}.jpg")
    return f if os.path.exists(f) else None
def series(s):
    return "none" if not s else f"{s['arrangement']} {s['w']}x{s['h']} {s['perRow']}/row g{s['groups']}" + (f" {s['kind']}" if s.get("kind") else "")
sheet = Image.new("RGB", (3 * CW + 2 * GAP, 26 + len(rows) * (CH + HEAD + GAP)), (0, 0, 0)); d = ImageDraw.Draw(sheet)
for c, name in enumerate(["TODAY (baseline)", "ENSEMBLE + old reading (seriesOf)", "ENSEMBLE + new reading (unitsOf)"]): d.text((c * (CW + GAP) + 4, 4), name, fill=(255, 207, 90), font=font)
for k, row in enumerate(rows):
    prefix, pid = row[0], row[1]; title = row[2] if len(row) > 2 else pid
    r = A[pid]; y = 26 + k * (CH + HEAD + GAP)
    same_ob = r["old"]["hash"] == r["base"]["hash"]; same_no = r["new"]["hash"] == r["old"]["hash"]; same_nb = r["new"]["hash"] == r["base"]["hash"]
    src = {"base": "base", "old": "base" if same_ob else "old", "new": "base" if same_nb else "old" if same_no else "new"}
    note = {"base": "", "old": "identical to baseline" if same_ob else "", "new": "identical to baseline" if same_nb else "identical to the old reading" if same_no else ""}
    gov = [t for t in r["territories"] if t["governable"]]
    d.text((4, y + 2), f"{title}", fill=(255, 255, 255), font=font)
    d.text((4 + 190, y + 5), f"buildings {r['base']['buildings']} · tallest {r['base']['max']}", fill=(170, 170, 170), font=small)
    for c, arm in enumerate(["old", "new"]):
        x = (c + 1) * (CW + GAP)
        d.text((x + 4, y + 2), f"governed {r[arm]['governed']}/256 lots · buildings {r[arm]['buildings']}" + (f" · {note[arm]}" if note[arm] else ""), fill=(120, 200, 255) if note[arm] else (220, 220, 220), font=small)
        txt = " | ".join(f"T{t['ti']}({t['lots']}): {series(t.get(arm))}" for t in sorted(gov, key=lambda t: -t["lots"])[:3])
        d.text((x + 4, y + 20), txt[:98], fill=(170, 170, 170), font=small)
    for c, arm in enumerate(["base", "old", "new"]):
        f = shot(prefix, pid, src[arm])
        x = c * (CW + GAP)
        if f: sheet.paste(Image.open(f).convert("RGB").resize((CW, CH), Image.LANCZOS), (x, y + HEAD))
        else: d.rectangle([x, y + HEAD, x + CW, y + HEAD + CH], fill=(40, 20, 20)); d.text((x + 10, y + HEAD + 10), f"missing {DIRS[src[arm]]}/{prefix}-{pid}-{view}", fill=(255, 120, 120), font=small)
sheet.save(out, quality=84); print(out, sheet.size)
