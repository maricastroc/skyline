#!/bin/zsh
# usage: shoot.sh <arm-dir> <exp> <far ids…> [-- <flat ids…>] [-- <id:focusx,focusz …> for close]
cd "/Users/marianacastro/Desktop/@dev/skyline"
export BASE=http://localhost:${PORT:-3100} FORCE=${FORCE:-}
ARM=$1; EXP=$2; shift 2
FAR=(); FLAT=(); CLOSE=(); mode=far
for a in "$@"; do if [[ $a == "--" ]]; then [[ $mode == far ]] && mode=flat || mode=close; continue; fi; case $mode in far) FAR+=($a);; flat) FLAT+=($a);; close) CLOSE+=($a);; esac; done
ALL=($FAR $FLAT); for c in $CLOSE; do ALL+=(${c%%:*}); done
export ALSO="${(j:,:)ALL}"
if (( ${#FAR} )); then export VIEW_QUERY="time=day&view=street&focus=0,0&zoom=0.5"; node scripts/morphology/shoot.mjs $ARM $EXP far $FAR 2>&1 | grep -E "^shot|pageerror|Error"; fi
if (( ${#FLAT} )); then export VIEW_QUERY="time=day&flat=1&view=street&focus=0,0&zoom=0.5"; node scripts/morphology/shoot.mjs $ARM $EXP flat $FLAT 2>&1 | grep -E "^shot|pageerror|Error"; fi
for c in $CLOSE; do export VIEW_QUERY="time=day&view=street&focus=${c#*:}&zoom=1.25"; node scripts/morphology/shoot.mjs $ARM $EXP close ${c%%:*} 2>&1 | grep -E "^shot|pageerror|Error"; done
echo "done $ARM"
