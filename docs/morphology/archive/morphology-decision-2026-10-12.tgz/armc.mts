// Preview of the conservative subset (temporary patch): hashes and heights against the three photographed arms.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, arms, out, ...specs] = process.argv.slice(2);
const { build } = await import(join(import.meta.dirname, "../eval/arms.mts"));
const A = Object.fromEntries(JSON.parse(readFileSync(arms, "utf8")).map((r: any) => [r.id, r]));
const rows: any[] = [];
for (const spec of specs) {
  const [set, rest] = spec.split(":"); const [id, file] = rest.split("=");
  const c = build(JSON.parse(readFileSync(join(root, file), "utf8")), "ensemble,units");
  rows.push({ set, id, hash: c.hash, buildings: c.buildings, q50: +c.q50.toFixed(1), q90: +c.q90.toFixed(1), max: +c.max.toFixed(1), clashes: c.clashes, fam: c.fam, sameAsBase: c.hash === A[id].base.hash, sameAsNew: c.hash === A[id].new.hash });
}
writeFileSync(out, JSON.stringify(rows));
const gov = rows.filter((r) => A[r.id].new.governed > 0 || A[r.id].old.governed > 0);
console.log(`pages ${rows.length} · same as baseline ${rows.filter((r) => r.sameAsBase).length} · same as ensemble+new ${rows.filter((r) => r.sameAsNew && !r.sameAsBase).length} · own result ${rows.filter((r) => !r.sameAsBase && !r.sameAsNew).length}`);
for (const r of rows) if (!r.sameAsBase || !A[r.id].new.hash || A[r.id].new.hash !== A[r.id].base.hash) if (A[r.id].new.hash !== A[r.id].base.hash || !r.sameAsBase) console.log(`  ${r.set}:${r.id.padEnd(12)} ${r.sameAsBase ? "= baseline" : r.sameAsNew ? "= ensemble+new" : "own       "} · buildings ${A[r.id].base.buildings}/${A[r.id].new.buildings}/${r.buildings} · q90 ${A[r.id].base.q90}/${A[r.id].new.q90}/${r.q90} · clashes ${A[r.id].base.clashes}/${A[r.id].new.clashes}/${r.clashes}`);
