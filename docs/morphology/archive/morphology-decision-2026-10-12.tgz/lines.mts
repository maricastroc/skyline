// Count check: the rows of the selected unit and the headings between them, as the capture measured them.
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, ...specs] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { unitGroups, unitsOf, seriesOf } = await import(join(root, "src/lib/pixelcity/kit/series.ts"));
for (const spec of specs) {
  const [file, ti] = spec.split("|");
  const p = realPage(JSON.parse(readFileSync(join(root, file), "utf8")), "none", parseExperiments("ensemble"));
  const nodes = p.doc.nodes; const t = p.plan.territories[Number(ti)];
  const o = seriesOf(p.doc, t.scope), n = unitsOf(p.doc, t.scope);
  const g = unitGroups(p.doc, t.scope).filter((x: any) => x.role === "unit").sort((a: any, b: any) => b.covered - a.covered)[0];
  const f = (s: any) => s ? `${s.arrangement} ${Math.round(s.width)}x${Math.round(s.height)} ${s.perRow}/row rows ${s.rows} groups ${s.groups} units ${s.units}` : "none";
  console.log(`\n## ${file.split("/").pop()} T${ti} “${(t.label ?? "").slice(0, 30)}”\n   old: ${f(o)}\n   new: ${f(n)}${g ? ` (visible ${g.members.length}, merged by the normaliser ${g.hidden})` : ""}`);
  if (!g) continue;
  const ids = scopeOf(nodes, t.scope.roots, t.scope.excluded);
  const heads = ids.filter((i: number) => nodes[i].heading && nodes[i].box && !nodes[i].cluster).map((i: number) => ({ y: nodes[i].box[1], text: `h ${nodes[i].fontSize ?? "?"}px “${(nodes[i].label ?? nodes[i].text ?? "").slice(0, 34)}”` }));
  const rows = g.lines.map((l: number[]) => ({ y: nodes[l[0]].box[1], text: `row of ${l.length} (x ${l.map((i) => nodes[i].box[0]).join(",")})` }));
  const top = rows[0].y - 2 * g.height, bottom = rows.at(-1).y + g.height;
  for (const e of [...heads.filter((h: any) => h.y >= top && h.y <= bottom), ...rows].sort((a, b) => a.y - b.y).slice(0, 40)) console.log(`   y ${String(e.y).padStart(5)}  ${e.text}`);
}
