# Preview sheet of the conservative subset: today | full ensemble with the new reading | conservative subset.
import json, os, sys
from PIL import Image, ImageDraw, ImageFont
arms_json, armc_json, shots, out, view = sys.argv[1:6]
rows = [a.split(":") for a in sys.argv[6:]]
A = {r["id"]: r for r in json.load(open(arms_json))}; C = {r["id"]: r for r in json.load(open(armc_json))}
font = ImageFont.load_default(size=17); small = ImageFont.load_default(size=13)
CW, CH, HEAD, GAP = 600, 375, 44, 6
DIRS = {"base": "itm-base", "old": "itm-ensemble", "new": "itm-units", "keep": "itm-keep"}
def shot(prefix, pid, arm):
    f = os.path.join(shots, DIRS[arm], f"{prefix}-{pid}-{view}.jpg")
    return f if os.path.exists(f) else None
fam = lambda d: ", ".join(f"{k} {v}" for k, v in sorted(d.items(), key=lambda x: -x[1])[:4])
sheet = Image.new("RGB", (3 * CW + 2 * GAP, 26 + len(rows) * (CH + HEAD + GAP)), (0, 0, 0)); d = ImageDraw.Draw(sheet)
for c, name in enumerate(["TODAY (baseline)", "A: full ensemble + new reading", "C: conservative subset (preview)"]): d.text((c * (CW + GAP) + 4, 4), name, fill=(255, 207, 90), font=font)
for k, row in enumerate(rows):
    prefix, pid = row[0], row[1]; title = row[2] if len(row) > 2 else pid
    r = A[pid]; c = C[pid]; y = 26 + k * (CH + HEAD + GAP)
    nb = r["new"]["hash"] == r["base"]["hash"]; no = r["new"]["hash"] == r["old"]["hash"]
    src = {"base": "base", "new": "base" if nb else "old" if no and not shot(prefix, pid, "new") else "new", "keep": "base" if c["sameAsBase"] else "new" if c["sameAsNew"] and not shot(prefix, pid, "keep") else "keep"}
    note = {"base": "", "new": "identical to baseline" if nb else "", "keep": "identical to baseline" if c["sameAsBase"] else "identical to A" if c["sameAsNew"] else ""}
    stats = {"base": r["base"], "new": r["new"], "keep": c}
    d.text((4, y + 2), title, fill=(255, 255, 255), font=font)
    for i, arm in enumerate(["base", "new", "keep"]):
        x = i * (CW + GAP); s = stats[arm]
        d.text((x + (200 if i == 0 else 4), y + 4 if i == 0 else y + 2), f"buildings {s['buildings']} · 9th decile of tops {s['q90']} · tallest {s['max']}" + (f" · {note[arm]}" if note[arm] else ""), fill=(120, 200, 255) if note[arm] else (220, 220, 220), font=small)
        d.text((x + 4, y + 22), fam(s["fam"]), fill=(170, 170, 170), font=small)
        f = shot(prefix, pid, src[arm])
        if f: sheet.paste(Image.open(f).convert("RGB").resize((CW, CH), Image.LANCZOS), (x, y + HEAD))
        else: d.rectangle([x, y + HEAD, x + CW, y + HEAD + CH], fill=(40, 20, 20)); d.text((x + 10, y + HEAD + 10), f"missing {DIRS[src[arm]]}/{prefix}-{pid}-{view}", fill=(255, 120, 120), font=small)
sheet.save(out, quality=84); print(out, sheet.size)
