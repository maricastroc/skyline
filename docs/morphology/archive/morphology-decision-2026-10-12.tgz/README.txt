Morphology decision round, 2026-10-12 (branch morphology/consolidation, HEAD 7b624b2, nothing committed).

working-tree.patch      git diff of the tracked files at the end of the round: the three arms
                        (no flag = today, exp=ensemble = old reading, exp=ensemble,units = new reading),
                        the six rules of composeEnsemble, the measuring pass of the capture.
untracked-sources/      the three source files the patch needs and git does not track yet:
                        src/lib/pixelcity/kit/series.ts (both readings), src/lib/snapshot/layout.ts,
                        scripts/morphology/layout-capture.ts.
conservative-preview.patch
                        the temporary, removal-only change used to preview alternative C
                        (no family swap by proportion, no heading rule, key territories not governed).
                        Applied on top of working-tree.patch; it was reverted after the shots.
arms3.mts, armc.mts, stability.mts, lines.mts, focus.mts, like.mts, triptych.py, preview.py, shoot.sh
                        instruments of the comparison. arms.mts, hash-all.mts, watchdog.sh come from the earlier round.
arms3.json, arms3-classified.json, armc.json, armc-headed.json, stability.json, hash-*.json
                        outputs: per page and per territory, what each arm receives and produces.

To recover the full state on HEAD 7b624b2: git apply working-tree.patch, then copy untracked-sources/ into place.
