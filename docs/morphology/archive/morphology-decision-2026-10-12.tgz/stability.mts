// Stability of what the composition receives when the page loses one item of its main list, for both readings.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, ...specs] = process.argv.slice(2);
process.chdir(root);
const { realPage, PERTURBATIONS } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { dropItems } = await import(join(root, "scripts/morphology/perturb.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const cls = (s: any) => (s.arrangement === "tiles" ? "keys" : s.height / s.width >= 1.5 ? "portrait" : s.height / s.width < 0.75 ? "landscape" : "regular");
const sig = (p: any) => { const a = allocate(p.plan); return p.plan.territories.map((t: any, i: number) => ({ t, lots: a.lots[i] })).filter((x: any) => x.t.series && x.lots >= 8 && x.t.mix.some((m: any) => m.comp === "media")).map((x: any) => `${x.t.series.arrangement}/${Math.min(Math.max(x.t.series.perRow, 2), 8)}/${cls(x.t.series)}`).sort().join(" "); };
const res: any[] = [];
for (const spec of specs) {
  const [set, rest] = spec.split(":"); const [id, file] = rest.split("=");
  const snap = JSON.parse(readFileSync(join(root, file), "utf8"));
  const row: any = { set, id };
  for (const [arm, exp] of [["old", "ensemble"], ["new", "ensemble,units"]] as const) {
    const e = parseExperiments(exp);
    const s0 = sig(realPage(snap, "none", e));
    const less = dropItems(snap, 1);
    row[arm] = { governed: !!s0, drop: !s0 ? null : !less ? "no list" : sig(realPage(less, "none", e)) === s0 ? "same" : `${s0} → ${sig(realPage(less, "none", e))}`, perturb: !s0 ? null : PERTURBATIONS.filter((pt: string) => sig(realPage(snap, pt, e)) !== s0) };
  }
  res.push(row);
}
writeFileSync(out, JSON.stringify(res));
for (const arm of ["old", "new"]) {
  const g = res.filter((r) => r[arm].governed);
  console.log(`${arm}: governed pages ${g.length} · one item fewer: same ${g.filter((r) => r[arm].drop === "same").length}, no list to edit ${g.filter((r) => r[arm].drop === "no list").length}, changed ${g.filter((r) => r[arm].drop !== "same" && r[arm].drop !== "no list").length} · text/link perturbations that change it: ${g.filter((r) => r[arm].perturb.length).length} pages`);
  for (const r of g) if ((r[arm].drop !== "same" && r[arm].drop !== "no list") || r[arm].perturb.length) console.log(`   ${r.set}:${r.id} drop: ${r[arm].drop} · perturb: ${r[arm].perturb.join(",") || "-"}`);
}
