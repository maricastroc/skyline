import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { pruneUnseen } = await import(join(root, "src/lib/snapshot/layout.ts"));
const w = (n: any): number => 1 + n.text / 180 + n.children.reduce((s: number, c: any) => s + w(c), 0);
const out: string[] = [];
for (const id of ids) {
  const snap = JSON.parse(readFileSync(join(dir, `${id}.js.json`), "utf8"));
  const a = w(snap.root), b = w(pruneUnseen(snap).root);
  out.push(`${id} ${Math.round((1 - b / a) * 100)}%`);
}
console.log(out.join(" · "));
