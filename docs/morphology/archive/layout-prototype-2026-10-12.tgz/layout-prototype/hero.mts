import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
for (const id of ids) {
  const snap = JSON.parse(readFileSync(join(dir, `${id}.js.json`), "utf8"));
  for (const exp of ["", "layout"]) {
    const p = realPage(snap, "none", parseExperiments(exp));
    const h = p.sem.hero >= 0 ? p.sem.regions[p.sem.hero] : null;
    const n = h ? p.doc.nodes[h.node] : null;
    const h1 = p.doc.nodes.filter((x: any) => x.heading === 1);
    console.log(id.padEnd(10), (exp || "base").padEnd(7), "hero:", h ? `${h.kind} “${(h.title ?? "").slice(0, 24)}” ${n.selector} share ${(n.weight / p.doc.nodes[0].weight * 100).toFixed(1)}%` : "none", "| plan.hero", p.plan.hero, "| h1 nodes:", h1.length, h1.map((x: any) => `${x.selector}${x.box ? "" : " (no box)"}`).slice(0, 3).join(", "), "| evidence:", h ? h.evidence.slice(0, 2).join("; ").slice(0, 110) : "");
  }
}
