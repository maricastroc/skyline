import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { pruneUnseen } = await import(join(root, "src/lib/snapshot/layout.ts"));
const { allocateSpatial, columnsOf } = await import(join(root, "src/lib/pixelcity/kit/spatial.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const { dropItems } = await import(join(root, "scripts/morphology/perturb.ts"));
const plan = (snap: any, exp: string) => {
  const p = realPage(snap, "none", parseExperiments(exp));
  const a = exp ? allocateSpatial(p.plan) : allocate(p.plan);
  return { comp: Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : a.open?.has(a.segments[s].territory) ? "open" : a.segments[s].comp)), cols: exp ? (columnsOf(p.plan, a.lots)?.length ?? 0) : 0, n: p.plan.territories.length };
};
const diff = (x: string[], y: string[]) => Math.round((x.filter((v, k) => v !== y[k]).length / 256) * 100);
const strip = (snap: any) => { const p = { ...pruneUnseen(snap) }; delete p.layout; return p; };
console.log("one item fewer: lots that change fabric".padEnd(42), "base", "prune", "full", " territories base/prune");
for (const id of ids) {
  const f = join(dir, `${id}.js.json`);
  if (!existsSync(f)) continue;
  const snap = JSON.parse(readFileSync(f, "utf8"));
  const less = dropItems(snap, 1);
  if (!less) { console.log(id.padEnd(42), "no main list"); continue; }
  const b = diff(plan(snap, "").comp, plan(less, "").comp);
  const p = diff(plan(strip(snap), "").comp, plan(strip(less), "").comp);
  const fl = diff(plan(snap, "layout").comp, plan(less, "layout").comp);
  console.log(id.padEnd(42), `${b}%`.padStart(4), `${p}%`.padStart(5), `${fl}%`.padStart(4), ` ${plan(snap, "").n}/${plan(strip(snap), "").n}`);
}
