import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
process.chdir(root);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict, newTrace } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { pruneUnseen } = await import(join(root, "src/lib/snapshot/layout.ts"));
const { columnsOf } = await import(join(root, "src/lib/pixelcity/kit/spatial.ts"));
const { measureSnapshot, apart } = await import(join(root, "scripts/morphology/measure.ts"));
const { dropItems } = await import(join(root, "scripts/morphology/perturb.ts"));
const { scopeOf } = await import(join(root, "src/lib/pixelcity/kit/structure.ts"));
const { createHash } = await import("node:crypto");

const load = (id: string, mode = "js") => {
  const f = join(dir, `${id}.${mode}.json`);
  return existsSync(f) ? JSON.parse(readFileSync(f, "utf8")) : null;
};
const stripped = (snap: any) => {
  const p = { ...pruneUnseen(snap) };
  delete p.layout;
  return p;
};
const city = (snap: any, exp: string) => {
  const p = realPage(snap, "none", parseExperiments(exp));
  const trace = newTrace();
  const c = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
  const h = createHash("sha1");
  for (const q of c.parts) h.update(JSON.stringify([q.mesh, q.x, q.y, q.z, q.w, q.h, q.d, q.color, q.surf]));
  const a = trace.alloc!;
  const comp = Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : a.open?.has(a.segments[s].territory) ? "open" : a.segments[s].comp));
  const key = Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : p.plan.territories[a.segments[s].territory].key));
  const cols = exp ? columnsOf(p.plan, a.lots) : null;
  return { p, trace, a, hash: h.digest("hex"), comp, key, columns: cols ? cols.length : 0, open: comp.filter((x: string) => x === "open").length };
};
const diff = (x: string[], y: string[]) => x.filter((v, k) => v !== y[k]).length / 256;
const pct = (v: number) => `${Math.round(v * 100)}%`;
const shares = (comp: string[]) => {
  const d: Record<string, number> = {};
  for (const c of comp) d[c] = (d[c] ?? 0) + 1 / 256;
  return Object.entries(d).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, v]) => `${k.slice(0, 6)} ${Math.round(v * 100)}`).join(", ");
};

const rows: any[] = [];
for (const id of ids) {
  const snap = load(id);
  if (!snap) continue;
  const pr = stripped(snap);
  const base = city(snap, "");
  const prune = city(pr, "");
  const full = city(snap, "layout");
  const meta = { id, family: "feed" as const, what: id };
  rows.push({ id, snap, pr, base, prune, full, m: { base: measureSnapshot(snap, meta, parseExperiments("")), prune: measureSnapshot(pr, meta, parseExperiments("")), full: measureSnapshot(snap, meta, parseExperiments("layout")) } });
}

console.log("\n# A. Three arms, lot by lot");
console.log("page".padEnd(11), "base=prune", "prune=full", "fabric base→prune", "fabric prune→full", "place prune→full", "cols", "open", " fabrics: base | prune | full");
for (const r of rows)
  console.log(r.id.padEnd(11), String(r.base.hash === r.prune.hash).padStart(10), String(r.prune.hash === r.full.hash).padStart(10), pct(diff(r.base.comp, r.prune.comp)).padStart(17), pct(diff(r.prune.comp, r.full.comp)).padStart(17), pct(diff(r.prune.key, r.full.key)).padStart(16), String(r.full.columns).padStart(4), String(r.full.open).padStart(4), ` ${shares(r.base.comp)} | ${shares(r.prune.comp)} | ${shares(r.full.comp)}`);

console.log("\n# B. Distance between cities (0 = same land use, buildings, heights and open land)");
for (const arm of ["base", "prune", "full"] as const) {
  const ms = rows.map((r) => r.m[arm]);
  const all = ms.flatMap((x: any, i: number) => ms.slice(i + 1).map((y: any) => apart(x, y)));
  const nn = ms.map((x: any) => ms.filter((y: any) => y !== x).map((y: any) => ({ id: y.id, d: apart(x, y) })).sort((a: any, b: any) => a.d - b.d)[0]);
  const twins = nn.map((n: any, k: number) => ({ a: ms[k].id, ...n })).filter((n: any) => n.d < 0.08);
  console.log(`${arm.padEnd(6)} mean ${(all.reduce((s: number, v: number) => s + v, 0) / all.length).toFixed(3)} · cities with a near twin (<0.08): ${twins.length} · ${twins.map((t: any) => `${t.a}~${t.id} ${t.d.toFixed(2)}`).join(", ")}`);
  const mdn = ms.findIndex((x: any) => x.id === "mdn");
  if (mdn >= 0) console.log(`       nearest to mdn: ${nn[mdn].id} ${nn[mdn].d.toFixed(2)} · mdn↔hn ${apart(ms[mdn], ms.find((x: any) => x.id === "hn")).toFixed(2)}`);
}
console.log("how far each city moves between arms:");
console.log(rows.map((r) => `${r.id} ${apart(r.m.base, r.m.prune).toFixed(2)}/${apart(r.m.prune, r.m.full).toFixed(2)}`).join(" · "));
console.log("open land (lots without a building): base → prune → full");
console.log(rows.map((r) => `${r.id} ${pct(r.m.base.open)}→${pct(r.m.prune.open)}→${pct(r.m.full.open)}`).join(" · "));
console.log("90th percentile of building tops: base → prune → full");
console.log(rows.map((r) => `${r.id} ${r.m.base.q90.toFixed(1)}→${r.m.prune.q90.toFixed(1)}→${r.m.full.q90.toFixed(1)}`).join(" · "));

console.log("\n# C. Stability of the full arm");
for (const r of rows) {
  const less = dropItems(r.snap, 1);
  const notes: string[] = [];
  if (less) {
    const c = city(less, "layout");
    notes.push(`one item fewer: fabric ${pct(diff(r.full.comp, c.comp))}, columns ${r.full.columns}→${c.columns}`);
  }
  const a = load(r.id, "nojs");
  const b = load(r.id, "nojs2");
  if (a && b) {
    const ca = city(a, "layout");
    const cb = city(b, "layout");
    notes.push(`two no-JS captures: fabric ${pct(diff(ca.comp, cb.comp))}, place ${pct(diff(ca.key, cb.key))}`);
    notes.push(`JS vs no-JS: fabric ${pct(diff(r.full.comp, ca.comp))}, columns ${r.full.columns}/${ca.columns}`);
  }
  const n = load(r.id, "narrow");
  if (n) {
    const cn = city(n, "layout");
    notes.push(`1100 px: fabric ${pct(diff(r.full.comp, cn.comp))}, columns ${r.full.columns}→${cn.columns}`);
  }
  if (notes.length) console.log(r.id.padEnd(11), notes.join(" · "));
}

console.log("\n# D. What stays inside territories (full arm)");
console.log("page".padEnd(11), "largest territory", "its fabric", "buildings there (families)", "measured items: count, per row, w×h px", "largest heading");
const inner: any[] = [];
for (const r of rows) {
  const p = r.full.p;
  const nodes = p.doc.nodes;
  const lots = r.full.a.lots as number[];
  const ti = lots.indexOf(Math.max(...lots));
  const t = p.plan.territories[ti];
  const fam: Record<string, number> = {};
  for (const b of r.full.trace.buildings) if (b.territory === ti) fam[b.P.family] = (fam[b.P.family] ?? 0) + 1;
  const region = t.region >= 0 ? p.sem.regions[t.region] : null;
  let items = (region?.items ?? []).map((k: number) => nodes[k].box).filter(Boolean) as number[][];
  if (items.length < 4 && t.scope) {
    const scope = scopeOf(nodes, t.scope.roots, t.scope.excluded);
    const groups = new Map<string, number[][]>();
    for (const k of scope) {
      const n = nodes[k];
      if (!n.box || n.parent < 0) continue;
      const g = `${n.parent}|${n.tag}`;
      groups.set(g, [...(groups.get(g) ?? []), n.box]);
    }
    items = [...groups.values()].sort((a, b) => b.length - a.length)[0] ?? [];
  }
  const med = (v: number[]) => [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)] ?? 0;
  const perRow = items.length >= 4 ? Math.round(items.length / new Set(items.map((b) => Math.round(b[1] / 12))).size) : 0;
  const head = Math.max(0, ...nodes.filter((n: any) => n.heading && n.fontSize && n.box).map((n: any) => n.fontSize));
  const top = [...t.mix].sort((x: any, y: any) => y.share - x.share)[0].comp;
  const itemW = med(items.map((b) => b[2]));
  const itemH = med(items.map((b) => b[3]));
  inner.push({ id: r.id, share: lots[ti] / 256, comp: top, items: items.length, perRow, itemW, itemH, head, columns: r.full.columns, open: r.full.open / 256 });
  console.log(r.id.padEnd(11), pct(lots[ti] / 256).padStart(17), top.padEnd(11), Object.entries(fam).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, v]) => `${k} ${v}`).join(", ").padEnd(34), items.length >= 4 ? `${items.length}, ${perRow}/row, ${itemW}×${itemH}`.padEnd(30) : "-".padEnd(30), `${head} px`);
}

const rank = (v: number[]) => {
  const s = v.map((x, i) => [x, i] as const).sort((a, b) => a[0] - b[0]);
  const r = new Array(v.length).fill(0);
  for (let i = 0; i < s.length; ) {
    let j = i;
    while (j < s.length && s[j][0] === s[i][0]) j++;
    for (let k = i; k < j; k++) r[s[k][1]] = (i + j - 1) / 2;
    i = j;
  }
  return r;
};
const spearman = (x: number[], y: number[]) => {
  const a = rank(x), b = rank(y);
  const ma = a.reduce((s, v) => s + v, 0) / a.length, mb = b.reduce((s, v) => s + v, 0) / b.length;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < a.length; i++) { num += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; }
  return da && db ? num / Math.sqrt(da * db) : 0;
};
const feats: Record<string, (r: any) => number> = {
  "item shape (log of width/height)": (r) => (r.items >= 4 && r.itemH > 0 ? Math.log2(Math.max(r.itemW, 1) / r.itemH) : 0),
  "items per row": (r) => Math.min(r.perRow, 10),
  "largest heading": (r) => r.head,
  "columns between territories": (r) => r.columns,
  "measured empty land": (r) => r.open,
  "share of the largest territory": (r) => r.share,
};
console.log("\n# E. Does the distance between two cities follow the difference between their pages? (Spearman over all pairs)");
console.log("page property".padEnd(36), "base".padStart(6), "prune".padStart(6), "full".padStart(6));
for (const [name, f] of Object.entries(feats)) {
  const line: string[] = [];
  for (const arm of ["base", "prune", "full"] as const) {
    const px: number[] = [], cy: number[] = [];
    for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
      px.push(Math.abs(f(inner[i]) - f(inner[j])));
      cy.push(apart(rows[i].m[arm], rows[j].m[arm]));
    }
    line.push(spearman(px, cy).toFixed(2).padStart(6));
  }
  console.log(name.padEnd(36), line.join(" "));
}
writeFileSync(join(dir, "evaluation.json"), JSON.stringify({ inner, rows: rows.map((r) => ({ id: r.id, base: r.base.comp, prune: r.prune.comp, full: r.full.comp, baseKey: r.base.key, pruneKey: r.prune.key, fullKey: r.full.key, columns: r.full.columns, open: r.full.open })) }));
