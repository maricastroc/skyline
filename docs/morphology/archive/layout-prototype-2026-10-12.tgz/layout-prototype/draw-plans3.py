import json, sys
from PIL import Image, ImageDraw, ImageFont
src, out, cols = sys.argv[1], sys.argv[2], int(sys.argv[3])
names = dict(a.split("=", 1) for a in sys.argv[4].split(","))
data = {r["id"]: r for r in json.load(open(src))}
COL = {"parcelled": (224, 142, 69), "continuous": (86, 132, 201), "media": (150, 104, 196), "archive": (150, 110, 78), "grid": (64, 168, 160), "navigation": (222, 196, 84), "support": (140, 146, 156), "interactive": (104, 178, 104), "structured": (214, 120, 160), "landmark": (214, 72, 72), "marker": (90, 90, 100), "-": (40, 40, 46), "open": (196, 214, 170)}
BG, FG, MUTED = (18, 18, 22), (240, 240, 240), (150, 150, 160)
f = ImageFont.load_default(size=14)
fb = ImageFont.load_default(size=19)
PW, PH, LOT = 150, 224, 9
GRID = 16 * LOT
LABELS = ["hoje", "so poda", "poda + planta", "area por superficie"]
CW, CH = PW + 4 * (GRID + 16) + 30, PH + 78

def page_panel(d, r, x, y):
    d.rectangle([x, y, x + PW, y + PH], fill=(34, 34, 40))
    sx = PW / r["W"]; sy = min(sx, PH / r["H"])
    d.rectangle([x, y, x + PW, y + r["H"] * sy], fill=(246, 246, 242))
    ts = [t for t in r["rects"] if t["lots"] > 0 and t["rect"]]
    for t in sorted(ts, key=lambda t: -((t["rect"][2] - t["rect"][0]) * (t["rect"][3] - t["rect"][1]))):
        a = t["rect"]
        d.rectangle([x + a[0] * sx, y + a[1] * sy, x + a[2] * sx, y + max(a[3] * sy, a[1] * sy + 2)], fill=COL["open"] if t["open"] else COL.get(t["comp"], COL["-"]), outline=(20, 20, 24))

def lot_panel(d, arm, x, y):
    comp, own = arm["comp"], arm["own"]
    for X in range(16):
        for Z in range(16):
            d.rectangle([x + X * LOT, y + Z * LOT, x + X * LOT + LOT - 1, y + Z * LOT + LOT - 1], fill=COL.get(comp[X * 16 + Z], COL["-"]))
    for X in range(16):
        for Z in range(16):
            o = own[X * 16 + Z]
            if X < 15 and own[(X + 1) * 16 + Z] != o: d.line([x + (X + 1) * LOT - 1, y + Z * LOT, x + (X + 1) * LOT - 1, y + (Z + 1) * LOT - 1], fill=(14, 14, 18), width=2)
            if Z < 15 and own[X * 16 + Z + 1] != o: d.line([x + X * LOT, y + (Z + 1) * LOT - 1, x + (X + 1) * LOT - 1, y + (Z + 1) * LOT - 1], fill=(14, 14, 18), width=2)
    for k in range(1, 4):
        d.line([x + k * 4 * LOT - 1, y, x + k * 4 * LOT - 1, y + GRID], fill=(250, 250, 250), width=1)
        d.line([x, y + k * 4 * LOT - 1, x + GRID, y + k * 4 * LOT - 1], fill=(250, 250, 250), width=1)

ids = [i for i in names if i in data]
rows = (len(ids) + cols - 1) // cols
img = Image.new("RGB", (cols * CW + 20, rows * CH + 64), BG)
d = ImageDraw.Draw(img)
lx = 14
for k, v in [("parcelled", "sobrados"), ("continuous", "quadras"), ("media", "midia"), ("archive", "indice"), ("navigation", "navegacao"), ("support", "rodape"), ("interactive", "praca"), ("landmark", "marco"), ("open", "vazio medido")]:
    d.rectangle([lx, 14, lx + 16, 30], fill=COL[k]); d.text((lx + 22, 13), v, fill=MUTED, font=f); lx += 30 + int(d.textlength(v, font=f)) + 16
for n, i in enumerate(ids):
    r = data[i]; x = 14 + (n % cols) * CW; y = 56 + (n // cols) * CH
    d.text((x, y), names[i], fill=FG, font=fb)
    d.text((x, y + 27), "a pagina", fill=MUTED, font=f)
    page_panel(d, r, x, y + 48)
    for k in range(4):
        px = x + PW + 16 + k * (GRID + 16)
        d.text((px, y + 27), LABELS[k], fill=MUTED, font=f)
        lot_panel(d, r["arms"][k], px, y + 48)
img.save(out, quality=90)
print(out, img.size)
