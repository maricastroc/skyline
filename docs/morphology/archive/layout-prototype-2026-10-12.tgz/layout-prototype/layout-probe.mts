import { existsSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, out, mode, ...only] = process.argv.slice(2);
const { captureWithLocalBrowser } = await import(join(root, "src/lib/acquisition/rendered-capture.ts"));
const PAGES: Array<[string, string]> = [
  ["hn", "https://news.ycombinator.com/"],
  ["lobsters", "https://lobste.rs/"],
  ["pg", "https://www.paulgraham.com/articles.html"],
  ["pydocs", "https://docs.python.org/3/library/itertools.html"],
  ["mdn", "https://developer.mozilla.org/en-US/docs/Web/HTML"],
  ["wikipedia", "https://en.wikipedia.org/wiki/City"],
  ["linear", "https://linear.app/"],
  ["vercel", "https://vercel.com/"],
  ["apple", "https://www.apple.com/"],
  ["govuk", "https://www.gov.uk/"],
  ["guardian", "https://www.theguardian.com/international"],
  ["github", "https://github.com/vercel/next.js"],
  ["craigslist", "https://www.craigslist.org/about/sites"],
  ["spotify", "https://open.spotify.com/"],
  ["airbnb", "https://www.airbnb.com/"],
  ["pinterest", "https://www.pinterest.com/"],
  ["mastodon", "https://mastodon.social/explore"],
  ["rayso", "https://ray.so/"],
  ["excalidraw", "https://excalidraw.com/"],
  ["youtube", "https://www.youtube.com/"],
  ["ikea", "https://www.ikea.com/us/en/cat/chairs-fu002/"],
  ["portfolio", "https://brittanychiang.com/"],
];
for (const [id, url] of PAGES) {
  if (only.length && !only.includes(id)) continue;
  const file = join(out, `${id}.${mode}.json`);
  if (existsSync(file)) continue;
  const t0 = Date.now();
  try {
    const snap = await captureWithLocalBrowser(new URL(url), { measure: true, javascript: !mode.startsWith("nojs"), viewport: mode === "narrow" ? { width: 1100, height: 900 } : undefined });
    writeFileSync(file, JSON.stringify(snap));
    console.log(`${id.padEnd(11)} ${mode.padEnd(6)} ${String(snap.stats.elementCount).padStart(5)} elements · page ${snap.layout?.width}×${snap.layout?.height} · ${Date.now() - t0} ms`);
  } catch (e) {
    console.log(`${id.padEnd(11)} ${mode.padEnd(6)} FAILED ${(e as Error).message ?? e} ${(e as { code?: string }).code ?? ""}`);
  }
}
