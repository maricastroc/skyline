import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { generateKitDistrict, newTrace } = await import(join(root, "src/lib/pixelcity/kit/district.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { pruneUnseen } = await import(join(root, "src/lib/snapshot/layout.ts"));
const { columnsOf, bareOf } = await import(join(root, "src/lib/pixelcity/kit/spatial.ts"));
const PAIRS = join(root, "docs/rendered-capture/snapshots");
mkdirSync(PAIRS, { recursive: true });

export function arms(id: string) {
  const file = join(dir, `${id}.js.json`);
  if (!existsSync(file)) return null;
  const snap = JSON.parse(readFileSync(file, "utf8"));
  const pruned = { ...pruneUnseen(snap), layout: undefined };
  delete pruned.layout;
  writeFileSync(join(PAIRS, `lay-${id}.json`), JSON.stringify(snap));
  writeFileSync(join(PAIRS, `lay-${id}-pruned.json`), JSON.stringify(pruned));
  const build = (s: any, exp: string) => {
    const p = realPage(s, "none", parseExperiments(exp));
    const trace = newTrace();
    const city = generateKitDistrict(p.fp, { profile: p.plan, time: "day", seed: 7, trace });
    const h = createHash("sha1");
    for (const q of city.parts) h.update(JSON.stringify([q.mesh, q.x, q.y, q.z, q.w, q.h, q.d, q.color, q.surf]));
    const a = trace.alloc!;
    const ownerComp = Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : a.open?.has(a.segments[s].territory) ? "open" : a.segments[s].comp));
    const ownerKey = Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : p.plan.territories[a.segments[s].territory].key));
    const comp: Record<string, number> = {};
    for (const c of ownerComp) comp[c] = (comp[c] ?? 0) + 1 / 256;
    return { p, trace, city, hash: h.digest("hex"), ownerComp, ownerKey, comp, alloc: a };
  };
  return { id, base: build(snap, ""), prune: build(pruned, ""), full: build(snap, "layout"), columnsOf, bareOf };
}

if (process.argv[1]?.endsWith("arms.mts")) {
  console.log("page".padEnd(11), "base=prune", "prune=full", "| lots changing fabric: base→prune", "prune→full", "| lots changing place prune→full", "| columns", "open lots");
  for (const id of ids) {
    const r = arms(id);
    if (!r) continue;
    const diff = (x: string[], y: string[]) => x.filter((v, k) => v !== y[k]).length;
    const cols = r.columnsOf(r.full.p.plan, r.full.alloc.lots);
    console.log(
      id.padEnd(11),
      String(r.base.hash === r.prune.hash).padStart(10),
      String(r.prune.hash === r.full.hash).padStart(10),
      "|",
      `${Math.round((diff(r.base.ownerComp, r.prune.ownerComp) / 256) * 100)}%`.padStart(30),
      `${Math.round((diff(r.prune.ownerComp, r.full.ownerComp) / 256) * 100)}%`.padStart(10),
      "|",
      `${Math.round((diff(r.prune.ownerKey, r.full.ownerKey) / 256) * 100)}%`.padStart(29),
      "|",
      String(cols ? cols.length : 0).padStart(7),
      String(r.full.ownerComp.filter((c: string) => c === "open").length).padStart(9),
    );
  }
}
