import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [root, dir, ...ids] = process.argv.slice(2);
const { realPage } = await import(join(root, "src/lib/pixelcity/kit/real-page.ts"));
const { parseExperiments } = await import(join(root, "src/lib/semantics/experiments.ts"));
const { pruneUnseen } = await import(join(root, "src/lib/snapshot/layout.ts"));
const { allocateSpatial } = await import(join(root, "src/lib/pixelcity/kit/spatial.ts"));
const { allocate } = await import(join(root, "src/lib/pixelcity/kit/territory.ts"));
const lotsOf = (a: any) => Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? "-" : a.open?.has(a.segments[s].territory) ? "open" : a.segments[s].comp));
const edges = (a: any) => Array.from(a.owner as Int32Array).map((s: number) => (s < 0 ? -1 : a.segments[s].territory));
const out: any[] = [];
console.log("page".padEnd(11), "lots that change fabric when area follows the surface on screen instead of the visible weight");
for (const id of ids) {
  const f = join(dir, `${id}.js.json`);
  if (!existsSync(f)) continue;
  const snap = JSON.parse(readFileSync(f, "utf8"));
  const stripped: any = { ...pruneUnseen(snap) };
  delete stripped.layout;
  const b = realPage(snap);
  const p = realPage(stripped);
  const l = realPage(snap, "none", parseExperiments("layout"));
  const ab = allocate(b.plan), ap = allocate(p.plan), al = allocateSpatial(l.plan);
  const areas = l.plan.territories.map((t: any) => (t.frame?.rect ? Math.max(0, (t.frame.rect[2] - t.frame.rect[0]) * (t.frame.rect[3] - t.frame.rect[1])) : 0));
  const total = areas.reduce((s: number, v: number) => s + v, 0) || 1;
  const surface = { ...l.plan, territories: l.plan.territories.map((t: any, i: number) => ({ ...t, weight: areas[i] / total })) };
  const as = allocateSpatial(surface);
  const full = lotsOf(al), surf = lotsOf(as);
  console.log(id.padEnd(11), `${Math.round((full.filter((v, k) => v !== surf[k]).length / 256) * 100)}%`.padStart(5), " largest by weight:", [...l.plan.territories].map((t: any, i: number) => ({ c: [...t.mix].sort((x: any, y: any) => y.share - x.share)[0].comp, w: al.lots[i], s: as.lots[i] })).sort((x, y) => y.w - x.w).slice(0, 3).map((x) => `${x.c} ${x.w}→${x.s}`).join(", "));
  out.push({
    id, W: l.doc.layout.width, H: l.doc.layout.height,
    rects: l.plan.territories.map((t: any, i: number) => ({ comp: [...t.mix].sort((x: any, y: any) => y.share - x.share)[0].comp, rect: t.frame?.rect ?? null, lots: al.lots[i], open: al.open?.has(i) ?? false })),
    arms: [{ comp: lotsOf(ab), own: edges(ab) }, { comp: lotsOf(ap), own: edges(ap) }, { comp: full, own: edges(al) }, { comp: surf, own: edges(as) }],
  });
}
writeFileSync(join(dir, "plans3.json"), JSON.stringify(out));
